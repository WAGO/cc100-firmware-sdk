#!/bin/sh

cp packaging/rhel/syslog-ng.spec ${EXTRA_FILES_DIR}/syslog-ng.spec
