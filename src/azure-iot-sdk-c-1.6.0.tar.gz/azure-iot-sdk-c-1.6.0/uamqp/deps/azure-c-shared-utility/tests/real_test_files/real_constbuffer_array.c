// Copyright (c) Microsoft. All rights reserved.

#define GBALLOC_H

#include "real_constbuffer_array_renames.h"
#include "real_constbuffer_renames.h"

#include "constbuffer_array.c"
