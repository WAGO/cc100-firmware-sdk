// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef FOR_EACH_1_KEEP_2_TEST_H
#define FOR_EACH_1_KEEP_2_TEST_H

#include "azure_macro_utils/macro_utils.h"

int run_for_each_1_keep_2_tests(void);

#endif // FOR_EACH_1_KEEP_2_TEST_H
