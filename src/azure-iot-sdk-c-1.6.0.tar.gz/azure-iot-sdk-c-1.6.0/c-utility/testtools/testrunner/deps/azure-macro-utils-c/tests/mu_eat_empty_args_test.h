// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef MU_EAT_EMPTY_ARGS_TEST_H
#define MU_EAT_EMPTY_ARGS_TEST_H

int run_mu_eat_empty_args_test(void);

#endif // MU_EAT_EMPTY_ARGS_TEST_H
