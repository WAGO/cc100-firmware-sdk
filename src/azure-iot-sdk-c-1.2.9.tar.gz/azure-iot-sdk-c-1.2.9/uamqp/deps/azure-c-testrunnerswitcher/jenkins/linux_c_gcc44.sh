#!/bin/bash
#set -o pipefail
#

set -e

./jenkins/linux_c.sh
