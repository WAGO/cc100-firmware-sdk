# Sample removed

This sample has been removed.  See [here](../iothub_ll_client_shared_sample) for the latest version.
