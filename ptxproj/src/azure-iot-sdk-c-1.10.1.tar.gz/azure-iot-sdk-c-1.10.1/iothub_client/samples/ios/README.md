# iOS Samples for Microsoft Azure IoT

The C SDKs for Microsoft Azure IoT on Apple products are currently distributed via CocoaPods.

* [More info about the Azure IoT SDKs on CocoaPods](CocoaPods.md)</br>
* [Instructions for Swift samples for Azure IoT SDKs on CocoaPods](CocoaPods-Samples.md). 
