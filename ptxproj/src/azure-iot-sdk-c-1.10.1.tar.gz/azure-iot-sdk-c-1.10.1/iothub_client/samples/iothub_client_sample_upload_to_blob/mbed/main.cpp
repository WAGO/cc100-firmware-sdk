// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "iothub_client_sample_upload_to_blob.h"

int main(void)
{
	iothub_client_sample_upload_to_blob_run();
	return 0;
}
