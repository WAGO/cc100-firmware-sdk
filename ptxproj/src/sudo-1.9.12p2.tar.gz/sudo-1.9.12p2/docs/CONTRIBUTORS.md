The following list of people, sorted by last name, have contributed
code or patches to this implementation of sudo since I began
maintaining it in 1993. This list is known to be incomplete--if
you believe you should be listed, send a note to sudo@sudo.ws.

    Ackeret, Matt
    Adler, Mark
    Allbery, Russ
    Anderson, Jamie
    Andrew, Nick
    Andric, Dimitry
    Barron, Danny
    Bates, Tom
    Behan, Zdeněk
    Bellis, Ray
    Benali, Elias
    Beverly, Jamie
    Boardman, Spider
    Bos, Sander
    Bostley, P.J.
    Bowes, Keith
    Boyce, Keith Garry
    Brantley, Michael
    Braun, Rob
    Březina, Pavel
    Brooks, Piete
    Brown, Jerry
    Burr, Michael E
    Burton, Ross
    Bussjaeger, Andreas
    Calvin, Gary
    Campbell, Aaron
    Chazelas, Stephane
    Cheloha, Scott
    Čížek, Vítězslav
    Coleman, Chris
    Corzine, Deven T.
    Cusack, Frank
    Dai, Wei
    Dill, David
    Earickson, Jeff
    Eckhardt, Drew
    Edgington, Ben
    Esipovich, Marc
    Espie, Marc
    Faigon, Ariel
    Farrell, Brian
    Fobes, Steve
    Frysinger, Mike
    G., Daniel Richard
    Gailly, Jean-loup
    Gelman, Stephen
    Gerraty, Simon J.
    Graber, Stephane
    Guillory, B.
    Hayman, Randy M.
    Henke, Joachim
    Hideaki, Yoshifuji
    Hieb, Dave
    Holloway, Nick
    Hoover, Adam
    Hunter, Michael T.
    Hutchings, Ben
    Irrgang, Eric
    Jackson, Brian
    Jackson, John R.
    Jackson, Richard L., Jr.
    Janssen, Mark
    Jindrák, Jaroslav
    Jepeway, Chris
    Jorge, Joel Peláe
    Jover, Guillem
    Juhani, Timo
    Kikuchi, Ayamura
    Kadow, Kevin
    Kasal, Stepan
    Kienenberger, Mike
    King, Dale
    King, Michael
    Klyachkin, Andrey
    Knoble, Jim
    Knox, Tim
    Komarnitsky, Alek O.
    Kondrashov, Nikolai
    Kopeček, Daniel
    Kranenburg, Paul
    Krause, David
    Lakin, Eric
    Larsen, Case
    Levin, Dmitry V.
    Libby, Kendall
    Lobbes, Phillip E.
    McIntyre, Jason
    MacKenzie, David J.
    McLaughlin, Tom
    Makey, Jeff
    Mallayya, Sangamesh
    Manner, Róbert
    Marchionna, Michael D.
    Markham, Paul
    Martinian, Emin
    Meskes, Michael
    Michael, David
    Miller, Todd C.
    Minier, Loïc
    Moffat, Darren
    Moldung, Jan Thomas
    Morris, Charles
    Mueller, Andreas
    Müller, Dworkin
    Nieusma, Jeff
    Nikitser, Peter A.
    Nussel, Ludwig
    Orbán, László
    Ouellet, Jean-Philippe
    Paquet, Eric
    Paradis, Chantal
    Pasteleurs, Frederic
    Percival, Ted
    Perera, Andres
    Peron, Christian S.J.
    Peschel, Aaron
    Peslyak, Alexander
    Peterson, Toby
    Pettenò, Diego Elio
    Pickett, Joel
    Plotnick, Alex
    de Raadt, Theo
    Rasch, Gudleik
    Reid, Steve
    Richards, Matt
    Rossum, Guido van
    Rouillard, John P.
    Rowe, William A., Jr.
    Roy, Alain
    Ruusamäe, Elan
    Ryabinkin, Eygene
    Sato, Yuichi
    Sánchez, Wilfredo
    Sanders, Miguel
    Sasaki, Kan
    Saucier, Jean-Francois
    Schoenfeld, Patrick
    Schuring, Arno
    Schwarze, Ingo
    Scott, Dougal
    Shand, Will
    Sieger, Nick
    Simon, Thor Lancelot
    Skoll, Dianne
    Slemko, Marc
    Smith, Andy
    Sobrado, Igor
    Soulen, Steven
    Spangler, Aaron
    Spradling, Cloyce D.
    Spradling, Michael
    Stier, Matthew
    Stoeckmann, Tobias
    Street, Russell
    Stritzky, Tilo
    Stroucken, Michael
    Tarrall, Robert
    Thomas, Matthew
    Todd, Giles
    Toft, Martin
    Torek, Chris
    Tucker, Darren
    Uhl, Robert
    Uzel, Petr
    Valery, Reznic
    Van Dinter, Theo
    Venckus, Martynas
    de Vries, Maarten
    Wagner, Klaus
    Walsh, Dan
    Warburton, John
    Webb, Kirk
    Wetzel, Timm
    Wieringen, Marco van
    Wilk, Jakub
    Winiger, Gary
    Wood, David
    Zacarias, Gustavo
    Zolnowsky, John

The following people have worked to translate sudo into
other languages as part of the Translation Project, see
https://translationproject.org for more details.

    Albuquerque, Pedro
    Blättermann, Mario
    Bogusz, Jakub
    Buo-ren, Lin
    Casagrande, Milo
    Castro, Felipe
    Cho, Seong-ho
    Chornoivan, Yuri
    Diéguez, Francisco
    Doghonadze, Temuri
    Fontenelle, Rafael
    García-Fontes, Walter
    Gezer, Volkan
    Hamasaki, Takeshi
    Hamming, Peter
    Hansen, Joe
    Hantrais, Frédéric
    Hein, Jochen
    Hufthammer, Karl Ove
    Jerovšek, Damir
    Karvonen, Jorma
    Kazik, Dušan
    Kelemen, Gábor
    Keçeci, Mehmet
    Košir, Klemen
    Kozlov, Yuri
    Kramer, Jakob
    Krznar, Tomislav
    Marchal, Frédéric
    Margevičius, Algimantas
    Maryanov, Pavel
    Florentina Mușat
    Nurmi, Lauri
    Nikolić, Miroslav
    Nylander, Daniel
    Pan, Yi-Jyun
    Písař, Petr
    Puente, Enol
    Putanec, Božidar
    Quân, Trần Ngọc
    Rasmussen, Sebastian
    Regueiro, Leandro
    Sarıer, Özgür
    Sendón, Abel
    Șerbănescu, Daniel
    Shahedany, Eshagh
    Sikrom, Åka
    Spingos, Dimitris
    Taniguchi, Yasuaki
    Tomat, Fábio
    Úr, Balázs
    Uranga, Mikel Olasagasti
    Vorotnikov, Artem
    Wang, Wylmer
    Yang, Boyuan

The following people designed the artwork used on the sudo website:

    Shield logo: Badger, Trent
    Sandwich logo (inspired by xkcd): Stillman, Mark
