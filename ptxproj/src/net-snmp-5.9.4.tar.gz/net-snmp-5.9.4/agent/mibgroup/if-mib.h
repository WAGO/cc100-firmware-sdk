/*
 * module to include the modules
 */

config_require(if-mib/ifTable);
config_require(if-mib/ifXTable);
config_add_mib(IF-MIB);
