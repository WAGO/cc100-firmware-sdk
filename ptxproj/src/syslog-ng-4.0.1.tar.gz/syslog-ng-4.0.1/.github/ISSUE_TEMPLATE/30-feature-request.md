---
name: Feature request
about: Use this template for raising a feature request.
title: ''
labels: 'enhancement'
assignees: ''

---

## Description of the problem
<!-- Is your feature request related to a problem? Please describe. Ex. I'm always frustrated when [...] -->

## Proposed solution
<!-- Describe the solution you'd like. -->

## Alternatives
<!-- Describe any alternative solutions or features you've considered. -->

## Additional context
<!-- Add any other context or screenshots about the feature request here. -->
