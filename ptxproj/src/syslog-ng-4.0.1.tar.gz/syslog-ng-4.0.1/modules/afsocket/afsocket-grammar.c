/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* "%code top" blocks.  */
#line 24 "modules/afsocket/afsocket-grammar.y"

#include "afsocket-parser.h"


#line 73 "modules/afsocket/afsocket-grammar.c"
/* Substitute the type names.  */
#define YYSTYPE         AFSOCKET_STYPE
#define YYLTYPE         AFSOCKET_LTYPE
/* Substitute the variable and function names.  */
#define yyparse         afsocket_parse
#define yylex           afsocket_lex
#define yyerror         afsocket_error
#define yydebug         afsocket_debug
#define yynerrs         afsocket_nerrs


# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_AFSOCKET_MODULES_AFSOCKET_AFSOCKET_GRAMMAR_H_INCLUDED
# define YY_AFSOCKET_MODULES_AFSOCKET_AFSOCKET_GRAMMAR_H_INCLUDED
/* Debug traces.  */
#ifndef AFSOCKET_DEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define AFSOCKET_DEBUG 1
#  else
#   define AFSOCKET_DEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define AFSOCKET_DEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined AFSOCKET_DEBUG */
#if AFSOCKET_DEBUG
extern int afsocket_debug;
#endif

/* Token kinds.  */
#ifndef AFSOCKET_TOKENTYPE
# define AFSOCKET_TOKENTYPE
  enum afsocket_tokentype
  {
    AFSOCKET_EMPTY = -2,
    AFSOCKET_EOF = 0,              /* "end of file"  */
    AFSOCKET_error = 256,          /* error  */
    AFSOCKET_UNDEF = 20001,        /* "invalid token"  */
    KW_UNIX_STREAM = 20000,        /* KW_UNIX_STREAM  */
    KW_UNIX_DGRAM = 20002,         /* KW_UNIX_DGRAM  */
    KW_TCP = 20003,                /* KW_TCP  */
    KW_UDP = 20004,                /* KW_UDP  */
    KW_TCP6 = 20005,               /* KW_TCP6  */
    KW_UDP6 = 20006,               /* KW_UDP6  */
    KW_NETWORK = 20007,            /* KW_NETWORK  */
    KW_TRANSPORT = 20008,          /* KW_TRANSPORT  */
    KW_IP_PROTOCOL = 20009,        /* KW_IP_PROTOCOL  */
    KW_SYSTEMD_SYSLOG = 20010,     /* KW_SYSTEMD_SYSLOG  */
    KW_IP_TTL = 20011,             /* KW_IP_TTL  */
    KW_SO_BROADCAST = 20012,       /* KW_SO_BROADCAST  */
    KW_IP_TOS = 20013,             /* KW_IP_TOS  */
    KW_IP_FREEBIND = 20014,        /* KW_IP_FREEBIND  */
    KW_SO_SNDBUF = 20015,          /* KW_SO_SNDBUF  */
    KW_SO_RCVBUF = 20016,          /* KW_SO_RCVBUF  */
    KW_SO_KEEPALIVE = 20017,       /* KW_SO_KEEPALIVE  */
    KW_SO_REUSEPORT = 20018,       /* KW_SO_REUSEPORT  */
    KW_TCP_KEEPALIVE_TIME = 20019, /* KW_TCP_KEEPALIVE_TIME  */
    KW_TCP_KEEPALIVE_PROBES = 20020, /* KW_TCP_KEEPALIVE_PROBES  */
    KW_TCP_KEEPALIVE_INTVL = 20021, /* KW_TCP_KEEPALIVE_INTVL  */
    KW_SO_PASSCRED = 20022,        /* KW_SO_PASSCRED  */
    KW_LISTEN_BACKLOG = 20023,     /* KW_LISTEN_BACKLOG  */
    KW_SPOOF_SOURCE = 20024,       /* KW_SPOOF_SOURCE  */
    KW_SPOOF_SOURCE_MAX_MSGLEN = 20025, /* KW_SPOOF_SOURCE_MAX_MSGLEN  */
    KW_KEEP_ALIVE = 20026,         /* KW_KEEP_ALIVE  */
    KW_MAX_CONNECTIONS = 20027,    /* KW_MAX_CONNECTIONS  */
    KW_CLOSE_ON_INPUT = 20028,     /* KW_CLOSE_ON_INPUT  */
    KW_LOCALIP = 20029,            /* KW_LOCALIP  */
    KW_IP = 20030,                 /* KW_IP  */
    KW_INTERFACE = 20031,          /* KW_INTERFACE  */
    KW_LOCALPORT = 20032,          /* KW_LOCALPORT  */
    KW_DESTPORT = 20033,           /* KW_DESTPORT  */
    KW_FAILOVER_SERVERS = 20034,   /* KW_FAILOVER_SERVERS  */
    KW_FAILOVER = 20035,           /* KW_FAILOVER  */
    KW_SERVERS = 20036,            /* KW_SERVERS  */
    KW_FAILBACK = 20037,           /* KW_FAILBACK  */
    KW_TCP_PROBE_INTERVAL = 20038, /* KW_TCP_PROBE_INTERVAL  */
    KW_SUCCESSFUL_PROBES_REQUIRED = 20039, /* KW_SUCCESSFUL_PROBES_REQUIRED  */
    KW_DYNAMIC_WINDOW_SIZE = 20040, /* KW_DYNAMIC_WINDOW_SIZE  */
    KW_DYNAMIC_WINDOW_STATS_FREQ = 20041, /* KW_DYNAMIC_WINDOW_STATS_FREQ  */
    KW_DYNAMIC_WINDOW_REALLOC_TICKS = 20042, /* KW_DYNAMIC_WINDOW_REALLOC_TICKS  */
    KW_TLS = 20043,                /* KW_TLS  */
    KW_PEER_VERIFY = 20044,        /* KW_PEER_VERIFY  */
    KW_KEY_FILE = 20045,           /* KW_KEY_FILE  */
    KW_CERT_FILE = 20046,          /* KW_CERT_FILE  */
    KW_DHPARAM_FILE = 20047,       /* KW_DHPARAM_FILE  */
    KW_PKCS12_FILE = 20048,        /* KW_PKCS12_FILE  */
    KW_CA_DIR = 20049,             /* KW_CA_DIR  */
    KW_CRL_DIR = 20050,            /* KW_CRL_DIR  */
    KW_CA_FILE = 20051,            /* KW_CA_FILE  */
    KW_TRUSTED_KEYS = 20052,       /* KW_TRUSTED_KEYS  */
    KW_TRUSTED_DN = 20053,         /* KW_TRUSTED_DN  */
    KW_CIPHER_SUITE = 20054,       /* KW_CIPHER_SUITE  */
    KW_TLS12_AND_OLDER = 20055,    /* KW_TLS12_AND_OLDER  */
    KW_TLS13 = 20056,              /* KW_TLS13  */
    KW_SIGALGS = 20057,            /* KW_SIGALGS  */
    KW_CLIENT_SIGALGS = 20058,     /* KW_CLIENT_SIGALGS  */
    KW_ECDH_CURVE_LIST = 20059,    /* KW_ECDH_CURVE_LIST  */
    KW_SSL_OPTIONS = 20060,        /* KW_SSL_OPTIONS  */
    KW_SNI = 20061,                /* KW_SNI  */
    KW_ALLOW_COMPRESS = 20062,     /* KW_ALLOW_COMPRESS  */
    KW_KEYLOG_FILE = 20063,        /* KW_KEYLOG_FILE  */
    KW_OCSP_STAPLING_VERIFY = 20064, /* KW_OCSP_STAPLING_VERIFY  */
    KW_CONF_CMDS = 20065,          /* KW_CONF_CMDS  */
    LL_CONTEXT_ROOT = 1,           /* LL_CONTEXT_ROOT  */
    LL_CONTEXT_DESTINATION = 2,    /* LL_CONTEXT_DESTINATION  */
    LL_CONTEXT_SOURCE = 3,         /* LL_CONTEXT_SOURCE  */
    LL_CONTEXT_PARSER = 4,         /* LL_CONTEXT_PARSER  */
    LL_CONTEXT_REWRITE = 5,        /* LL_CONTEXT_REWRITE  */
    LL_CONTEXT_FILTER = 6,         /* LL_CONTEXT_FILTER  */
    LL_CONTEXT_LOG = 7,            /* LL_CONTEXT_LOG  */
    LL_CONTEXT_BLOCK_DEF = 8,      /* LL_CONTEXT_BLOCK_DEF  */
    LL_CONTEXT_BLOCK_REF = 9,      /* LL_CONTEXT_BLOCK_REF  */
    LL_CONTEXT_BLOCK_CONTENT = 10, /* LL_CONTEXT_BLOCK_CONTENT  */
    LL_CONTEXT_BLOCK_ARG = 11,     /* LL_CONTEXT_BLOCK_ARG  */
    LL_CONTEXT_PRAGMA = 12,        /* LL_CONTEXT_PRAGMA  */
    LL_CONTEXT_FORMAT = 13,        /* LL_CONTEXT_FORMAT  */
    LL_CONTEXT_TEMPLATE_FUNC = 14, /* LL_CONTEXT_TEMPLATE_FUNC  */
    LL_CONTEXT_INNER_DEST = 15,    /* LL_CONTEXT_INNER_DEST  */
    LL_CONTEXT_INNER_SRC = 16,     /* LL_CONTEXT_INNER_SRC  */
    LL_CONTEXT_CLIENT_PROTO = 17,  /* LL_CONTEXT_CLIENT_PROTO  */
    LL_CONTEXT_SERVER_PROTO = 18,  /* LL_CONTEXT_SERVER_PROTO  */
    LL_CONTEXT_OPTIONS = 19,       /* LL_CONTEXT_OPTIONS  */
    LL_CONTEXT_CONFIG = 20,        /* LL_CONTEXT_CONFIG  */
    LL_CONTEXT_MAX = 21,           /* LL_CONTEXT_MAX  */
    KW_SOURCE = 10000,             /* KW_SOURCE  */
    KW_FILTER = 10001,             /* KW_FILTER  */
    KW_PARSER = 10002,             /* KW_PARSER  */
    KW_DESTINATION = 10003,        /* KW_DESTINATION  */
    KW_LOG = 10004,                /* KW_LOG  */
    KW_OPTIONS = 10005,            /* KW_OPTIONS  */
    KW_INCLUDE = 10006,            /* KW_INCLUDE  */
    KW_BLOCK = 10007,              /* KW_BLOCK  */
    KW_JUNCTION = 10008,           /* KW_JUNCTION  */
    KW_CHANNEL = 10009,            /* KW_CHANNEL  */
    KW_IF = 10010,                 /* KW_IF  */
    KW_ELSE = 10011,               /* KW_ELSE  */
    KW_ELIF = 10012,               /* KW_ELIF  */
    KW_INTERNAL = 10020,           /* KW_INTERNAL  */
    KW_SYSLOG = 10060,             /* KW_SYSLOG  */
    KW_MARK_FREQ = 10071,          /* KW_MARK_FREQ  */
    KW_STATS_FREQ = 10072,         /* KW_STATS_FREQ  */
    KW_STATS_LEVEL = 10073,        /* KW_STATS_LEVEL  */
    KW_STATS_LIFETIME = 10074,     /* KW_STATS_LIFETIME  */
    KW_FLUSH_LINES = 10075,        /* KW_FLUSH_LINES  */
    KW_SUPPRESS = 10076,           /* KW_SUPPRESS  */
    KW_FLUSH_TIMEOUT = 10077,      /* KW_FLUSH_TIMEOUT  */
    KW_LOG_MSG_SIZE = 10078,       /* KW_LOG_MSG_SIZE  */
    KW_FILE_TEMPLATE = 10079,      /* KW_FILE_TEMPLATE  */
    KW_PROTO_TEMPLATE = 10080,     /* KW_PROTO_TEMPLATE  */
    KW_MARK_MODE = 10081,          /* KW_MARK_MODE  */
    KW_ENCODING = 10082,           /* KW_ENCODING  */
    KW_TYPE = 10083,               /* KW_TYPE  */
    KW_STATS_MAX_DYNAMIC = 10084,  /* KW_STATS_MAX_DYNAMIC  */
    KW_MIN_IW_SIZE_PER_READER = 10085, /* KW_MIN_IW_SIZE_PER_READER  */
    KW_WORKERS = 10086,            /* KW_WORKERS  */
    KW_BATCH_LINES = 10087,        /* KW_BATCH_LINES  */
    KW_BATCH_TIMEOUT = 10088,      /* KW_BATCH_TIMEOUT  */
    KW_TRIM_LARGE_MESSAGES = 10089, /* KW_TRIM_LARGE_MESSAGES  */
    KW_CHAIN_HOSTNAMES = 10090,    /* KW_CHAIN_HOSTNAMES  */
    KW_NORMALIZE_HOSTNAMES = 10091, /* KW_NORMALIZE_HOSTNAMES  */
    KW_KEEP_HOSTNAME = 10092,      /* KW_KEEP_HOSTNAME  */
    KW_CHECK_HOSTNAME = 10093,     /* KW_CHECK_HOSTNAME  */
    KW_BAD_HOSTNAME = 10094,       /* KW_BAD_HOSTNAME  */
    KW_LOG_LEVEL = 10095,          /* KW_LOG_LEVEL  */
    KW_KEEP_TIMESTAMP = 10100,     /* KW_KEEP_TIMESTAMP  */
    KW_USE_DNS = 10110,            /* KW_USE_DNS  */
    KW_USE_FQDN = 10111,           /* KW_USE_FQDN  */
    KW_CUSTOM_DOMAIN = 10112,      /* KW_CUSTOM_DOMAIN  */
    KW_DNS_CACHE = 10120,          /* KW_DNS_CACHE  */
    KW_DNS_CACHE_SIZE = 10121,     /* KW_DNS_CACHE_SIZE  */
    KW_DNS_CACHE_EXPIRE = 10130,   /* KW_DNS_CACHE_EXPIRE  */
    KW_DNS_CACHE_EXPIRE_FAILED = 10131, /* KW_DNS_CACHE_EXPIRE_FAILED  */
    KW_DNS_CACHE_HOSTS = 10132,    /* KW_DNS_CACHE_HOSTS  */
    KW_PERSIST_ONLY = 10140,       /* KW_PERSIST_ONLY  */
    KW_USE_RCPTID = 10141,         /* KW_USE_RCPTID  */
    KW_USE_UNIQID = 10142,         /* KW_USE_UNIQID  */
    KW_TZ_CONVERT = 10150,         /* KW_TZ_CONVERT  */
    KW_TS_FORMAT = 10151,          /* KW_TS_FORMAT  */
    KW_FRAC_DIGITS = 10152,        /* KW_FRAC_DIGITS  */
    KW_LOG_FIFO_SIZE = 10160,      /* KW_LOG_FIFO_SIZE  */
    KW_LOG_FETCH_LIMIT = 10162,    /* KW_LOG_FETCH_LIMIT  */
    KW_LOG_IW_SIZE = 10163,        /* KW_LOG_IW_SIZE  */
    KW_LOG_PREFIX = 10164,         /* KW_LOG_PREFIX  */
    KW_PROGRAM_OVERRIDE = 10165,   /* KW_PROGRAM_OVERRIDE  */
    KW_HOST_OVERRIDE = 10166,      /* KW_HOST_OVERRIDE  */
    KW_THROTTLE = 10170,           /* KW_THROTTLE  */
    KW_THREADED = 10171,           /* KW_THREADED  */
    KW_PASS_UNIX_CREDENTIALS = 10231, /* KW_PASS_UNIX_CREDENTIALS  */
    KW_PERSIST_NAME = 10302,       /* KW_PERSIST_NAME  */
    KW_READ_OLD_RECORDS = 10304,   /* KW_READ_OLD_RECORDS  */
    KW_USE_SYSLOGNG_PID = 10305,   /* KW_USE_SYSLOGNG_PID  */
    KW_FLAGS = 10190,              /* KW_FLAGS  */
    KW_PAD_SIZE = 10200,           /* KW_PAD_SIZE  */
    KW_TIME_ZONE = 10201,          /* KW_TIME_ZONE  */
    KW_RECV_TIME_ZONE = 10202,     /* KW_RECV_TIME_ZONE  */
    KW_SEND_TIME_ZONE = 10203,     /* KW_SEND_TIME_ZONE  */
    KW_LOCAL_TIME_ZONE = 10204,    /* KW_LOCAL_TIME_ZONE  */
    KW_FORMAT = 10205,             /* KW_FORMAT  */
    KW_TRUNCATE_SIZE = 10206,      /* KW_TRUNCATE_SIZE  */
    KW_TIME_REOPEN = 10210,        /* KW_TIME_REOPEN  */
    KW_TIME_REAP = 10211,          /* KW_TIME_REAP  */
    KW_TIME_SLEEP = 10212,         /* KW_TIME_SLEEP  */
    KW_TMPL_ESCAPE = 10220,        /* KW_TMPL_ESCAPE  */
    KW_OPTIONAL = 10230,           /* KW_OPTIONAL  */
    KW_CREATE_DIRS = 10240,        /* KW_CREATE_DIRS  */
    KW_OWNER = 10250,              /* KW_OWNER  */
    KW_GROUP = 10251,              /* KW_GROUP  */
    KW_PERM = 10252,               /* KW_PERM  */
    KW_DIR_OWNER = 10260,          /* KW_DIR_OWNER  */
    KW_DIR_GROUP = 10261,          /* KW_DIR_GROUP  */
    KW_DIR_PERM = 10262,           /* KW_DIR_PERM  */
    KW_TEMPLATE = 10270,           /* KW_TEMPLATE  */
    KW_TEMPLATE_ESCAPE = 10271,    /* KW_TEMPLATE_ESCAPE  */
    KW_TEMPLATE_FUNCTION = 10272,  /* KW_TEMPLATE_FUNCTION  */
    KW_DEFAULT_FACILITY = 10300,   /* KW_DEFAULT_FACILITY  */
    KW_DEFAULT_SEVERITY = 10301,   /* KW_DEFAULT_SEVERITY  */
    KW_PORT = 10323,               /* KW_PORT  */
    KW_USE_TIME_RECVD = 10340,     /* KW_USE_TIME_RECVD  */
    KW_FACILITY = 10350,           /* KW_FACILITY  */
    KW_SEVERITY = 10351,           /* KW_SEVERITY  */
    KW_HOST = 10352,               /* KW_HOST  */
    KW_MATCH = 10353,              /* KW_MATCH  */
    KW_MESSAGE = 10354,            /* KW_MESSAGE  */
    KW_NETMASK = 10355,            /* KW_NETMASK  */
    KW_TAGS = 10356,               /* KW_TAGS  */
    KW_NETMASK6 = 10357,           /* KW_NETMASK6  */
    KW_REWRITE = 10370,            /* KW_REWRITE  */
    KW_CONDITION = 10371,          /* KW_CONDITION  */
    KW_VALUE = 10372,              /* KW_VALUE  */
    KW_YES = 10380,                /* KW_YES  */
    KW_NO = 10381,                 /* KW_NO  */
    KW_IFDEF = 10410,              /* KW_IFDEF  */
    KW_ENDIF = 10411,              /* KW_ENDIF  */
    LL_DOTDOT = 10420,             /* LL_DOTDOT  */
    LL_DOTDOTDOT = 10421,          /* LL_DOTDOTDOT  */
    LL_PRAGMA = 10422,             /* LL_PRAGMA  */
    LL_EOL = 10423,                /* LL_EOL  */
    LL_ERROR = 10424,              /* LL_ERROR  */
    LL_ARROW = 10425,              /* LL_ARROW  */
    LL_IDENTIFIER = 10430,         /* LL_IDENTIFIER  */
    LL_NUMBER = 10431,             /* LL_NUMBER  */
    LL_FLOAT = 10432,              /* LL_FLOAT  */
    LL_STRING = 10433,             /* LL_STRING  */
    LL_TOKEN = 10434,              /* LL_TOKEN  */
    LL_BLOCK = 10435,              /* LL_BLOCK  */
    LL_PLUGIN = 10436,             /* LL_PLUGIN  */
    KW_VALUE_PAIRS = 10500,        /* KW_VALUE_PAIRS  */
    KW_EXCLUDE = 10502,            /* KW_EXCLUDE  */
    KW_PAIR = 10503,               /* KW_PAIR  */
    KW_KEY = 10504,                /* KW_KEY  */
    KW_SCOPE = 10505,              /* KW_SCOPE  */
    KW_SHIFT = 10506,              /* KW_SHIFT  */
    KW_SHIFT_LEVELS = 10507,       /* KW_SHIFT_LEVELS  */
    KW_REKEY = 10508,              /* KW_REKEY  */
    KW_ADD_PREFIX = 10509,         /* KW_ADD_PREFIX  */
    KW_REPLACE_PREFIX = 10510,     /* KW_REPLACE_PREFIX  */
    KW_CAST = 10511,               /* KW_CAST  */
    KW_ON_ERROR = 10520,           /* KW_ON_ERROR  */
    KW_RETRIES = 10521,            /* KW_RETRIES  */
    KW_FETCH_NO_DATA_DELAY = 10522 /* KW_FETCH_NO_DATA_DELAY  */
  };
  typedef enum afsocket_tokentype afsocket_token_kind_t;
#endif
/* Token kinds.  */
#define AFSOCKET_EMPTY -2
#define AFSOCKET_EOF 0
#define AFSOCKET_error 256
#define AFSOCKET_UNDEF 20001
#define KW_UNIX_STREAM 20000
#define KW_UNIX_DGRAM 20002
#define KW_TCP 20003
#define KW_UDP 20004
#define KW_TCP6 20005
#define KW_UDP6 20006
#define KW_NETWORK 20007
#define KW_TRANSPORT 20008
#define KW_IP_PROTOCOL 20009
#define KW_SYSTEMD_SYSLOG 20010
#define KW_IP_TTL 20011
#define KW_SO_BROADCAST 20012
#define KW_IP_TOS 20013
#define KW_IP_FREEBIND 20014
#define KW_SO_SNDBUF 20015
#define KW_SO_RCVBUF 20016
#define KW_SO_KEEPALIVE 20017
#define KW_SO_REUSEPORT 20018
#define KW_TCP_KEEPALIVE_TIME 20019
#define KW_TCP_KEEPALIVE_PROBES 20020
#define KW_TCP_KEEPALIVE_INTVL 20021
#define KW_SO_PASSCRED 20022
#define KW_LISTEN_BACKLOG 20023
#define KW_SPOOF_SOURCE 20024
#define KW_SPOOF_SOURCE_MAX_MSGLEN 20025
#define KW_KEEP_ALIVE 20026
#define KW_MAX_CONNECTIONS 20027
#define KW_CLOSE_ON_INPUT 20028
#define KW_LOCALIP 20029
#define KW_IP 20030
#define KW_INTERFACE 20031
#define KW_LOCALPORT 20032
#define KW_DESTPORT 20033
#define KW_FAILOVER_SERVERS 20034
#define KW_FAILOVER 20035
#define KW_SERVERS 20036
#define KW_FAILBACK 20037
#define KW_TCP_PROBE_INTERVAL 20038
#define KW_SUCCESSFUL_PROBES_REQUIRED 20039
#define KW_DYNAMIC_WINDOW_SIZE 20040
#define KW_DYNAMIC_WINDOW_STATS_FREQ 20041
#define KW_DYNAMIC_WINDOW_REALLOC_TICKS 20042
#define KW_TLS 20043
#define KW_PEER_VERIFY 20044
#define KW_KEY_FILE 20045
#define KW_CERT_FILE 20046
#define KW_DHPARAM_FILE 20047
#define KW_PKCS12_FILE 20048
#define KW_CA_DIR 20049
#define KW_CRL_DIR 20050
#define KW_CA_FILE 20051
#define KW_TRUSTED_KEYS 20052
#define KW_TRUSTED_DN 20053
#define KW_CIPHER_SUITE 20054
#define KW_TLS12_AND_OLDER 20055
#define KW_TLS13 20056
#define KW_SIGALGS 20057
#define KW_CLIENT_SIGALGS 20058
#define KW_ECDH_CURVE_LIST 20059
#define KW_SSL_OPTIONS 20060
#define KW_SNI 20061
#define KW_ALLOW_COMPRESS 20062
#define KW_KEYLOG_FILE 20063
#define KW_OCSP_STAPLING_VERIFY 20064
#define KW_CONF_CMDS 20065
#define LL_CONTEXT_ROOT 1
#define LL_CONTEXT_DESTINATION 2
#define LL_CONTEXT_SOURCE 3
#define LL_CONTEXT_PARSER 4
#define LL_CONTEXT_REWRITE 5
#define LL_CONTEXT_FILTER 6
#define LL_CONTEXT_LOG 7
#define LL_CONTEXT_BLOCK_DEF 8
#define LL_CONTEXT_BLOCK_REF 9
#define LL_CONTEXT_BLOCK_CONTENT 10
#define LL_CONTEXT_BLOCK_ARG 11
#define LL_CONTEXT_PRAGMA 12
#define LL_CONTEXT_FORMAT 13
#define LL_CONTEXT_TEMPLATE_FUNC 14
#define LL_CONTEXT_INNER_DEST 15
#define LL_CONTEXT_INNER_SRC 16
#define LL_CONTEXT_CLIENT_PROTO 17
#define LL_CONTEXT_SERVER_PROTO 18
#define LL_CONTEXT_OPTIONS 19
#define LL_CONTEXT_CONFIG 20
#define LL_CONTEXT_MAX 21
#define KW_SOURCE 10000
#define KW_FILTER 10001
#define KW_PARSER 10002
#define KW_DESTINATION 10003
#define KW_LOG 10004
#define KW_OPTIONS 10005
#define KW_INCLUDE 10006
#define KW_BLOCK 10007
#define KW_JUNCTION 10008
#define KW_CHANNEL 10009
#define KW_IF 10010
#define KW_ELSE 10011
#define KW_ELIF 10012
#define KW_INTERNAL 10020
#define KW_SYSLOG 10060
#define KW_MARK_FREQ 10071
#define KW_STATS_FREQ 10072
#define KW_STATS_LEVEL 10073
#define KW_STATS_LIFETIME 10074
#define KW_FLUSH_LINES 10075
#define KW_SUPPRESS 10076
#define KW_FLUSH_TIMEOUT 10077
#define KW_LOG_MSG_SIZE 10078
#define KW_FILE_TEMPLATE 10079
#define KW_PROTO_TEMPLATE 10080
#define KW_MARK_MODE 10081
#define KW_ENCODING 10082
#define KW_TYPE 10083
#define KW_STATS_MAX_DYNAMIC 10084
#define KW_MIN_IW_SIZE_PER_READER 10085
#define KW_WORKERS 10086
#define KW_BATCH_LINES 10087
#define KW_BATCH_TIMEOUT 10088
#define KW_TRIM_LARGE_MESSAGES 10089
#define KW_CHAIN_HOSTNAMES 10090
#define KW_NORMALIZE_HOSTNAMES 10091
#define KW_KEEP_HOSTNAME 10092
#define KW_CHECK_HOSTNAME 10093
#define KW_BAD_HOSTNAME 10094
#define KW_LOG_LEVEL 10095
#define KW_KEEP_TIMESTAMP 10100
#define KW_USE_DNS 10110
#define KW_USE_FQDN 10111
#define KW_CUSTOM_DOMAIN 10112
#define KW_DNS_CACHE 10120
#define KW_DNS_CACHE_SIZE 10121
#define KW_DNS_CACHE_EXPIRE 10130
#define KW_DNS_CACHE_EXPIRE_FAILED 10131
#define KW_DNS_CACHE_HOSTS 10132
#define KW_PERSIST_ONLY 10140
#define KW_USE_RCPTID 10141
#define KW_USE_UNIQID 10142
#define KW_TZ_CONVERT 10150
#define KW_TS_FORMAT 10151
#define KW_FRAC_DIGITS 10152
#define KW_LOG_FIFO_SIZE 10160
#define KW_LOG_FETCH_LIMIT 10162
#define KW_LOG_IW_SIZE 10163
#define KW_LOG_PREFIX 10164
#define KW_PROGRAM_OVERRIDE 10165
#define KW_HOST_OVERRIDE 10166
#define KW_THROTTLE 10170
#define KW_THREADED 10171
#define KW_PASS_UNIX_CREDENTIALS 10231
#define KW_PERSIST_NAME 10302
#define KW_READ_OLD_RECORDS 10304
#define KW_USE_SYSLOGNG_PID 10305
#define KW_FLAGS 10190
#define KW_PAD_SIZE 10200
#define KW_TIME_ZONE 10201
#define KW_RECV_TIME_ZONE 10202
#define KW_SEND_TIME_ZONE 10203
#define KW_LOCAL_TIME_ZONE 10204
#define KW_FORMAT 10205
#define KW_TRUNCATE_SIZE 10206
#define KW_TIME_REOPEN 10210
#define KW_TIME_REAP 10211
#define KW_TIME_SLEEP 10212
#define KW_TMPL_ESCAPE 10220
#define KW_OPTIONAL 10230
#define KW_CREATE_DIRS 10240
#define KW_OWNER 10250
#define KW_GROUP 10251
#define KW_PERM 10252
#define KW_DIR_OWNER 10260
#define KW_DIR_GROUP 10261
#define KW_DIR_PERM 10262
#define KW_TEMPLATE 10270
#define KW_TEMPLATE_ESCAPE 10271
#define KW_TEMPLATE_FUNCTION 10272
#define KW_DEFAULT_FACILITY 10300
#define KW_DEFAULT_SEVERITY 10301
#define KW_PORT 10323
#define KW_USE_TIME_RECVD 10340
#define KW_FACILITY 10350
#define KW_SEVERITY 10351
#define KW_HOST 10352
#define KW_MATCH 10353
#define KW_MESSAGE 10354
#define KW_NETMASK 10355
#define KW_TAGS 10356
#define KW_NETMASK6 10357
#define KW_REWRITE 10370
#define KW_CONDITION 10371
#define KW_VALUE 10372
#define KW_YES 10380
#define KW_NO 10381
#define KW_IFDEF 10410
#define KW_ENDIF 10411
#define LL_DOTDOT 10420
#define LL_DOTDOTDOT 10421
#define LL_PRAGMA 10422
#define LL_EOL 10423
#define LL_ERROR 10424
#define LL_ARROW 10425
#define LL_IDENTIFIER 10430
#define LL_NUMBER 10431
#define LL_FLOAT 10432
#define LL_STRING 10433
#define LL_TOKEN 10434
#define LL_BLOCK 10435
#define LL_PLUGIN 10436
#define KW_VALUE_PAIRS 10500
#define KW_EXCLUDE 10502
#define KW_PAIR 10503
#define KW_KEY 10504
#define KW_SCOPE 10505
#define KW_SHIFT 10506
#define KW_SHIFT_LEVELS 10507
#define KW_REKEY 10508
#define KW_ADD_PREFIX 10509
#define KW_REPLACE_PREFIX 10510
#define KW_CAST 10511
#define KW_ON_ERROR 10520
#define KW_RETRIES 10521
#define KW_FETCH_NO_DATA_DELAY 10522

/* Value type.  */
#if ! defined AFSOCKET_STYPE && ! defined AFSOCKET_STYPE_IS_DECLARED
typedef CFG_STYPE AFSOCKET_STYPE;
# define AFSOCKET_STYPE_IS_TRIVIAL 1
# define AFSOCKET_STYPE_IS_DECLARED 1
#endif

/* Location type.  */
typedef CFG_LTYPE AFSOCKET_LTYPE;




int afsocket_parse (CfgLexer *lexer, LogDriver **instance, gpointer arg);


#endif /* !YY_AFSOCKET_MODULES_AFSOCKET_AFSOCKET_GRAMMAR_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_KW_UNIX_STREAM = 3,             /* KW_UNIX_STREAM  */
  YYSYMBOL_KW_UNIX_DGRAM = 4,              /* KW_UNIX_DGRAM  */
  YYSYMBOL_KW_TCP = 5,                     /* KW_TCP  */
  YYSYMBOL_KW_UDP = 6,                     /* KW_UDP  */
  YYSYMBOL_KW_TCP6 = 7,                    /* KW_TCP6  */
  YYSYMBOL_KW_UDP6 = 8,                    /* KW_UDP6  */
  YYSYMBOL_KW_NETWORK = 9,                 /* KW_NETWORK  */
  YYSYMBOL_KW_TRANSPORT = 10,              /* KW_TRANSPORT  */
  YYSYMBOL_KW_IP_PROTOCOL = 11,            /* KW_IP_PROTOCOL  */
  YYSYMBOL_KW_SYSTEMD_SYSLOG = 12,         /* KW_SYSTEMD_SYSLOG  */
  YYSYMBOL_KW_IP_TTL = 13,                 /* KW_IP_TTL  */
  YYSYMBOL_KW_SO_BROADCAST = 14,           /* KW_SO_BROADCAST  */
  YYSYMBOL_KW_IP_TOS = 15,                 /* KW_IP_TOS  */
  YYSYMBOL_KW_IP_FREEBIND = 16,            /* KW_IP_FREEBIND  */
  YYSYMBOL_KW_SO_SNDBUF = 17,              /* KW_SO_SNDBUF  */
  YYSYMBOL_KW_SO_RCVBUF = 18,              /* KW_SO_RCVBUF  */
  YYSYMBOL_KW_SO_KEEPALIVE = 19,           /* KW_SO_KEEPALIVE  */
  YYSYMBOL_KW_SO_REUSEPORT = 20,           /* KW_SO_REUSEPORT  */
  YYSYMBOL_KW_TCP_KEEPALIVE_TIME = 21,     /* KW_TCP_KEEPALIVE_TIME  */
  YYSYMBOL_KW_TCP_KEEPALIVE_PROBES = 22,   /* KW_TCP_KEEPALIVE_PROBES  */
  YYSYMBOL_KW_TCP_KEEPALIVE_INTVL = 23,    /* KW_TCP_KEEPALIVE_INTVL  */
  YYSYMBOL_KW_SO_PASSCRED = 24,            /* KW_SO_PASSCRED  */
  YYSYMBOL_KW_LISTEN_BACKLOG = 25,         /* KW_LISTEN_BACKLOG  */
  YYSYMBOL_KW_SPOOF_SOURCE = 26,           /* KW_SPOOF_SOURCE  */
  YYSYMBOL_KW_SPOOF_SOURCE_MAX_MSGLEN = 27, /* KW_SPOOF_SOURCE_MAX_MSGLEN  */
  YYSYMBOL_KW_KEEP_ALIVE = 28,             /* KW_KEEP_ALIVE  */
  YYSYMBOL_KW_MAX_CONNECTIONS = 29,        /* KW_MAX_CONNECTIONS  */
  YYSYMBOL_KW_CLOSE_ON_INPUT = 30,         /* KW_CLOSE_ON_INPUT  */
  YYSYMBOL_KW_LOCALIP = 31,                /* KW_LOCALIP  */
  YYSYMBOL_KW_IP = 32,                     /* KW_IP  */
  YYSYMBOL_KW_INTERFACE = 33,              /* KW_INTERFACE  */
  YYSYMBOL_KW_LOCALPORT = 34,              /* KW_LOCALPORT  */
  YYSYMBOL_KW_DESTPORT = 35,               /* KW_DESTPORT  */
  YYSYMBOL_KW_FAILOVER_SERVERS = 36,       /* KW_FAILOVER_SERVERS  */
  YYSYMBOL_KW_FAILOVER = 37,               /* KW_FAILOVER  */
  YYSYMBOL_KW_SERVERS = 38,                /* KW_SERVERS  */
  YYSYMBOL_KW_FAILBACK = 39,               /* KW_FAILBACK  */
  YYSYMBOL_KW_TCP_PROBE_INTERVAL = 40,     /* KW_TCP_PROBE_INTERVAL  */
  YYSYMBOL_KW_SUCCESSFUL_PROBES_REQUIRED = 41, /* KW_SUCCESSFUL_PROBES_REQUIRED  */
  YYSYMBOL_KW_DYNAMIC_WINDOW_SIZE = 42,    /* KW_DYNAMIC_WINDOW_SIZE  */
  YYSYMBOL_KW_DYNAMIC_WINDOW_STATS_FREQ = 43, /* KW_DYNAMIC_WINDOW_STATS_FREQ  */
  YYSYMBOL_KW_DYNAMIC_WINDOW_REALLOC_TICKS = 44, /* KW_DYNAMIC_WINDOW_REALLOC_TICKS  */
  YYSYMBOL_KW_TLS = 45,                    /* KW_TLS  */
  YYSYMBOL_KW_PEER_VERIFY = 46,            /* KW_PEER_VERIFY  */
  YYSYMBOL_KW_KEY_FILE = 47,               /* KW_KEY_FILE  */
  YYSYMBOL_KW_CERT_FILE = 48,              /* KW_CERT_FILE  */
  YYSYMBOL_KW_DHPARAM_FILE = 49,           /* KW_DHPARAM_FILE  */
  YYSYMBOL_KW_PKCS12_FILE = 50,            /* KW_PKCS12_FILE  */
  YYSYMBOL_KW_CA_DIR = 51,                 /* KW_CA_DIR  */
  YYSYMBOL_KW_CRL_DIR = 52,                /* KW_CRL_DIR  */
  YYSYMBOL_KW_CA_FILE = 53,                /* KW_CA_FILE  */
  YYSYMBOL_KW_TRUSTED_KEYS = 54,           /* KW_TRUSTED_KEYS  */
  YYSYMBOL_KW_TRUSTED_DN = 55,             /* KW_TRUSTED_DN  */
  YYSYMBOL_KW_CIPHER_SUITE = 56,           /* KW_CIPHER_SUITE  */
  YYSYMBOL_KW_TLS12_AND_OLDER = 57,        /* KW_TLS12_AND_OLDER  */
  YYSYMBOL_KW_TLS13 = 58,                  /* KW_TLS13  */
  YYSYMBOL_KW_SIGALGS = 59,                /* KW_SIGALGS  */
  YYSYMBOL_KW_CLIENT_SIGALGS = 60,         /* KW_CLIENT_SIGALGS  */
  YYSYMBOL_KW_ECDH_CURVE_LIST = 61,        /* KW_ECDH_CURVE_LIST  */
  YYSYMBOL_KW_SSL_OPTIONS = 62,            /* KW_SSL_OPTIONS  */
  YYSYMBOL_KW_SNI = 63,                    /* KW_SNI  */
  YYSYMBOL_KW_ALLOW_COMPRESS = 64,         /* KW_ALLOW_COMPRESS  */
  YYSYMBOL_KW_KEYLOG_FILE = 65,            /* KW_KEYLOG_FILE  */
  YYSYMBOL_KW_OCSP_STAPLING_VERIFY = 66,   /* KW_OCSP_STAPLING_VERIFY  */
  YYSYMBOL_KW_CONF_CMDS = 67,              /* KW_CONF_CMDS  */
  YYSYMBOL_LL_CONTEXT_ROOT = 68,           /* LL_CONTEXT_ROOT  */
  YYSYMBOL_LL_CONTEXT_DESTINATION = 69,    /* LL_CONTEXT_DESTINATION  */
  YYSYMBOL_LL_CONTEXT_SOURCE = 70,         /* LL_CONTEXT_SOURCE  */
  YYSYMBOL_LL_CONTEXT_PARSER = 71,         /* LL_CONTEXT_PARSER  */
  YYSYMBOL_LL_CONTEXT_REWRITE = 72,        /* LL_CONTEXT_REWRITE  */
  YYSYMBOL_LL_CONTEXT_FILTER = 73,         /* LL_CONTEXT_FILTER  */
  YYSYMBOL_LL_CONTEXT_LOG = 74,            /* LL_CONTEXT_LOG  */
  YYSYMBOL_LL_CONTEXT_BLOCK_DEF = 75,      /* LL_CONTEXT_BLOCK_DEF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_REF = 76,      /* LL_CONTEXT_BLOCK_REF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_CONTENT = 77,  /* LL_CONTEXT_BLOCK_CONTENT  */
  YYSYMBOL_LL_CONTEXT_BLOCK_ARG = 78,      /* LL_CONTEXT_BLOCK_ARG  */
  YYSYMBOL_LL_CONTEXT_PRAGMA = 79,         /* LL_CONTEXT_PRAGMA  */
  YYSYMBOL_LL_CONTEXT_FORMAT = 80,         /* LL_CONTEXT_FORMAT  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_FUNC = 81,  /* LL_CONTEXT_TEMPLATE_FUNC  */
  YYSYMBOL_LL_CONTEXT_INNER_DEST = 82,     /* LL_CONTEXT_INNER_DEST  */
  YYSYMBOL_LL_CONTEXT_INNER_SRC = 83,      /* LL_CONTEXT_INNER_SRC  */
  YYSYMBOL_LL_CONTEXT_CLIENT_PROTO = 84,   /* LL_CONTEXT_CLIENT_PROTO  */
  YYSYMBOL_LL_CONTEXT_SERVER_PROTO = 85,   /* LL_CONTEXT_SERVER_PROTO  */
  YYSYMBOL_LL_CONTEXT_OPTIONS = 86,        /* LL_CONTEXT_OPTIONS  */
  YYSYMBOL_LL_CONTEXT_CONFIG = 87,         /* LL_CONTEXT_CONFIG  */
  YYSYMBOL_LL_CONTEXT_MAX = 88,            /* LL_CONTEXT_MAX  */
  YYSYMBOL_KW_SOURCE = 89,                 /* KW_SOURCE  */
  YYSYMBOL_KW_FILTER = 90,                 /* KW_FILTER  */
  YYSYMBOL_KW_PARSER = 91,                 /* KW_PARSER  */
  YYSYMBOL_KW_DESTINATION = 92,            /* KW_DESTINATION  */
  YYSYMBOL_KW_LOG = 93,                    /* KW_LOG  */
  YYSYMBOL_KW_OPTIONS = 94,                /* KW_OPTIONS  */
  YYSYMBOL_KW_INCLUDE = 95,                /* KW_INCLUDE  */
  YYSYMBOL_KW_BLOCK = 96,                  /* KW_BLOCK  */
  YYSYMBOL_KW_JUNCTION = 97,               /* KW_JUNCTION  */
  YYSYMBOL_KW_CHANNEL = 98,                /* KW_CHANNEL  */
  YYSYMBOL_KW_IF = 99,                     /* KW_IF  */
  YYSYMBOL_KW_ELSE = 100,                  /* KW_ELSE  */
  YYSYMBOL_KW_ELIF = 101,                  /* KW_ELIF  */
  YYSYMBOL_KW_INTERNAL = 102,              /* KW_INTERNAL  */
  YYSYMBOL_KW_SYSLOG = 103,                /* KW_SYSLOG  */
  YYSYMBOL_KW_MARK_FREQ = 104,             /* KW_MARK_FREQ  */
  YYSYMBOL_KW_STATS_FREQ = 105,            /* KW_STATS_FREQ  */
  YYSYMBOL_KW_STATS_LEVEL = 106,           /* KW_STATS_LEVEL  */
  YYSYMBOL_KW_STATS_LIFETIME = 107,        /* KW_STATS_LIFETIME  */
  YYSYMBOL_KW_FLUSH_LINES = 108,           /* KW_FLUSH_LINES  */
  YYSYMBOL_KW_SUPPRESS = 109,              /* KW_SUPPRESS  */
  YYSYMBOL_KW_FLUSH_TIMEOUT = 110,         /* KW_FLUSH_TIMEOUT  */
  YYSYMBOL_KW_LOG_MSG_SIZE = 111,          /* KW_LOG_MSG_SIZE  */
  YYSYMBOL_KW_FILE_TEMPLATE = 112,         /* KW_FILE_TEMPLATE  */
  YYSYMBOL_KW_PROTO_TEMPLATE = 113,        /* KW_PROTO_TEMPLATE  */
  YYSYMBOL_KW_MARK_MODE = 114,             /* KW_MARK_MODE  */
  YYSYMBOL_KW_ENCODING = 115,              /* KW_ENCODING  */
  YYSYMBOL_KW_TYPE = 116,                  /* KW_TYPE  */
  YYSYMBOL_KW_STATS_MAX_DYNAMIC = 117,     /* KW_STATS_MAX_DYNAMIC  */
  YYSYMBOL_KW_MIN_IW_SIZE_PER_READER = 118, /* KW_MIN_IW_SIZE_PER_READER  */
  YYSYMBOL_KW_WORKERS = 119,               /* KW_WORKERS  */
  YYSYMBOL_KW_BATCH_LINES = 120,           /* KW_BATCH_LINES  */
  YYSYMBOL_KW_BATCH_TIMEOUT = 121,         /* KW_BATCH_TIMEOUT  */
  YYSYMBOL_KW_TRIM_LARGE_MESSAGES = 122,   /* KW_TRIM_LARGE_MESSAGES  */
  YYSYMBOL_KW_CHAIN_HOSTNAMES = 123,       /* KW_CHAIN_HOSTNAMES  */
  YYSYMBOL_KW_NORMALIZE_HOSTNAMES = 124,   /* KW_NORMALIZE_HOSTNAMES  */
  YYSYMBOL_KW_KEEP_HOSTNAME = 125,         /* KW_KEEP_HOSTNAME  */
  YYSYMBOL_KW_CHECK_HOSTNAME = 126,        /* KW_CHECK_HOSTNAME  */
  YYSYMBOL_KW_BAD_HOSTNAME = 127,          /* KW_BAD_HOSTNAME  */
  YYSYMBOL_KW_LOG_LEVEL = 128,             /* KW_LOG_LEVEL  */
  YYSYMBOL_KW_KEEP_TIMESTAMP = 129,        /* KW_KEEP_TIMESTAMP  */
  YYSYMBOL_KW_USE_DNS = 130,               /* KW_USE_DNS  */
  YYSYMBOL_KW_USE_FQDN = 131,              /* KW_USE_FQDN  */
  YYSYMBOL_KW_CUSTOM_DOMAIN = 132,         /* KW_CUSTOM_DOMAIN  */
  YYSYMBOL_KW_DNS_CACHE = 133,             /* KW_DNS_CACHE  */
  YYSYMBOL_KW_DNS_CACHE_SIZE = 134,        /* KW_DNS_CACHE_SIZE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE = 135,      /* KW_DNS_CACHE_EXPIRE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE_FAILED = 136, /* KW_DNS_CACHE_EXPIRE_FAILED  */
  YYSYMBOL_KW_DNS_CACHE_HOSTS = 137,       /* KW_DNS_CACHE_HOSTS  */
  YYSYMBOL_KW_PERSIST_ONLY = 138,          /* KW_PERSIST_ONLY  */
  YYSYMBOL_KW_USE_RCPTID = 139,            /* KW_USE_RCPTID  */
  YYSYMBOL_KW_USE_UNIQID = 140,            /* KW_USE_UNIQID  */
  YYSYMBOL_KW_TZ_CONVERT = 141,            /* KW_TZ_CONVERT  */
  YYSYMBOL_KW_TS_FORMAT = 142,             /* KW_TS_FORMAT  */
  YYSYMBOL_KW_FRAC_DIGITS = 143,           /* KW_FRAC_DIGITS  */
  YYSYMBOL_KW_LOG_FIFO_SIZE = 144,         /* KW_LOG_FIFO_SIZE  */
  YYSYMBOL_KW_LOG_FETCH_LIMIT = 145,       /* KW_LOG_FETCH_LIMIT  */
  YYSYMBOL_KW_LOG_IW_SIZE = 146,           /* KW_LOG_IW_SIZE  */
  YYSYMBOL_KW_LOG_PREFIX = 147,            /* KW_LOG_PREFIX  */
  YYSYMBOL_KW_PROGRAM_OVERRIDE = 148,      /* KW_PROGRAM_OVERRIDE  */
  YYSYMBOL_KW_HOST_OVERRIDE = 149,         /* KW_HOST_OVERRIDE  */
  YYSYMBOL_KW_THROTTLE = 150,              /* KW_THROTTLE  */
  YYSYMBOL_KW_THREADED = 151,              /* KW_THREADED  */
  YYSYMBOL_KW_PASS_UNIX_CREDENTIALS = 152, /* KW_PASS_UNIX_CREDENTIALS  */
  YYSYMBOL_KW_PERSIST_NAME = 153,          /* KW_PERSIST_NAME  */
  YYSYMBOL_KW_READ_OLD_RECORDS = 154,      /* KW_READ_OLD_RECORDS  */
  YYSYMBOL_KW_USE_SYSLOGNG_PID = 155,      /* KW_USE_SYSLOGNG_PID  */
  YYSYMBOL_KW_FLAGS = 156,                 /* KW_FLAGS  */
  YYSYMBOL_KW_PAD_SIZE = 157,              /* KW_PAD_SIZE  */
  YYSYMBOL_KW_TIME_ZONE = 158,             /* KW_TIME_ZONE  */
  YYSYMBOL_KW_RECV_TIME_ZONE = 159,        /* KW_RECV_TIME_ZONE  */
  YYSYMBOL_KW_SEND_TIME_ZONE = 160,        /* KW_SEND_TIME_ZONE  */
  YYSYMBOL_KW_LOCAL_TIME_ZONE = 161,       /* KW_LOCAL_TIME_ZONE  */
  YYSYMBOL_KW_FORMAT = 162,                /* KW_FORMAT  */
  YYSYMBOL_KW_TRUNCATE_SIZE = 163,         /* KW_TRUNCATE_SIZE  */
  YYSYMBOL_KW_TIME_REOPEN = 164,           /* KW_TIME_REOPEN  */
  YYSYMBOL_KW_TIME_REAP = 165,             /* KW_TIME_REAP  */
  YYSYMBOL_KW_TIME_SLEEP = 166,            /* KW_TIME_SLEEP  */
  YYSYMBOL_KW_TMPL_ESCAPE = 167,           /* KW_TMPL_ESCAPE  */
  YYSYMBOL_KW_OPTIONAL = 168,              /* KW_OPTIONAL  */
  YYSYMBOL_KW_CREATE_DIRS = 169,           /* KW_CREATE_DIRS  */
  YYSYMBOL_KW_OWNER = 170,                 /* KW_OWNER  */
  YYSYMBOL_KW_GROUP = 171,                 /* KW_GROUP  */
  YYSYMBOL_KW_PERM = 172,                  /* KW_PERM  */
  YYSYMBOL_KW_DIR_OWNER = 173,             /* KW_DIR_OWNER  */
  YYSYMBOL_KW_DIR_GROUP = 174,             /* KW_DIR_GROUP  */
  YYSYMBOL_KW_DIR_PERM = 175,              /* KW_DIR_PERM  */
  YYSYMBOL_KW_TEMPLATE = 176,              /* KW_TEMPLATE  */
  YYSYMBOL_KW_TEMPLATE_ESCAPE = 177,       /* KW_TEMPLATE_ESCAPE  */
  YYSYMBOL_KW_TEMPLATE_FUNCTION = 178,     /* KW_TEMPLATE_FUNCTION  */
  YYSYMBOL_KW_DEFAULT_FACILITY = 179,      /* KW_DEFAULT_FACILITY  */
  YYSYMBOL_KW_DEFAULT_SEVERITY = 180,      /* KW_DEFAULT_SEVERITY  */
  YYSYMBOL_KW_PORT = 181,                  /* KW_PORT  */
  YYSYMBOL_KW_USE_TIME_RECVD = 182,        /* KW_USE_TIME_RECVD  */
  YYSYMBOL_KW_FACILITY = 183,              /* KW_FACILITY  */
  YYSYMBOL_KW_SEVERITY = 184,              /* KW_SEVERITY  */
  YYSYMBOL_KW_HOST = 185,                  /* KW_HOST  */
  YYSYMBOL_KW_MATCH = 186,                 /* KW_MATCH  */
  YYSYMBOL_KW_MESSAGE = 187,               /* KW_MESSAGE  */
  YYSYMBOL_KW_NETMASK = 188,               /* KW_NETMASK  */
  YYSYMBOL_KW_TAGS = 189,                  /* KW_TAGS  */
  YYSYMBOL_KW_NETMASK6 = 190,              /* KW_NETMASK6  */
  YYSYMBOL_KW_REWRITE = 191,               /* KW_REWRITE  */
  YYSYMBOL_KW_CONDITION = 192,             /* KW_CONDITION  */
  YYSYMBOL_KW_VALUE = 193,                 /* KW_VALUE  */
  YYSYMBOL_KW_YES = 194,                   /* KW_YES  */
  YYSYMBOL_KW_NO = 195,                    /* KW_NO  */
  YYSYMBOL_KW_IFDEF = 196,                 /* KW_IFDEF  */
  YYSYMBOL_KW_ENDIF = 197,                 /* KW_ENDIF  */
  YYSYMBOL_LL_DOTDOT = 198,                /* LL_DOTDOT  */
  YYSYMBOL_LL_DOTDOTDOT = 199,             /* LL_DOTDOTDOT  */
  YYSYMBOL_LL_PRAGMA = 200,                /* LL_PRAGMA  */
  YYSYMBOL_LL_EOL = 201,                   /* LL_EOL  */
  YYSYMBOL_LL_ERROR = 202,                 /* LL_ERROR  */
  YYSYMBOL_LL_ARROW = 203,                 /* LL_ARROW  */
  YYSYMBOL_LL_IDENTIFIER = 204,            /* LL_IDENTIFIER  */
  YYSYMBOL_LL_NUMBER = 205,                /* LL_NUMBER  */
  YYSYMBOL_LL_FLOAT = 206,                 /* LL_FLOAT  */
  YYSYMBOL_LL_STRING = 207,                /* LL_STRING  */
  YYSYMBOL_LL_TOKEN = 208,                 /* LL_TOKEN  */
  YYSYMBOL_LL_BLOCK = 209,                 /* LL_BLOCK  */
  YYSYMBOL_LL_PLUGIN = 210,                /* LL_PLUGIN  */
  YYSYMBOL_KW_VALUE_PAIRS = 211,           /* KW_VALUE_PAIRS  */
  YYSYMBOL_KW_EXCLUDE = 212,               /* KW_EXCLUDE  */
  YYSYMBOL_KW_PAIR = 213,                  /* KW_PAIR  */
  YYSYMBOL_KW_KEY = 214,                   /* KW_KEY  */
  YYSYMBOL_KW_SCOPE = 215,                 /* KW_SCOPE  */
  YYSYMBOL_KW_SHIFT = 216,                 /* KW_SHIFT  */
  YYSYMBOL_KW_SHIFT_LEVELS = 217,          /* KW_SHIFT_LEVELS  */
  YYSYMBOL_KW_REKEY = 218,                 /* KW_REKEY  */
  YYSYMBOL_KW_ADD_PREFIX = 219,            /* KW_ADD_PREFIX  */
  YYSYMBOL_KW_REPLACE_PREFIX = 220,        /* KW_REPLACE_PREFIX  */
  YYSYMBOL_KW_CAST = 221,                  /* KW_CAST  */
  YYSYMBOL_KW_ON_ERROR = 222,              /* KW_ON_ERROR  */
  YYSYMBOL_KW_RETRIES = 223,               /* KW_RETRIES  */
  YYSYMBOL_KW_FETCH_NO_DATA_DELAY = 224,   /* KW_FETCH_NO_DATA_DELAY  */
  YYSYMBOL_225_ = 225,                     /* '('  */
  YYSYMBOL_226_ = 226,                     /* ')'  */
  YYSYMBOL_227_ = 227,                     /* '{'  */
  YYSYMBOL_228_ = 228,                     /* '}'  */
  YYSYMBOL_229_ = 229,                     /* ';'  */
  YYSYMBOL_230_ = 230,                     /* ':'  */
  YYSYMBOL_YYACCEPT = 231,                 /* $accept  */
  YYSYMBOL_start = 232,                    /* start  */
  YYSYMBOL_driver = 233,                   /* driver  */
  YYSYMBOL_source_afunix = 234,            /* source_afunix  */
  YYSYMBOL_source_afunix_dgram_params = 235, /* source_afunix_dgram_params  */
  YYSYMBOL_236_1 = 236,                    /* $@1  */
  YYSYMBOL_source_afunix_stream_params = 237, /* source_afunix_stream_params  */
  YYSYMBOL_238_2 = 238,                    /* $@2  */
  YYSYMBOL_source_afunix_options = 239,    /* source_afunix_options  */
  YYSYMBOL_source_afunix_option = 240,     /* source_afunix_option  */
  YYSYMBOL_source_afinet = 241,            /* source_afinet  */
  YYSYMBOL_source_afinet_udp_params = 242, /* source_afinet_udp_params  */
  YYSYMBOL_243_3 = 243,                    /* $@3  */
  YYSYMBOL_source_afinet_udp6_params = 244, /* source_afinet_udp6_params  */
  YYSYMBOL_245_4 = 245,                    /* $@4  */
  YYSYMBOL_source_afinet_udp_options = 246, /* source_afinet_udp_options  */
  YYSYMBOL_source_afinet_udp_option = 247, /* source_afinet_udp_option  */
  YYSYMBOL_source_afinet_option = 248,     /* source_afinet_option  */
  YYSYMBOL_source_afinet_tcp_params = 249, /* source_afinet_tcp_params  */
  YYSYMBOL_250_5 = 250,                    /* $@5  */
  YYSYMBOL_source_afinet_tcp6_params = 251, /* source_afinet_tcp6_params  */
  YYSYMBOL_252_6 = 252,                    /* $@6  */
  YYSYMBOL_source_afinet_tcp_options = 253, /* source_afinet_tcp_options  */
  YYSYMBOL_source_afinet_tcp_option = 254, /* source_afinet_tcp_option  */
  YYSYMBOL_255_7 = 255,                    /* $@7  */
  YYSYMBOL_source_afsocket_stream_params = 256, /* source_afsocket_stream_params  */
  YYSYMBOL_source_afsyslog = 257,          /* source_afsyslog  */
  YYSYMBOL_source_afsyslog_params = 258,   /* source_afsyslog_params  */
  YYSYMBOL_259_8 = 259,                    /* $@8  */
  YYSYMBOL_source_afsyslog_options = 260,  /* source_afsyslog_options  */
  YYSYMBOL_source_afsyslog_option = 261,   /* source_afsyslog_option  */
  YYSYMBOL_source_afnetwork = 262,         /* source_afnetwork  */
  YYSYMBOL_source_afnetwork_params = 263,  /* source_afnetwork_params  */
  YYSYMBOL_264_9 = 264,                    /* $@9  */
  YYSYMBOL_source_afnetwork_options = 265, /* source_afnetwork_options  */
  YYSYMBOL_source_afnetwork_option = 266,  /* source_afnetwork_option  */
  YYSYMBOL_source_afsocket_transport = 267, /* source_afsocket_transport  */
  YYSYMBOL_268_10 = 268,                   /* $@10  */
  YYSYMBOL_269_11 = 269,                   /* $@11  */
  YYSYMBOL_source_systemd_syslog = 270,    /* source_systemd_syslog  */
  YYSYMBOL_source_systemd_syslog_params = 271, /* source_systemd_syslog_params  */
  YYSYMBOL_272_12 = 272,                   /* $@12  */
  YYSYMBOL_source_systemd_syslog_options = 273, /* source_systemd_syslog_options  */
  YYSYMBOL_source_systemd_syslog_option = 274, /* source_systemd_syslog_option  */
  YYSYMBOL_dest_afunix = 275,              /* dest_afunix  */
  YYSYMBOL_dest_afunix_dgram_params = 276, /* dest_afunix_dgram_params  */
  YYSYMBOL_277_13 = 277,                   /* $@13  */
  YYSYMBOL_dest_afunix_stream_params = 278, /* dest_afunix_stream_params  */
  YYSYMBOL_279_14 = 279,                   /* $@14  */
  YYSYMBOL_dest_afunix_options = 280,      /* dest_afunix_options  */
  YYSYMBOL_dest_afunix_option = 281,       /* dest_afunix_option  */
  YYSYMBOL_dest_afinet = 282,              /* dest_afinet  */
  YYSYMBOL_dest_afinet_udp_params = 283,   /* dest_afinet_udp_params  */
  YYSYMBOL_284_15 = 284,                   /* $@15  */
  YYSYMBOL_dest_afinet_udp6_params = 285,  /* dest_afinet_udp6_params  */
  YYSYMBOL_286_16 = 286,                   /* $@16  */
  YYSYMBOL_dest_afinet_udp_options = 287,  /* dest_afinet_udp_options  */
  YYSYMBOL_dest_afinet_option = 288,       /* dest_afinet_option  */
  YYSYMBOL_289_17 = 289,                   /* $@17  */
  YYSYMBOL_290_18 = 290,                   /* $@18  */
  YYSYMBOL_dest_failover_options = 291,    /* dest_failover_options  */
  YYSYMBOL_292_19 = 292,                   /* $@19  */
  YYSYMBOL_dest_failover_modes_options = 293, /* dest_failover_modes_options  */
  YYSYMBOL_dest_failback_options = 294,    /* dest_failback_options  */
  YYSYMBOL_295_20 = 295,                   /* $@20  */
  YYSYMBOL_dest_failback_probe_options = 296, /* dest_failback_probe_options  */
  YYSYMBOL_dest_failback_probe_option = 297, /* dest_failback_probe_option  */
  YYSYMBOL_dest_afinet_dgram_option = 298, /* dest_afinet_dgram_option  */
  YYSYMBOL_dest_afinet_udp_option = 299,   /* dest_afinet_udp_option  */
  YYSYMBOL_dest_afinet_tcp_params = 300,   /* dest_afinet_tcp_params  */
  YYSYMBOL_301_21 = 301,                   /* $@21  */
  YYSYMBOL_dest_afinet_tcp6_params = 302,  /* dest_afinet_tcp6_params  */
  YYSYMBOL_303_22 = 303,                   /* $@22  */
  YYSYMBOL_dest_afinet_tcp_options = 304,  /* dest_afinet_tcp_options  */
  YYSYMBOL_dest_afinet_tcp_option = 305,   /* dest_afinet_tcp_option  */
  YYSYMBOL_306_23 = 306,                   /* $@23  */
  YYSYMBOL_dest_afsocket_option = 307,     /* dest_afsocket_option  */
  YYSYMBOL_dest_afsyslog = 308,            /* dest_afsyslog  */
  YYSYMBOL_dest_afsyslog_params = 309,     /* dest_afsyslog_params  */
  YYSYMBOL_310_24 = 310,                   /* $@24  */
  YYSYMBOL_dest_afsyslog_options = 311,    /* dest_afsyslog_options  */
  YYSYMBOL_dest_afsyslog_option = 312,     /* dest_afsyslog_option  */
  YYSYMBOL_dest_afnetwork = 313,           /* dest_afnetwork  */
  YYSYMBOL_dest_afnetwork_params = 314,    /* dest_afnetwork_params  */
  YYSYMBOL_315_25 = 315,                   /* $@25  */
  YYSYMBOL_dest_afnetwork_options = 316,   /* dest_afnetwork_options  */
  YYSYMBOL_dest_afnetwork_option = 317,    /* dest_afnetwork_option  */
  YYSYMBOL_dest_afsocket_transport = 318,  /* dest_afsocket_transport  */
  YYSYMBOL_319_26 = 319,                   /* $@26  */
  YYSYMBOL_320_27 = 320,                   /* $@27  */
  YYSYMBOL_afsocket_transport = 321,       /* afsocket_transport  */
  YYSYMBOL_dest_tls_options = 322,         /* dest_tls_options  */
  YYSYMBOL_dest_tls_option = 323,          /* dest_tls_option  */
  YYSYMBOL_tls_options = 324,              /* tls_options  */
  YYSYMBOL_tls_option = 325,               /* tls_option  */
  YYSYMBOL_tls_conf_cmds = 326,            /* tls_conf_cmds  */
  YYSYMBOL_tls_conf_cmd_list_build = 327,  /* tls_conf_cmd_list_build  */
  YYSYMBOL_tls_cipher_suites = 328,        /* tls_cipher_suites  */
  YYSYMBOL_tls_cipher_suite = 329,         /* tls_cipher_suite  */
  YYSYMBOL_socket_option = 330,            /* socket_option  */
  YYSYMBOL_unix_socket_option = 331,       /* unix_socket_option  */
  YYSYMBOL_inet_socket_option = 332,       /* inet_socket_option  */
  YYSYMBOL_inet_ip_protocol_option = 333,  /* inet_ip_protocol_option  */
  YYSYMBOL_string = 334,                   /* string  */
  YYSYMBOL_yesno = 335,                    /* yesno  */
  YYSYMBOL_dnsmode = 336,                  /* dnsmode  */
  YYSYMBOL_nonnegative_integer64 = 337,    /* nonnegative_integer64  */
  YYSYMBOL_nonnegative_integer = 338,      /* nonnegative_integer  */
  YYSYMBOL_positive_integer64 = 339,       /* positive_integer64  */
  YYSYMBOL_positive_integer = 340,         /* positive_integer  */
  YYSYMBOL_nonnegative_float = 341,        /* nonnegative_float  */
  YYSYMBOL_string_or_number = 342,         /* string_or_number  */
  YYSYMBOL_path = 343,                     /* path  */
  YYSYMBOL_path_check = 344,               /* path_check  */
  YYSYMBOL_path_secret = 345,              /* path_secret  */
  YYSYMBOL_normalized_flag = 346,          /* normalized_flag  */
  YYSYMBOL_string_list = 347,              /* string_list  */
  YYSYMBOL_string_list_build = 348,        /* string_list_build  */
  YYSYMBOL_severity_string = 349,          /* severity_string  */
  YYSYMBOL_facility_string = 350,          /* facility_string  */
  YYSYMBOL_driver_option = 351,            /* driver_option  */
  YYSYMBOL_inner_source = 352,             /* inner_source  */
  YYSYMBOL_source_driver_option = 353,     /* source_driver_option  */
  YYSYMBOL_inner_dest = 354,               /* inner_dest  */
  YYSYMBOL_dest_driver_option = 355,       /* dest_driver_option  */
  YYSYMBOL_source_option = 356,            /* source_option  */
  YYSYMBOL_357_32 = 357,                   /* $@32  */
  YYSYMBOL_source_reader_option = 358,     /* source_reader_option  */
  YYSYMBOL_359_33 = 359,                   /* $@33  */
  YYSYMBOL_360_34 = 360,                   /* $@34  */
  YYSYMBOL_361_35 = 361,                   /* $@35  */
  YYSYMBOL_source_reader_option_flags = 362, /* source_reader_option_flags  */
  YYSYMBOL_source_proto_option = 363,      /* source_proto_option  */
  YYSYMBOL_host_resolve_option = 364,      /* host_resolve_option  */
  YYSYMBOL_msg_format_option = 365,        /* msg_format_option  */
  YYSYMBOL_dest_writer_option = 366,       /* dest_writer_option  */
  YYSYMBOL_367_36 = 367,                   /* $@36  */
  YYSYMBOL_dest_writer_options_flags = 368, /* dest_writer_options_flags  */
  YYSYMBOL_file_perm_option = 369,         /* file_perm_option  */
  YYSYMBOL_template_option = 370,          /* template_option  */
  YYSYMBOL__inner_dest_context_push = 371, /* _inner_dest_context_push  */
  YYSYMBOL__inner_dest_context_pop = 372,  /* _inner_dest_context_pop  */
  YYSYMBOL__inner_src_context_push = 373,  /* _inner_src_context_push  */
  YYSYMBOL__inner_src_context_pop = 374    /* _inner_src_context_pop  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;



/* Unqualified %code blocks.  */
#line 30 "modules/afsocket/afsocket-grammar.y"


#include "afsocket.h"
#include "cfg-parser.h"
#include "afunix-source.h"
#include "afunix-dest.h"
#include "afinet-source.h"
#include "afinet-dest.h"
#include "messages.h"
#include "syslog-names.h"
#include "plugin.h"
#include "cfg-grammar-internal.h"
#include "socket-options-inet.h"
#include "socket-options-unix.h"
#include "transport-mapper-inet.h"
#include "service-management.h"

#include "systemd-syslog-source.h"
#include "afsocket-systemd-override.h"

#include "tlscontext.h"


static SocketOptions *last_sock_options;
static TransportMapper *last_transport_mapper;

TLSContext *last_tls_context;


#if ! SYSLOG_NG_ENABLE_IPV6
#undef AF_INET6
#define AF_INET6 0; g_assert_not_reached()

#endif

static void
afsocket_grammar_set_source_driver(AFSocketSourceDriver *sd)
{
  last_driver = &sd->super.super;

  last_reader_options = &((AFSocketSourceDriver *) last_driver)->reader_options;
  last_sock_options = ((AFSocketSourceDriver *) last_driver)->socket_options;
  last_transport_mapper = ((AFSocketSourceDriver *) last_driver)->transport_mapper;
  last_proto_server_options = &last_reader_options->proto_options.super;
}

static void
afsocket_grammar_set_dest_driver(AFSocketDestDriver *dd)
{
  last_driver = &dd->super.super;

  last_writer_options = &((AFSocketDestDriver *) last_driver)->writer_options;
  last_sock_options = ((AFSocketDestDriver *) last_driver)->socket_options;
  last_transport_mapper = ((AFSocketDestDriver *) last_driver)->transport_mapper;
  last_proto_client_options = &last_writer_options->proto_options.super;
}

void
afunix_grammar_set_source_driver(AFUnixSourceDriver *sd)
{
  afsocket_grammar_set_source_driver(&sd->super);
  last_file_perm_options = &sd->file_perm_options;
}

static void
afinet_grammar_set_source_driver(AFInetSourceDriver *sd)
{
  afsocket_grammar_set_source_driver(&sd->super);
}

static void
afunix_grammar_set_dest_driver(AFUnixDestDriver *dd)
{
  afsocket_grammar_set_dest_driver(&dd->super);
}

static void
afinet_grammar_set_dest_driver(AFInetDestDriver *dd)
{
  afsocket_grammar_set_dest_driver(&dd->super);
}

void
systemd_syslog_grammar_set_source_driver(SystemDSyslogSourceDriver *sd)
{
  afsocket_grammar_set_source_driver(&sd->super);
}

#line 210 "modules/afsocket/afsocket-grammar.y"


# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
  do {                                                                  \
    if (N)                                                              \
      {                                                                 \
        (Current).level = YYRHSLOC(Rhs, 1).level;                       \
        (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;          \
        (Current).first_column = YYRHSLOC (Rhs, 1).first_column;        \
        (Current).last_line    = YYRHSLOC (Rhs, N).last_line;           \
        (Current).last_column  = YYRHSLOC (Rhs, N).last_column;         \
      }                                                                 \
    else                                                                \
      {                                                                 \
        (Current).level = YYRHSLOC(Rhs, 0).level;                       \
        (Current).first_line   = (Current).last_line   =                \
          YYRHSLOC (Rhs, 0).last_line;                                  \
        (Current).first_column = (Current).last_column =                \
          YYRHSLOC (Rhs, 0).last_column;                                \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_WITHOUT_MESSAGE(val, token) do {                    \
    if (!(val))                                                         \
      {                                                                 \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR(val, token, errorfmt, ...) do {                     \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt, ## __VA_ARGS__); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_GERROR(val, token, error, errorfmt, ...) do {       \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt ", error=%s", ## __VA_ARGS__, error->message); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        g_clear_error(&error);						\
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define YYMAXDEPTH 20000



#line 1140 "modules/afsocket/afsocket-grammar.c"

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined AFSOCKET_LTYPE_IS_TRIVIAL && AFSOCKET_LTYPE_IS_TRIVIAL \
             && defined AFSOCKET_STYPE_IS_TRIVIAL && AFSOCKET_STYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  31
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1624

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  231
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  144
/* YYNRULES -- Number of rules.  */
#define YYNRULES  333
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  788

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   20065


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    88,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     225,   226,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   230,   229,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   227,     2,   228,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
      99,   100,   101,     2,     2,     2,     2,     2,     2,     2,
     102,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     103,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   104,   105,   106,   107,   108,   109,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,     2,     2,     2,     2,
     129,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     130,   131,   132,     2,     2,     2,     2,     2,     2,     2,
     133,   134,     2,     2,     2,     2,     2,     2,     2,     2,
     135,   136,   137,     2,     2,     2,     2,     2,     2,     2,
     138,   139,   140,     2,     2,     2,     2,     2,     2,     2,
     141,   142,   143,     2,     2,     2,     2,     2,     2,     2,
     144,     2,   145,   146,   147,   148,   149,     2,     2,     2,
     150,   151,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     156,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     157,   158,   159,   160,   161,   162,   163,     2,     2,     2,
     164,   165,   166,     2,     2,     2,     2,     2,     2,     2,
     167,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     168,   152,     2,     2,     2,     2,     2,     2,     2,     2,
     169,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     170,   171,   172,     2,     2,     2,     2,     2,     2,     2,
     173,   174,   175,     2,     2,     2,     2,     2,     2,     2,
     176,   177,   178,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     179,   180,   153,     2,   154,   155,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   181,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     182,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     183,   184,   185,   186,   187,   188,   189,   190,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     191,   192,   193,     2,     2,     2,     2,     2,     2,     2,
     194,   195,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     196,   197,     2,     2,     2,     2,     2,     2,     2,     2,
     198,   199,   200,   201,   202,   203,     2,     2,     2,     2,
     204,   205,   206,   207,   208,   209,   210,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     211,     2,   212,   213,   214,   215,   216,   217,   218,   219,
     220,   221,     2,     2,     2,     2,     2,     2,     2,     2,
     222,   223,   224,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       3,     2,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67
};

#if AFSOCKET_DEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   595,   595,   605,   606,   607,   608,   609,   610,   611,
     612,   613,   618,   619,   624,   623,   632,   631,   640,   641,
     645,   646,   647,   648,   649,   650,   651,   656,   664,   665,
     666,   667,   672,   672,   682,   682,   691,   692,   696,   700,
     701,   702,   703,   704,   705,   706,   711,   711,   721,   721,
     730,   731,   735,   737,   736,   746,   750,   751,   752,   753,
     754,   755,   759,   764,   764,   774,   775,   779,   780,   781,
     785,   790,   790,   800,   801,   805,   806,   807,   811,   813,
     812,   831,   830,   843,   847,   847,   862,   863,   867,   868,
     869,   873,   874,   879,   878,   889,   888,   898,   899,   903,
     904,   905,   906,   910,   911,   912,   913,   918,   917,   928,
     927,   938,   939,   944,   945,   946,   947,   948,   948,   949,
     949,   950,   951,   952,   953,   957,   957,   961,   962,   966,
     966,   970,   971,   975,   976,   980,   981,   985,   986,   991,
     990,  1001,  1000,  1010,  1011,  1015,  1017,  1016,  1028,  1029,
    1038,  1042,  1041,  1052,  1053,  1057,  1058,  1062,  1067,  1066,
    1076,  1077,  1081,  1082,  1086,  1088,  1087,  1105,  1107,  1106,
    1119,  1120,  1121,  1122,  1126,  1127,  1131,  1132,  1137,  1144,
    1145,  1149,  1152,  1157,  1163,  1168,  1174,  1179,  1184,  1189,
    1194,  1199,  1204,  1208,  1212,  1213,  1219,  1225,  1231,  1236,
    1241,  1245,  1250,  1255,  1262,  1272,  1278,  1279,  1283,  1288,
    1297,  1302,  1307,  1308,  1309,  1313,  1314,  1318,  1319,  1320,
    1321,  1322,  1323,  1328,  1333,  1341,  1622,  1623,  1627,  1628,
    1629,  1633,  1634,  1638,  1645,  1652,  1659,  1666,  1670,  1688,
    1689,  1690,  1694,  1704,  1708,  1716,  1720,  1724,  1725,  1734,
    1745,  1753,  1769,  1773,  1799,  1800,  1804,  1832,  1833,  1834,
    1835,  1883,  1884,  1885,  1886,  1887,  1888,  1889,  1890,  1891,
    1892,  1893,  1893,  1900,  1901,  1902,  1903,  1904,  1904,  1905,
    1905,  1906,  1906,  1910,  1911,  1912,  1917,  1924,  1925,  1929,
    1930,  1931,  1932,  1936,  1937,  1943,  1959,  1960,  1961,  1962,
    1963,  1970,  1971,  1972,  1973,  1974,  1975,  1981,  1982,  1982,
    1986,  1987,  1991,  1992,  1993,  1994,  1995,  1996,  1997,  1998,
    1999,  2000,  2001,  2002,  2006,  2007,  2008,  2009,  2010,  2011,
    2145,  2146,  2147,  2148
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "KW_UNIX_STREAM",
  "KW_UNIX_DGRAM", "KW_TCP", "KW_UDP", "KW_TCP6", "KW_UDP6", "KW_NETWORK",
  "KW_TRANSPORT", "KW_IP_PROTOCOL", "KW_SYSTEMD_SYSLOG", "KW_IP_TTL",
  "KW_SO_BROADCAST", "KW_IP_TOS", "KW_IP_FREEBIND", "KW_SO_SNDBUF",
  "KW_SO_RCVBUF", "KW_SO_KEEPALIVE", "KW_SO_REUSEPORT",
  "KW_TCP_KEEPALIVE_TIME", "KW_TCP_KEEPALIVE_PROBES",
  "KW_TCP_KEEPALIVE_INTVL", "KW_SO_PASSCRED", "KW_LISTEN_BACKLOG",
  "KW_SPOOF_SOURCE", "KW_SPOOF_SOURCE_MAX_MSGLEN", "KW_KEEP_ALIVE",
  "KW_MAX_CONNECTIONS", "KW_CLOSE_ON_INPUT", "KW_LOCALIP", "KW_IP",
  "KW_INTERFACE", "KW_LOCALPORT", "KW_DESTPORT", "KW_FAILOVER_SERVERS",
  "KW_FAILOVER", "KW_SERVERS", "KW_FAILBACK", "KW_TCP_PROBE_INTERVAL",
  "KW_SUCCESSFUL_PROBES_REQUIRED", "KW_DYNAMIC_WINDOW_SIZE",
  "KW_DYNAMIC_WINDOW_STATS_FREQ", "KW_DYNAMIC_WINDOW_REALLOC_TICKS",
  "KW_TLS", "KW_PEER_VERIFY", "KW_KEY_FILE", "KW_CERT_FILE",
  "KW_DHPARAM_FILE", "KW_PKCS12_FILE", "KW_CA_DIR", "KW_CRL_DIR",
  "KW_CA_FILE", "KW_TRUSTED_KEYS", "KW_TRUSTED_DN", "KW_CIPHER_SUITE",
  "KW_TLS12_AND_OLDER", "KW_TLS13", "KW_SIGALGS", "KW_CLIENT_SIGALGS",
  "KW_ECDH_CURVE_LIST", "KW_SSL_OPTIONS", "KW_SNI", "KW_ALLOW_COMPRESS",
  "KW_KEYLOG_FILE", "KW_OCSP_STAPLING_VERIFY", "KW_CONF_CMDS",
  "LL_CONTEXT_ROOT", "LL_CONTEXT_DESTINATION", "LL_CONTEXT_SOURCE",
  "LL_CONTEXT_PARSER", "LL_CONTEXT_REWRITE", "LL_CONTEXT_FILTER",
  "LL_CONTEXT_LOG", "LL_CONTEXT_BLOCK_DEF", "LL_CONTEXT_BLOCK_REF",
  "LL_CONTEXT_BLOCK_CONTENT", "LL_CONTEXT_BLOCK_ARG", "LL_CONTEXT_PRAGMA",
  "LL_CONTEXT_FORMAT", "LL_CONTEXT_TEMPLATE_FUNC", "LL_CONTEXT_INNER_DEST",
  "LL_CONTEXT_INNER_SRC", "LL_CONTEXT_CLIENT_PROTO",
  "LL_CONTEXT_SERVER_PROTO", "LL_CONTEXT_OPTIONS", "LL_CONTEXT_CONFIG",
  "LL_CONTEXT_MAX", "KW_SOURCE", "KW_FILTER", "KW_PARSER",
  "KW_DESTINATION", "KW_LOG", "KW_OPTIONS", "KW_INCLUDE", "KW_BLOCK",
  "KW_JUNCTION", "KW_CHANNEL", "KW_IF", "KW_ELSE", "KW_ELIF",
  "KW_INTERNAL", "KW_SYSLOG", "KW_MARK_FREQ", "KW_STATS_FREQ",
  "KW_STATS_LEVEL", "KW_STATS_LIFETIME", "KW_FLUSH_LINES", "KW_SUPPRESS",
  "KW_FLUSH_TIMEOUT", "KW_LOG_MSG_SIZE", "KW_FILE_TEMPLATE",
  "KW_PROTO_TEMPLATE", "KW_MARK_MODE", "KW_ENCODING", "KW_TYPE",
  "KW_STATS_MAX_DYNAMIC", "KW_MIN_IW_SIZE_PER_READER", "KW_WORKERS",
  "KW_BATCH_LINES", "KW_BATCH_TIMEOUT", "KW_TRIM_LARGE_MESSAGES",
  "KW_CHAIN_HOSTNAMES", "KW_NORMALIZE_HOSTNAMES", "KW_KEEP_HOSTNAME",
  "KW_CHECK_HOSTNAME", "KW_BAD_HOSTNAME", "KW_LOG_LEVEL",
  "KW_KEEP_TIMESTAMP", "KW_USE_DNS", "KW_USE_FQDN", "KW_CUSTOM_DOMAIN",
  "KW_DNS_CACHE", "KW_DNS_CACHE_SIZE", "KW_DNS_CACHE_EXPIRE",
  "KW_DNS_CACHE_EXPIRE_FAILED", "KW_DNS_CACHE_HOSTS", "KW_PERSIST_ONLY",
  "KW_USE_RCPTID", "KW_USE_UNIQID", "KW_TZ_CONVERT", "KW_TS_FORMAT",
  "KW_FRAC_DIGITS", "KW_LOG_FIFO_SIZE", "KW_LOG_FETCH_LIMIT",
  "KW_LOG_IW_SIZE", "KW_LOG_PREFIX", "KW_PROGRAM_OVERRIDE",
  "KW_HOST_OVERRIDE", "KW_THROTTLE", "KW_THREADED",
  "KW_PASS_UNIX_CREDENTIALS", "KW_PERSIST_NAME", "KW_READ_OLD_RECORDS",
  "KW_USE_SYSLOGNG_PID", "KW_FLAGS", "KW_PAD_SIZE", "KW_TIME_ZONE",
  "KW_RECV_TIME_ZONE", "KW_SEND_TIME_ZONE", "KW_LOCAL_TIME_ZONE",
  "KW_FORMAT", "KW_TRUNCATE_SIZE", "KW_TIME_REOPEN", "KW_TIME_REAP",
  "KW_TIME_SLEEP", "KW_TMPL_ESCAPE", "KW_OPTIONAL", "KW_CREATE_DIRS",
  "KW_OWNER", "KW_GROUP", "KW_PERM", "KW_DIR_OWNER", "KW_DIR_GROUP",
  "KW_DIR_PERM", "KW_TEMPLATE", "KW_TEMPLATE_ESCAPE",
  "KW_TEMPLATE_FUNCTION", "KW_DEFAULT_FACILITY", "KW_DEFAULT_SEVERITY",
  "KW_PORT", "KW_USE_TIME_RECVD", "KW_FACILITY", "KW_SEVERITY", "KW_HOST",
  "KW_MATCH", "KW_MESSAGE", "KW_NETMASK", "KW_TAGS", "KW_NETMASK6",
  "KW_REWRITE", "KW_CONDITION", "KW_VALUE", "KW_YES", "KW_NO", "KW_IFDEF",
  "KW_ENDIF", "LL_DOTDOT", "LL_DOTDOTDOT", "LL_PRAGMA", "LL_EOL",
  "LL_ERROR", "LL_ARROW", "LL_IDENTIFIER", "LL_NUMBER", "LL_FLOAT",
  "LL_STRING", "LL_TOKEN", "LL_BLOCK", "LL_PLUGIN", "KW_VALUE_PAIRS",
  "KW_EXCLUDE", "KW_PAIR", "KW_KEY", "KW_SCOPE", "KW_SHIFT",
  "KW_SHIFT_LEVELS", "KW_REKEY", "KW_ADD_PREFIX", "KW_REPLACE_PREFIX",
  "KW_CAST", "KW_ON_ERROR", "KW_RETRIES", "KW_FETCH_NO_DATA_DELAY", "'('",
  "')'", "'{'", "'}'", "';'", "':'", "$accept", "start", "driver",
  "source_afunix", "source_afunix_dgram_params", "$@1",
  "source_afunix_stream_params", "$@2", "source_afunix_options",
  "source_afunix_option", "source_afinet", "source_afinet_udp_params",
  "$@3", "source_afinet_udp6_params", "$@4", "source_afinet_udp_options",
  "source_afinet_udp_option", "source_afinet_option",
  "source_afinet_tcp_params", "$@5", "source_afinet_tcp6_params", "$@6",
  "source_afinet_tcp_options", "source_afinet_tcp_option", "$@7",
  "source_afsocket_stream_params", "source_afsyslog",
  "source_afsyslog_params", "$@8", "source_afsyslog_options",
  "source_afsyslog_option", "source_afnetwork", "source_afnetwork_params",
  "$@9", "source_afnetwork_options", "source_afnetwork_option",
  "source_afsocket_transport", "$@10", "$@11", "source_systemd_syslog",
  "source_systemd_syslog_params", "$@12", "source_systemd_syslog_options",
  "source_systemd_syslog_option", "dest_afunix",
  "dest_afunix_dgram_params", "$@13", "dest_afunix_stream_params", "$@14",
  "dest_afunix_options", "dest_afunix_option", "dest_afinet",
  "dest_afinet_udp_params", "$@15", "dest_afinet_udp6_params", "$@16",
  "dest_afinet_udp_options", "dest_afinet_option", "$@17", "$@18",
  "dest_failover_options", "$@19", "dest_failover_modes_options",
  "dest_failback_options", "$@20", "dest_failback_probe_options",
  "dest_failback_probe_option", "dest_afinet_dgram_option",
  "dest_afinet_udp_option", "dest_afinet_tcp_params", "$@21",
  "dest_afinet_tcp6_params", "$@22", "dest_afinet_tcp_options",
  "dest_afinet_tcp_option", "$@23", "dest_afsocket_option",
  "dest_afsyslog", "dest_afsyslog_params", "$@24", "dest_afsyslog_options",
  "dest_afsyslog_option", "dest_afnetwork", "dest_afnetwork_params",
  "$@25", "dest_afnetwork_options", "dest_afnetwork_option",
  "dest_afsocket_transport", "$@26", "$@27", "afsocket_transport",
  "dest_tls_options", "dest_tls_option", "tls_options", "tls_option",
  "tls_conf_cmds", "tls_conf_cmd_list_build", "tls_cipher_suites",
  "tls_cipher_suite", "socket_option", "unix_socket_option",
  "inet_socket_option", "inet_ip_protocol_option", "string", "yesno",
  "dnsmode", "nonnegative_integer64", "nonnegative_integer",
  "positive_integer64", "positive_integer", "nonnegative_float",
  "string_or_number", "path", "path_check", "path_secret",
  "normalized_flag", "string_list", "string_list_build", "severity_string",
  "facility_string", "driver_option", "inner_source",
  "source_driver_option", "inner_dest", "dest_driver_option",
  "source_option", "$@32", "source_reader_option", "$@33", "$@34", "$@35",
  "source_reader_option_flags", "source_proto_option",
  "host_resolve_option", "msg_format_option", "dest_writer_option", "$@36",
  "dest_writer_options_flags", "file_perm_option", "template_option",
  "_inner_dest_context_push", "_inner_dest_context_pop",
  "_inner_src_context_push", "_inner_src_context_pop", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-576)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-282)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     124,   345,   321,    14,  -576,  -195,  -189,  -158,  -155,  -149,
    -144,  -127,  -124,  -576,  -576,  -576,  -576,  -114,  -108,   -78,
     -59,   -53,     3,    16,    19,    22,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -146,
    -146,  -146,  -146,  -146,  -146,  -146,  -146,  -146,  -146,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  1214,
    -576,  1251,  -576,  1214,  -576,  1251,  -576,   565,  -576,     5,
    -576,   602,  -133,  -576,   -93,  -576,   -86,  -576,    13,  -576,
      25,  -576,    29,  -576,    31,  -576,    33,  -576,    39,  1175,
      52,  1175,    63,    24,    65,    67,    73,    85,    86,    90,
      93,   109,   118,   119,   134,   141,   143,   147,   148,   149,
     154,   155,   161,   164,  -576,   166,   168,   173,   178,   190,
     191,  -576,  -576,  -576,  1214,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,   258,    49,   -51,   200,  -576,  1251,  -576,   202,
    -576,   206,  -576,   208,   213,   226,  -576,  -576,  -576,  -576,
     565,  -576,  -576,   214,  -576,     5,  -576,  -576,  -576,   220,
    -576,  -576,  -576,   602,  -576,  -576,  1361,  -576,  1398,  -576,
     996,  -576,   780,  -576,  1034,  -576,   818,  -576,    69,  -576,
     286,  -576,   228,   231,   240,   255,   257,   259,   270,   272,
     273,   274,  -576,  1175,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,    88,   -13,    88,   -13,    88,    88,   -13,
     -13,    88,    88,    88,    89,   -13,    89,  -146,  -146,  -146,
     254,    88,    12,    88,   275,   -13,    89,  -146,   -72,  -146,
     254,  -576,   288,   293,   298,   301,   302,   304,   309,   310,
     311,   348,  -576,   278,   349,   352,   364,  -576,   366,   367,
     370,  -576,  -576,  -576,  -576,  -576,  -576,    23,   247,   375,
    -576,  -576,  -576,  -576,  -576,   376,   377,   379,   380,   381,
     386,   389,   401,   403,   404,   407,   412,   413,   414,   415,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,   -83,   416,
     417,   418,  -576,  -576,  -576,   423,  -576,  -576,  -576,  -576,
    -576,  -576,   424,   425,  -576,  -576,  -576,   428,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,   -13,   -13,   -13,
     -13,   135,   158,   -71,   171,   215,   -35,  -576,  -576,  -576,
     344,  -576,  -576,  -576,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,  -576,  -576,   439,   440,   441,   442,
     443,   444,  -576,  -576,  -576,   445,   446,  -576,  -576,   447,
     448,   455,   449,   451,   453,   -72,   -72,   456,   457,   458,
     -13,   -13,   -13,    89,  -146,  -146,  -146,   -13,   -13,  -146,
     460,   461,   463,   464,  -576,    89,  -146,   -13,  -146,   -85,
    -146,   466,   467,   468,  -576,  -576,   469,   455,   -13,   -13,
      88,    88,    88,    89,   -92,    89,    88,  -146,    88,    88,
      89,  -146,   -13,   465,   471,   474,   475,   476,   477,  -576,
    -146,   254,   254,   478,   479,   480,   254,   -13,    89,    23,
     481,   482,   485,   486,   488,  -576,   490,  -576,   493,   494,
    -576,  -576,   496,  -576,   499,   500,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,   504,   505,
     506,   507,   508,   509,   510,   511,   512,   514,   515,   516,
     517,   518,   523,   524,   525,   526,  -576,  -576,   527,   455,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,   528,   530,
     531,   533,   535,   536,   537,   539,   540,  -146,   541,  -576,
     -13,   -69,   -13,   -13,   542,   543,   544,   545,  -576,  -576,
     546,  -576,   547,  -576,  -576,  -576,   548,  -576,   550,   551,
     552,   553,   554,   558,   559,   560,   561,   562,   563,  -576,
    -146,   564,   566,   578,   579,   583,   592,  -146,    88,  -146,
    -146,  -146,  -146,   593,   594,   595,  -146,   142,   221,   596,
     597,   598,  -576,   221,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,   250,  -146,  -146,  -146,  -146,  -146,
    -146,  -146,  -146,  -146,   -45,  -146,  -146,  -146,  -146,   -13,
    -146,  -146,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,   599,  -576,  -576,   600,   601,
     603,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,   604,   616,   617,   621,
     624,   630,  -576,  -576,  -576,   631,   633,   634,   636,   637,
     638,   221,  -576,  -576,  -576,  -576,   639,   640,   641,   642,
    -576,  -576,   643,  -576,   644,   645,   646,   647,   648,   649,
     650,   651,   653,   654,   655,   163,   656,   657,   659,   660,
     661,   665,   666,   667,  -576,   400,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -146,  -576,   -13,
     -13,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -146,  -146,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -146,   669,
     670,   671,   672,   673,  -146,  -576,  -576,  -576,  -576,  -576,
    -576,   615,  -576,  -576,  -576,   675,  -576,   -25,   676,   677,
    -576,  -576,    89,    89,   678,   679,  -576,  -576
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
       0,     0,     0,     0,     2,     0,     0,     0,     0,     0,
       0,     0,     0,     8,     9,    10,    11,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     3,     4,     5,     6,
       7,     1,   330,   330,   330,   330,   330,   330,   330,   330,
     332,   332,   332,   332,   332,   332,   332,   332,   332,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    46,
      32,    48,    34,    71,    84,    63,   226,   227,   331,    95,
     331,    93,   331,   139,   331,   107,   331,   141,   331,   109,
     331,   158,   331,   151,   333,    16,   333,    14,   333,   277,
     333,   277,   333,   277,   333,   277,   333,   277,   333,   277,
     333,   277,     0,    98,     0,    98,     0,   144,     0,   112,
       0,   144,     0,   112,     0,   161,     0,   154,     0,   277,
       0,   277,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    53,     0,     0,     0,     0,     0,
       0,   253,    52,    47,   277,    55,   217,    45,   255,   254,
      44,    43,   271,     0,     0,     0,    33,   277,    38,     0,
      49,     0,    35,     0,     0,     0,    81,    75,    77,    72,
     277,    76,    78,     0,    85,   277,    89,    90,    88,     0,
      67,    69,    64,   277,    68,    92,   308,    91,   308,   104,
     308,   103,   308,   106,   308,   105,   308,   157,   308,   150,
     308,    13,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    17,   277,    21,   215,    24,    23,    22,    20,
      12,    15,    29,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   285,     0,
       0,    50,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   278,     0,     0,     0,     0,   280,     0,     0,
       0,   282,    28,    36,    31,    30,    70,     0,     0,     0,
      73,    83,    86,    62,    65,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     256,    97,   100,   101,   260,   259,   102,    99,     0,     0,
       0,     0,   117,   119,   146,     0,   145,   143,   123,   121,
     124,   122,     0,     0,   137,   138,   111,     0,   168,   162,
     167,   160,   163,   164,   155,   153,   156,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    18,   233,   234,
       0,   228,   229,   230,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   235,   236,     0,     0,     0,     0,
       0,     0,   240,   241,   239,     0,     0,   237,   238,     0,
       0,   180,     0,     0,     0,   285,   285,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   248,
       0,     0,     0,     0,   272,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    79,   225,     0,   180,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   311,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   309,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   313,     0,   315,     0,     0,
     317,   319,     0,   321,     0,     0,   323,   218,   212,   219,
     220,   210,   211,   213,   214,   222,   224,   223,    58,    56,
      57,    39,    40,   221,    41,    59,    60,    61,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   181,   202,     0,   180,
     273,   275,   252,   284,   283,   274,   276,    42,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   248,     0,   246,
       0,     0,     0,     0,     0,     0,     0,     0,   251,   250,
       0,   249,     0,   170,   171,   172,     0,   173,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   245,
     311,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   248,     0,   175,     0,
       0,     0,   165,   175,   216,    26,    25,    27,   312,   314,
     316,   318,   320,   322,     0,     0,     0,     0,     0,     0,
       0,     0,   248,   248,   207,     0,     0,     0,   248,     0,
       0,   205,    54,   179,   262,   263,   267,   261,   266,   264,
     265,   268,   269,   247,   270,     0,   232,   231,     0,     0,
       0,   287,   286,   288,   293,   295,   294,    80,    82,   148,
     149,   304,   297,   299,   298,   305,   306,   257,   258,   310,
     296,   302,   303,   307,   300,   301,     0,     0,     0,     0,
       0,     0,   113,   114,   116,     0,     0,     0,     0,     0,
       0,   175,   176,   115,   135,   136,     0,     0,     0,     0,
     242,   244,     0,   243,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   207,     0,     0,     0,     0,
       0,     0,     0,     0,   203,     0,   292,   290,   289,   291,
     324,   325,   326,   327,   328,   329,   118,   248,   120,     0,
       0,   147,   174,   166,   169,   183,   182,   184,   186,   187,
     188,   189,   190,   191,   192,   193,     0,     0,   194,   206,
     195,   196,   197,   198,   199,   200,   185,   201,     0,     0,
       0,     0,     0,     0,   205,   125,   177,   178,   208,   209,
     204,   128,   129,   126,   127,     0,   132,     0,     0,     0,
     130,   131,     0,     0,     0,     0,   133,   134
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -576,  -100,  -576,
    -576,  -576,  -576,  -576,  -576,   -46,  -576,   165,  -576,  -576,
    -576,  -576,   -60,  -576,  -576,    68,  -576,  -576,  -576,   687,
    -576,  -576,  -576,  -576,   501,  -576,   -75,  -576,  -576,  -576,
    -576,  -576,   522,  -576,  -576,  -576,  -576,  -576,  -576,   754,
    -576,  -576,  -576,  -576,  -576,  -576,   625,   284,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,  -145,  -576,  -576,
    -576,  -576,  -576,   752,  -576,  -576,   -50,  -576,  -576,  -576,
    -576,  -576,  -576,  -576,  -576,  -576,  -576,   693,  -576,  -576,
     -20,  -573,  -576,  -395,  -540,  -576,   -12,   201,  -576,   -47,
    -576,   283,  -576,   -49,  -205,  -576,  -576,  -196,  -576,  -229,
    -576,  -198,   303,  -498,  -576,  -576,  -575,   372,  -576,  -576,
     227,  -576,   -55,  -576,     9,  -576,  -576,   -48,  -576,  -576,
    -576,  -132,  -576,  -576,  -576,    18,  -576,   337,  -576,  -576,
     513,   399,   497,   378
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     3,     4,    26,    86,   121,    84,   119,   222,   223,
      27,    90,    91,    94,    95,   166,   167,   152,    88,    89,
      92,    93,   153,   154,   254,   155,    28,   100,   101,   192,
     193,    29,    96,    97,   179,   180,   181,   556,   289,    30,
      98,    99,   184,   185,    13,    70,   105,    68,   103,   196,
     311,    14,    74,   109,    78,   113,   202,   326,   453,   454,
     677,   771,   773,   774,   775,   777,   781,   335,   336,    72,
     107,    76,   111,   200,   327,   455,   328,    15,    82,   117,
     210,   345,    16,    80,   115,   208,   341,   342,   686,   460,
     182,   680,   681,   518,   519,   713,   714,   704,   705,   156,
     226,   157,   426,   384,   364,   638,   359,   360,   375,   376,
     389,   385,   693,   694,   692,   570,   538,   539,   552,   550,
     158,   159,   160,   315,   330,   272,   273,   161,   162,   163,
     164,   397,   277,   414,   281,   331,   318,   571,   229,   449,
      49,   102,    57,   118
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      69,    71,    73,    75,    77,    79,    81,    83,    85,    87,
     565,   675,   702,   703,    31,   778,   779,   378,   548,   124,
     687,   231,   127,   128,   129,   130,   194,   393,   421,   422,
      32,   366,   558,   170,   369,   370,    33,   700,   701,   365,
     377,   367,   368,   710,   187,   371,   372,   373,   682,   172,
     392,   188,   186,   682,   395,   386,   388,   390,    66,   443,
     444,    67,   399,   340,   227,   340,   227,    34,   423,   636,
      35,   228,   225,   228,   225,   445,    36,   446,   447,   337,
     175,    37,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   132,   133,   195,   261,   332,   333,   295,    38,   296,
     319,    39,   139,   320,   321,   322,   323,   278,   732,   695,
     696,    40,    66,   699,   338,    67,  -279,    41,   194,    66,
    -279,   283,    67,   357,   623,   361,   362,  -279,   279,   280,
     187,   145,    66,   197,   469,    67,   363,   188,   186,   448,
     199,   682,   461,   462,   463,   464,   312,    42,   312,   313,
     146,   313,   759,   466,   468,   470,   472,   474,   147,    66,
     274,   148,    67,  -281,   275,   178,    43,   149,   227,   191,
     475,   276,    44,   297,   531,   228,   225,   298,   299,   300,
     676,   361,   362,   301,  -281,  -281,   544,   224,   343,   224,
     343,   476,   363,     1,     2,   528,   529,   530,   379,   380,
     381,   780,   535,   536,   564,   316,   567,   316,   394,   396,
     398,   574,   546,   302,   317,   151,   317,   358,   387,   303,
     702,   703,   147,   559,   560,   304,   305,    66,    45,   591,
      67,   -87,   306,   307,   561,   562,   563,   576,   424,   201,
     568,    46,   572,   573,    47,   308,   309,    48,   178,   233,
     325,   203,   590,   584,   585,   205,   168,   207,   589,   209,
     168,   191,   177,   523,   524,   211,   190,   498,   499,   500,
     501,   502,   503,   504,   505,   506,   507,   508,   230,   310,
     509,   510,   511,   512,   678,   513,   514,   679,   515,   232,
     234,   224,   235,   358,   374,  -159,   337,   175,   236,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     237,   238,   332,   333,   295,   239,   296,   319,   240,   139,
     320,   321,   322,   323,    17,    18,    19,    20,    21,    22,
      23,   338,   168,    24,   241,   635,   637,   639,   640,    66,
     382,   383,    67,   242,   243,   177,   396,   396,     5,     6,
       7,     8,     9,    10,    11,   532,   533,   534,   190,   244,
     537,   465,    66,   382,   383,    67,   245,   545,   246,   547,
     549,   551,   247,   248,   249,    66,   382,   383,    67,   250,
     251,   262,   667,   263,   467,   566,   252,   264,   569,   253,
     297,   255,   575,   256,   298,   299,   300,   471,   257,   689,
     301,   583,   410,   258,   265,   266,   267,   268,   411,   412,
     592,   413,   269,   270,   711,   259,   260,   516,   517,    66,
     382,   383,    67,   314,    25,   314,   282,   314,   284,   314,
     302,   314,   285,   314,   286,   314,   303,   314,   287,   147,
     291,   473,   304,   305,   361,   362,   293,   271,    12,   306,
     307,   288,   425,   347,    66,   363,   348,    67,    66,   382,
     383,    67,   308,   309,   120,   349,   122,   325,   165,   104,
     169,   106,   171,   108,   173,   110,   183,   112,   189,   114,
     350,   116,   351,   329,   352,   329,   334,   329,   537,   329,
     334,   329,   339,   329,   344,   353,   310,   354,   355,   356,
     391,   498,   499,   500,   501,   502,   503,   504,   505,   506,
     507,   508,  -152,   400,   509,   510,   511,   512,   401,   513,
     514,   569,   515,   402,   760,   761,   403,   404,   666,   405,
     668,   669,   670,   671,   406,   407,   408,   537,    58,    59,
      60,    61,    62,    63,    64,    65,    50,    51,    52,    53,
      54,    55,    56,   784,   785,   688,   690,   690,   690,   690,
     697,   698,   690,   537,   537,   706,   707,   708,   709,   537,
     477,   712,   715,   409,   415,   174,   175,   416,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   417,
     134,   418,   419,   135,   136,   420,   137,   138,   139,   140,
     427,   428,   429,   758,   430,   431,   432,   141,   142,   143,
     176,   433,   174,   175,   434,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,   435,   134,   436,   437,
     135,   136,   438,   137,   138,   139,   140,   439,   440,   441,
     442,   450,   451,   452,   141,   142,   143,   176,   456,   457,
     458,   516,   517,   459,   772,   478,   479,   480,   481,   482,
     483,   484,   485,   486,   487,   488,   489,   490,   491,   492,
     493,   494,   495,   496,   497,   520,  -279,   521,   537,   522,
    -279,   290,   525,   526,   527,   540,   541,  -279,   542,   543,
     577,   145,   553,   554,   555,   557,   578,   762,   763,   579,
     580,   581,   582,   586,   587,   588,   593,   292,   594,   764,
     146,   595,   596,  -279,   597,   715,   598,  -279,   147,   599,
     600,   148,   601,  -281,  -279,   602,   603,   149,   145,   604,
     605,   606,   607,   608,   609,   610,   611,   612,   206,   613,
     614,   615,   616,   617,  -281,  -281,   150,   146,   618,   619,
     620,   621,   770,   622,   624,   147,   625,   626,   148,   627,
    -281,   628,   629,   630,   149,   631,   632,   634,   641,   642,
     643,   644,   645,   646,   647,   151,   648,   649,   650,   651,
     652,  -281,  -281,   150,   653,   654,   655,   656,   657,   658,
     660,   -74,   661,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   662,   663,   332,   333,   295,   664,
     296,   319,   151,   139,   320,   321,   322,   323,   665,   672,
     673,   674,   683,   684,   685,   716,   717,   718,   -66,   719,
     720,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   721,   722,   332,   333,   295,   723,   296,   319,
     724,   139,   320,   321,   322,   323,   725,   726,   727,   198,
     728,   729,   730,   204,   731,   733,   734,   735,   736,   737,
     738,   739,   740,   741,   742,   743,   744,   745,   746,   747,
     294,   748,   750,   751,   297,   752,   753,   754,   298,   299,
     300,   755,   756,   757,   301,   765,   766,   767,   768,   769,
     776,   782,   783,   346,   786,   787,   749,   659,   691,   633,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   297,     0,   302,     0,   298,   299,   300,     0,
     303,     0,   301,   147,     0,     0,   304,   305,     0,     0,
       0,     0,     0,   306,   307,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   308,   309,     0,     0,
       0,   325,   302,     0,     0,     0,     0,     0,   303,     0,
       0,   147,     0,     0,   304,   305,     0,     0,     0,     0,
       0,   306,   307,     0,     0,     0,     0,     0,     0,     0,
     310,     0,     0,     0,   308,   309,     0,     0,     0,   325,
       0,     0,     0,     0,     0,     0,  -108,     0,     0,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
       0,     0,     0,     0,   295,     0,   296,   319,   310,   139,
     320,   321,   322,   323,     0,     0,     0,     0,     0,     0,
       0,   324,     0,     0,  -110,     0,     0,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,     0,     0,
       0,     0,   295,     0,   296,   319,     0,   139,   320,   321,
     322,   323,     0,     0,     0,     0,     0,     0,     0,   324,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     297,     0,     0,     0,   298,   299,   300,     0,     0,     0,
     301,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   297,     0,
     302,     0,   298,   299,   300,     0,   303,     0,   301,   147,
       0,     0,   304,   305,     0,     0,     0,     0,     0,   306,
     307,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   308,   309,     0,     0,     0,   325,   302,     0,
       0,     0,     0,     0,   303,     0,     0,   147,     0,   124,
     304,   305,   127,   128,   129,   130,     0,   306,   307,   212,
     134,     0,     0,   135,   136,     0,   310,     0,     0,     0,
     308,   309,     0,     0,     0,   325,     0,   141,   142,   143,
       0,     0,  -140,     0,     0,     0,     0,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,     0,   134,
       0,     0,   135,   136,   310,   137,   138,   139,   140,     0,
       0,     0,     0,     0,     0,     0,   141,   142,   143,   144,
    -142,     0,     0,     0,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,     0,     0,     0,     0,     0,
       0,     0,   137,   138,   139,   140,  -279,     0,     0,     0,
    -279,     0,     0,     0,     0,     0,     0,  -279,     0,     0,
       0,   145,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     146,     0,     0,     0,     0,  -279,     0,   213,   147,  -279,
       0,   148,     0,  -281,     0,     0,  -279,   149,     0,     0,
     145,     0,     0,   214,   215,   216,   217,   218,   219,   220,
     221,     0,     0,     0,  -281,  -281,     0,     0,     0,   146,
       0,     0,  -279,     0,     0,     0,  -279,   147,     0,     0,
     148,     0,  -281,  -279,     0,   124,   149,   145,   127,   128,
     129,   130,     0,     0,     0,   151,     0,     0,     0,   295,
       0,   296,     0,  -281,  -281,   150,   146,     0,     0,     0,
       0,   -19,     0,     0,   147,     0,     0,   148,     0,  -281,
       0,     0,   124,   149,     0,   127,   128,   129,   130,     0,
       0,     0,     0,     0,   151,     0,   295,     0,   296,     0,
    -281,  -281,   150,     0,     0,     0,     0,     0,     0,     0,
     -51,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   151,     0,     0,     0,   297,     0,     0,     0,   298,
     299,   300,     0,     0,     0,   301,     0,   -37,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   297,     0,     0,   302,   298,   299,   300,     0,
       0,   303,   301,     0,   147,     0,     0,   304,   305,     0,
       0,     0,     0,     0,   306,   307,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   308,   309,     0,
       0,     0,   302,     0,     0,     0,     0,     0,   303,     0,
       0,   147,     0,     0,   304,   305,     0,     0,     0,     0,
       0,   306,   307,     0,     0,     0,     0,     0,     0,     0,
       0,   310,     0,     0,   308,   309,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   -96,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   310,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   -94
};

static const yytype_int16 yycheck[] =
{
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
     102,   586,    57,    58,     0,    40,    41,   246,   103,    14,
     593,   121,    17,    18,    19,    20,   101,   256,     5,     6,
     225,   236,   427,    93,   239,   240,   225,   612,   613,   235,
     245,   237,   238,   618,    99,   241,   242,   243,   588,    95,
     255,    99,    99,   593,   126,   251,   252,   253,   204,   142,
     143,   207,   260,   208,   119,   210,   121,   225,    45,   138,
     225,   119,   119,   121,   121,   158,   225,   160,   161,    10,
      11,   225,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,   226,   154,    26,    27,    28,   225,    30,
      31,   225,    33,    34,    35,    36,    37,   158,   681,   607,
     608,   225,   204,   611,    45,   207,   111,   225,   193,   204,
     115,   167,   207,   223,   519,   194,   195,   122,   179,   180,
     185,   126,   204,   226,   205,   207,   205,   185,   185,   222,
     226,   681,   347,   348,   349,   350,   196,   225,   198,   196,
     145,   198,   727,   351,   352,   226,   354,   355,   153,   204,
     111,   156,   207,   158,   115,    97,   225,   162,   223,   101,
     205,   122,   225,   104,   403,   223,   223,   108,   109,   110,
      38,   194,   195,   114,   179,   180,   415,   119,   208,   121,
     210,   226,   205,    69,    70,   400,   401,   402,   247,   248,
     249,   226,   407,   408,   433,   196,   435,   198,   257,   258,
     259,   440,   417,   144,   196,   210,   198,   205,   206,   150,
      57,    58,   153,   428,   429,   156,   157,   204,   225,   458,
     207,   226,   163,   164,   430,   431,   432,   442,   287,   226,
     436,   225,   438,   439,   225,   176,   177,   225,   180,   225,
     181,   226,   457,   451,   452,   226,    91,   226,   456,   226,
      95,   193,    97,   395,   396,   226,   101,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,   226,   210,
      59,    60,    61,    62,    63,    64,    65,    66,    67,   226,
     225,   223,   225,   205,   205,   226,    10,    11,   225,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
     225,   225,    26,    27,    28,   225,    30,    31,   225,    33,
      34,    35,    36,    37,     3,     4,     5,     6,     7,     8,
       9,    45,   167,    12,   225,   540,   541,   542,   543,   204,
     205,   206,   207,   225,   225,   180,   395,   396,     3,     4,
       5,     6,     7,     8,     9,   404,   405,   406,   193,   225,
     409,   226,   204,   205,   206,   207,   225,   416,   225,   418,
     419,   420,   225,   225,   225,   204,   205,   206,   207,   225,
     225,   123,   578,   125,   226,   434,   225,   129,   437,   225,
     104,   225,   441,   225,   108,   109,   110,   226,   225,   604,
     114,   450,   124,   225,   146,   147,   148,   149,   130,   131,
     459,   133,   154,   155,   619,   225,   225,   196,   197,   204,
     205,   206,   207,   196,   103,   198,   226,   200,   226,   202,
     144,   204,   226,   206,   226,   208,   150,   210,   225,   153,
     226,   226,   156,   157,   194,   195,   226,   189,   103,   163,
     164,   225,   205,   225,   204,   205,   225,   207,   204,   205,
     206,   207,   176,   177,    86,   225,    88,   181,    90,    70,
      92,    72,    94,    74,    96,    76,    98,    78,   100,    80,
     225,    82,   225,   200,   225,   202,   202,   204,   537,   206,
     206,   208,   208,   210,   210,   225,   210,   225,   225,   225,
     225,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,   226,   225,    59,    60,    61,    62,   225,    64,
      65,   570,    67,   225,   729,   730,   225,   225,   577,   225,
     579,   580,   581,   582,   225,   225,   225,   586,    41,    42,
      43,    44,    45,    46,    47,    48,    33,    34,    35,    36,
      37,    38,    39,   782,   783,   604,   605,   606,   607,   608,
     609,   610,   611,   612,   613,   614,   615,   616,   617,   618,
     226,   620,   621,   225,   225,    10,    11,   225,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,   225,
      25,   225,   225,    28,    29,   225,    31,    32,    33,    34,
     225,   225,   225,   203,   225,   225,   225,    42,    43,    44,
      45,   225,    10,    11,   225,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,   225,    25,   225,   225,
      28,    29,   225,    31,    32,    33,    34,   225,   225,   225,
     225,   225,   225,   225,    42,    43,    44,    45,   225,   225,
     225,   196,   197,   225,    39,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   111,   226,   727,   226,
     115,   180,   226,   226,   226,   225,   225,   122,   225,   225,
     225,   126,   226,   226,   226,   226,   225,   746,   747,   225,
     225,   225,   225,   225,   225,   225,   225,   185,   226,   758,
     145,   226,   226,   111,   226,   764,   226,   115,   153,   226,
     226,   156,   226,   158,   122,   226,   226,   162,   126,   225,
     225,   225,   225,   225,   225,   225,   225,   225,   113,   225,
     225,   225,   225,   225,   179,   180,   181,   145,   225,   225,
     225,   225,   764,   226,   226,   153,   226,   226,   156,   226,
     158,   226,   226,   226,   162,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   210,   226,   226,   226,   226,
     226,   179,   180,   181,   226,   226,   226,   226,   226,   226,
     226,   226,   226,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,   226,   226,    26,    27,    28,   226,
      30,    31,   210,    33,    34,    35,    36,    37,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     226,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,   226,   226,    26,    27,    28,   226,    30,    31,
     226,    33,    34,    35,    36,    37,   226,   226,   225,   105,
     226,   225,   225,   111,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   225,   225,
     193,   226,   226,   226,   104,   226,   226,   226,   108,   109,
     110,   226,   226,   226,   114,   226,   226,   226,   226,   226,
     225,   225,   225,   210,   226,   226,   705,   570,   605,   537,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   104,    -1,   144,    -1,   108,   109,   110,    -1,
     150,    -1,   114,   153,    -1,    -1,   156,   157,    -1,    -1,
      -1,    -1,    -1,   163,   164,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   176,   177,    -1,    -1,
      -1,   181,   144,    -1,    -1,    -1,    -1,    -1,   150,    -1,
      -1,   153,    -1,    -1,   156,   157,    -1,    -1,    -1,    -1,
      -1,   163,   164,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     210,    -1,    -1,    -1,   176,   177,    -1,    -1,    -1,   181,
      -1,    -1,    -1,    -1,    -1,    -1,   226,    -1,    -1,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      -1,    -1,    -1,    -1,    28,    -1,    30,    31,   210,    33,
      34,    35,    36,    37,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    45,    -1,    -1,   226,    -1,    -1,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    -1,    -1,
      -1,    -1,    28,    -1,    30,    31,    -1,    33,    34,    35,
      36,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    45,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     104,    -1,    -1,    -1,   108,   109,   110,    -1,    -1,    -1,
     114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   104,    -1,
     144,    -1,   108,   109,   110,    -1,   150,    -1,   114,   153,
      -1,    -1,   156,   157,    -1,    -1,    -1,    -1,    -1,   163,
     164,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   176,   177,    -1,    -1,    -1,   181,   144,    -1,
      -1,    -1,    -1,    -1,   150,    -1,    -1,   153,    -1,    14,
     156,   157,    17,    18,    19,    20,    -1,   163,   164,    24,
      25,    -1,    -1,    28,    29,    -1,   210,    -1,    -1,    -1,
     176,   177,    -1,    -1,    -1,   181,    -1,    42,    43,    44,
      -1,    -1,   226,    -1,    -1,    -1,    -1,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    -1,    25,
      -1,    -1,    28,    29,   210,    31,    32,    33,    34,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    43,    44,    45,
     226,    -1,    -1,    -1,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    31,    32,    33,    34,   111,    -1,    -1,    -1,
     115,    -1,    -1,    -1,    -1,    -1,    -1,   122,    -1,    -1,
      -1,   126,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     145,    -1,    -1,    -1,    -1,   111,    -1,   152,   153,   115,
      -1,   156,    -1,   158,    -1,    -1,   122,   162,    -1,    -1,
     126,    -1,    -1,   168,   169,   170,   171,   172,   173,   174,
     175,    -1,    -1,    -1,   179,   180,    -1,    -1,    -1,   145,
      -1,    -1,   111,    -1,    -1,    -1,   115,   153,    -1,    -1,
     156,    -1,   158,   122,    -1,    14,   162,   126,    17,    18,
      19,    20,    -1,    -1,    -1,   210,    -1,    -1,    -1,    28,
      -1,    30,    -1,   179,   180,   181,   145,    -1,    -1,    -1,
      -1,   226,    -1,    -1,   153,    -1,    -1,   156,    -1,   158,
      -1,    -1,    14,   162,    -1,    17,    18,    19,    20,    -1,
      -1,    -1,    -1,    -1,   210,    -1,    28,    -1,    30,    -1,
     179,   180,   181,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     226,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   210,    -1,    -1,    -1,   104,    -1,    -1,    -1,   108,
     109,   110,    -1,    -1,    -1,   114,    -1,   226,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   104,    -1,    -1,   144,   108,   109,   110,    -1,
      -1,   150,   114,    -1,   153,    -1,    -1,   156,   157,    -1,
      -1,    -1,    -1,    -1,   163,   164,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   176,   177,    -1,
      -1,    -1,   144,    -1,    -1,    -1,    -1,    -1,   150,    -1,
      -1,   153,    -1,    -1,   156,   157,    -1,    -1,    -1,    -1,
      -1,   163,   164,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   210,    -1,    -1,   176,   177,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   226,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   210,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   226
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,    69,    70,   232,   233,     3,     4,     5,     6,     7,
       8,     9,   103,   275,   282,   308,   313,     3,     4,     5,
       6,     7,     8,     9,    12,   103,   234,   241,   257,   262,
     270,     0,   225,   225,   225,   225,   225,   225,   225,   225,
     225,   225,   225,   225,   225,   225,   225,   225,   225,   371,
     371,   371,   371,   371,   371,   371,   371,   373,   373,   373,
     373,   373,   373,   373,   373,   373,   204,   207,   278,   334,
     276,   334,   300,   334,   283,   334,   302,   334,   285,   334,
     314,   334,   309,   334,   237,   334,   235,   334,   249,   250,
     242,   243,   251,   252,   244,   245,   263,   264,   271,   272,
     258,   259,   372,   279,   372,   277,   372,   301,   372,   284,
     372,   303,   372,   286,   372,   315,   372,   310,   374,   238,
     374,   236,   374,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    25,    28,    29,    31,    32,    33,
      34,    42,    43,    44,    45,   126,   145,   153,   156,   162,
     181,   210,   248,   253,   254,   256,   330,   332,   351,   352,
     353,   358,   359,   360,   361,   374,   246,   247,   248,   374,
     253,   374,   246,   374,    10,    11,    45,   248,   256,   265,
     266,   267,   321,   374,   273,   274,   330,   353,   358,   374,
     248,   256,   260,   261,   267,   226,   280,   226,   280,   226,
     304,   226,   287,   226,   304,   226,   287,   226,   316,   226,
     311,   226,    24,   152,   168,   169,   170,   171,   172,   173,
     174,   175,   239,   240,   256,   330,   331,   353,   358,   369,
     226,   239,   226,   225,   225,   225,   225,   225,   225,   225,
     225,   225,   225,   225,   225,   225,   225,   225,   225,   225,
     225,   225,   225,   225,   255,   225,   225,   225,   225,   225,
     225,   253,   123,   125,   129,   146,   147,   148,   149,   154,
     155,   189,   356,   357,   111,   115,   122,   363,   158,   179,
     180,   365,   226,   246,   226,   226,   226,   225,   225,   269,
     265,   226,   273,   226,   260,    28,    30,   104,   108,   109,
     110,   114,   144,   150,   156,   157,   163,   164,   176,   177,
     210,   281,   307,   330,   351,   354,   355,   366,   367,    31,
      34,    35,    36,    37,    45,   181,   288,   305,   307,   332,
     355,   366,    26,    27,   288,   298,   299,    10,    45,   288,
     298,   317,   318,   321,   288,   312,   318,   225,   225,   225,
     225,   225,   225,   225,   225,   225,   225,   239,   205,   337,
     338,   194,   195,   205,   335,   338,   335,   338,   338,   335,
     335,   338,   338,   338,   205,   339,   340,   335,   340,   334,
     334,   334,   205,   206,   334,   342,   338,   206,   338,   341,
     338,   225,   335,   340,   334,   126,   334,   362,   334,   342,
     225,   225,   225,   225,   225,   225,   225,   225,   225,   225,
     124,   130,   131,   133,   364,   225,   225,   225,   225,   225,
     225,     5,     6,    45,   334,   205,   333,   225,   225,   225,
     225,   225,   225,   225,   225,   225,   225,   225,   225,   225,
     225,   225,   225,   142,   143,   158,   160,   161,   222,   370,
     225,   225,   225,   289,   290,   306,   225,   225,   225,   225,
     320,   335,   335,   335,   335,   226,   342,   226,   342,   205,
     226,   226,   342,   226,   342,   205,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    59,
      60,    61,    62,    64,    65,    67,   196,   197,   324,   325,
     226,   226,   226,   362,   362,   226,   226,   226,   335,   335,
     335,   340,   334,   334,   334,   335,   335,   334,   347,   348,
     225,   225,   225,   225,   340,   334,   335,   334,   103,   334,
     350,   334,   349,   226,   226,   226,   268,   226,   324,   335,
     335,   338,   338,   338,   340,   102,   334,   340,   338,   334,
     346,   368,   338,   338,   340,   334,   335,   225,   225,   225,
     225,   225,   225,   334,   342,   342,   225,   225,   225,   342,
     335,   340,   334,   225,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   225,   225,   225,   225,   225,   225,
     225,   225,   225,   225,   225,   225,   225,   225,   225,   225,
     225,   225,   226,   324,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   348,   226,   335,   138,   335,   336,   335,
     335,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   368,
     226,   226,   226,   226,   226,   226,   334,   338,   334,   334,
     334,   334,   226,   226,   226,   347,    38,   291,    63,    66,
     322,   323,   325,   226,   226,   226,   319,   322,   334,   335,
     334,   343,   345,   343,   344,   344,   344,   334,   334,   344,
     347,   347,    57,    58,   328,   329,   334,   334,   334,   334,
     347,   335,   334,   326,   327,   334,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   225,   226,   225,
     225,   226,   322,   226,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   225,   225,   226,   328,
     226,   226,   226,   226,   226,   226,   226,   226,   203,   347,
     335,   335,   334,   334,   334,   226,   226,   226,   226,   226,
     327,   292,    39,   293,   294,   295,   225,   296,    40,    41,
     226,   297,   225,   225,   340,   340,   226,   226
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   231,   232,   233,   233,   233,   233,   233,   233,   233,
     233,   233,   234,   234,   236,   235,   238,   237,   239,   239,
     240,   240,   240,   240,   240,   240,   240,   240,   241,   241,
     241,   241,   243,   242,   245,   244,   246,   246,   247,   248,
     248,   248,   248,   248,   248,   248,   250,   249,   252,   251,
     253,   253,   254,   255,   254,   254,   256,   256,   256,   256,
     256,   256,   257,   259,   258,   260,   260,   261,   261,   261,
     262,   264,   263,   265,   265,   266,   266,   266,   267,   268,
     267,   269,   267,   270,   272,   271,   273,   273,   274,   274,
     274,   275,   275,   277,   276,   279,   278,   280,   280,   281,
     281,   281,   281,   282,   282,   282,   282,   284,   283,   286,
     285,   287,   287,   288,   288,   288,   288,   289,   288,   290,
     288,   288,   288,   288,   288,   292,   291,   293,   293,   295,
     294,   296,   296,   297,   297,   298,   298,   299,   299,   301,
     300,   303,   302,   304,   304,   305,   306,   305,   307,   307,
     308,   310,   309,   311,   311,   312,   312,   313,   315,   314,
     316,   316,   317,   317,   318,   319,   318,   318,   320,   318,
     321,   321,   321,   321,   322,   322,   323,   323,   323,   324,
     324,   325,   325,   325,   325,   325,   325,   325,   325,   325,
     325,   325,   325,   325,   325,   325,   325,   325,   325,   325,
     325,   325,   325,   326,   327,   327,   328,   328,   329,   329,
     330,   330,   330,   330,   330,   331,   331,   332,   332,   332,
     332,   332,   332,   332,   332,   333,   334,   334,   335,   335,
     335,   336,   336,   337,   338,   339,   340,   341,   341,   342,
     342,   342,   343,   344,   345,   346,   347,   348,   348,   349,
     350,   350,   351,   352,   353,   353,   354,   355,   355,   355,
     355,   356,   356,   356,   356,   356,   356,   356,   356,   356,
     356,   357,   356,   358,   358,   358,   358,   359,   358,   360,
     358,   361,   358,   362,   362,   362,   363,   363,   363,   364,
     364,   364,   364,   365,   365,   365,   366,   366,   366,   366,
     366,   366,   366,   366,   366,   366,   366,   366,   367,   366,
     368,   368,   369,   369,   369,   369,   369,   369,   369,   369,
     369,   369,   369,   369,   370,   370,   370,   370,   370,   370,
     371,   372,   373,   374
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     6,     6,     0,     3,     0,     3,     2,     0,
       1,     1,     1,     1,     1,     4,     4,     4,     6,     6,
       6,     6,     0,     2,     0,     2,     2,     0,     1,     4,
       4,     4,     4,     1,     1,     1,     0,     2,     0,     2,
       2,     0,     1,     0,     5,     1,     4,     4,     4,     4,
       4,     4,     6,     0,     2,     2,     0,     1,     1,     1,
       6,     0,     2,     2,     0,     1,     1,     1,     1,     0,
       5,     0,     5,     6,     0,     2,     2,     0,     1,     1,
       1,     6,     6,     0,     3,     0,     3,     2,     0,     1,
       1,     1,     1,     6,     6,     6,     6,     0,     3,     0,
       3,     2,     0,     4,     4,     4,     4,     0,     5,     0,
       5,     1,     1,     1,     1,     0,     6,     1,     0,     0,
       5,     2,     0,     4,     4,     4,     4,     1,     1,     0,
       3,     0,     3,     2,     0,     1,     0,     5,     4,     4,
       6,     0,     3,     2,     0,     1,     1,     6,     0,     3,
       2,     0,     1,     1,     1,     0,     5,     1,     0,     5,
       4,     4,     4,     4,     2,     0,     1,     4,     4,     2,
       0,     1,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     1,     1,     4,     0,     2,     0,     4,     4,
       4,     4,     4,     4,     4,     1,     4,     1,     4,     4,
       4,     4,     4,     4,     4,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     0,     1,
       1,     1,     4,     1,     1,     1,     1,     4,     4,     1,
       1,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     0,     2,     4,     4,     4,     4,     0,     2,     0,
       2,     0,     2,     2,     2,     0,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     0,     2,
       2,     0,     4,     3,     4,     3,     4,     3,     4,     3,
       4,     3,     4,     3,     4,     4,     4,     4,     4,     4,
       0,     0,     0,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = AFSOCKET_EMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == AFSOCKET_EMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, lexer, instance, arg, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use AFSOCKET_error or AFSOCKET_UNDEF. */
#define YYERRCODE AFSOCKET_UNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if AFSOCKET_DEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined AFSOCKET_LTYPE_IS_TRIVIAL && AFSOCKET_LTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, lexer, instance, arg); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (instance);
  YY_USE (arg);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, lexer, instance, arg);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), lexer, instance, arg);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, lexer, instance, arg); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !AFSOCKET_DEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !AFSOCKET_DEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (instance);
  YY_USE (arg);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_LL_IDENTIFIER: /* LL_IDENTIFIER  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4955 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_LL_STRING: /* LL_STRING  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4961 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_LL_BLOCK: /* LL_BLOCK  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4967 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_LL_PLUGIN: /* LL_PLUGIN  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4973 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_string: /* string  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4979 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_string_or_number: /* string_or_number  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4985 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_path: /* path  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4991 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_path_check: /* path_check  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 4997 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_path_secret: /* path_secret  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 5003 "modules/afsocket/afsocket-grammar.c"
        break;

    case YYSYMBOL_normalized_flag: /* normalized_flag  */
#line 470 "modules/afsocket/afsocket-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 5009 "modules/afsocket/afsocket-grammar.c"
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined AFSOCKET_LTYPE_IS_TRIVIAL && AFSOCKET_LTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = AFSOCKET_EMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == AFSOCKET_EMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, lexer);
    }

  if (yychar <= AFSOCKET_EOF)
    {
      yychar = AFSOCKET_EOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == AFSOCKET_error)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = AFSOCKET_UNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = AFSOCKET_EMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* start: driver  */
#line 596 "modules/afsocket/afsocket-grammar.y"
          {
            *instance = (yyvsp[0].ptr);
            if (yychar != AFSOCKET_EMPTY)
              cfg_lexer_unput_token(lexer, &yylval);
            YYACCEPT;
          }
#line 5320 "modules/afsocket/afsocket-grammar.c"
    break;

  case 3: /* driver: LL_CONTEXT_SOURCE source_afunix  */
#line 605 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5326 "modules/afsocket/afsocket-grammar.c"
    break;

  case 4: /* driver: LL_CONTEXT_SOURCE source_afinet  */
#line 606 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5332 "modules/afsocket/afsocket-grammar.c"
    break;

  case 5: /* driver: LL_CONTEXT_SOURCE source_afsyslog  */
#line 607 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5338 "modules/afsocket/afsocket-grammar.c"
    break;

  case 6: /* driver: LL_CONTEXT_SOURCE source_afnetwork  */
#line 608 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5344 "modules/afsocket/afsocket-grammar.c"
    break;

  case 7: /* driver: LL_CONTEXT_SOURCE source_systemd_syslog  */
#line 609 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5350 "modules/afsocket/afsocket-grammar.c"
    break;

  case 8: /* driver: LL_CONTEXT_DESTINATION dest_afunix  */
#line 610 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5356 "modules/afsocket/afsocket-grammar.c"
    break;

  case 9: /* driver: LL_CONTEXT_DESTINATION dest_afinet  */
#line 611 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5362 "modules/afsocket/afsocket-grammar.c"
    break;

  case 10: /* driver: LL_CONTEXT_DESTINATION dest_afsyslog  */
#line 612 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5368 "modules/afsocket/afsocket-grammar.c"
    break;

  case 11: /* driver: LL_CONTEXT_DESTINATION dest_afnetwork  */
#line 613 "modules/afsocket/afsocket-grammar.y"
                                                              { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5374 "modules/afsocket/afsocket-grammar.c"
    break;

  case 12: /* source_afunix: KW_UNIX_DGRAM '(' _inner_src_context_push source_afunix_dgram_params _inner_src_context_pop ')'  */
#line 618 "modules/afsocket/afsocket-grammar.y"
                                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5380 "modules/afsocket/afsocket-grammar.c"
    break;

  case 13: /* source_afunix: KW_UNIX_STREAM '(' _inner_src_context_push source_afunix_stream_params _inner_src_context_pop ')'  */
#line 619 "modules/afsocket/afsocket-grammar.y"
                                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5386 "modules/afsocket/afsocket-grammar.c"
    break;

  case 14: /* $@1: %empty  */
#line 624 "modules/afsocket/afsocket-grammar.y"
          {
            create_and_set_unix_dgram_or_systemd_syslog_source((yyvsp[0].cptr), configuration);
	  }
#line 5394 "modules/afsocket/afsocket-grammar.c"
    break;

  case 15: /* source_afunix_dgram_params: string $@1 source_afunix_options  */
#line 627 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5400 "modules/afsocket/afsocket-grammar.c"
    break;

  case 16: /* $@2: %empty  */
#line 632 "modules/afsocket/afsocket-grammar.y"
          {
            create_and_set_unix_stream_or_systemd_syslog_source((yyvsp[0].cptr), configuration);
	  }
#line 5408 "modules/afsocket/afsocket-grammar.c"
    break;

  case 17: /* source_afunix_stream_params: string $@2 source_afunix_options  */
#line 635 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5414 "modules/afsocket/afsocket-grammar.c"
    break;

  case 21: /* source_afunix_option: source_afsocket_stream_params  */
#line 646 "modules/afsocket/afsocket-grammar.y"
                                                {}
#line 5420 "modules/afsocket/afsocket-grammar.c"
    break;

  case 22: /* source_afunix_option: source_reader_option  */
#line 647 "modules/afsocket/afsocket-grammar.y"
                                                {}
#line 5426 "modules/afsocket/afsocket-grammar.c"
    break;

  case 24: /* source_afunix_option: unix_socket_option  */
#line 649 "modules/afsocket/afsocket-grammar.y"
                                                {}
#line 5432 "modules/afsocket/afsocket-grammar.c"
    break;

  case 25: /* source_afunix_option: KW_OPTIONAL '(' yesno ')'  */
#line 650 "modules/afsocket/afsocket-grammar.y"
                                                { last_driver->optional = (yyvsp[-1].num); }
#line 5438 "modules/afsocket/afsocket-grammar.c"
    break;

  case 26: /* source_afunix_option: KW_PASS_UNIX_CREDENTIALS '(' yesno ')'  */
#line 652 "modules/afsocket/afsocket-grammar.y"
          {
	    AFUnixSourceDriver *self = (AFUnixSourceDriver*) last_driver;
	    afunix_sd_set_pass_unix_credentials(self, (yyvsp[-1].num));
	  }
#line 5447 "modules/afsocket/afsocket-grammar.c"
    break;

  case 27: /* source_afunix_option: KW_CREATE_DIRS '(' yesno ')'  */
#line 657 "modules/afsocket/afsocket-grammar.y"
          {
	    AFUnixSourceDriver *self = (AFUnixSourceDriver*) last_driver;
	    afunix_sd_set_create_dirs(self, (yyvsp[-1].num));
	  }
#line 5456 "modules/afsocket/afsocket-grammar.c"
    break;

  case 28: /* source_afinet: KW_UDP '(' _inner_src_context_push source_afinet_udp_params _inner_src_context_pop ')'  */
#line 664 "modules/afsocket/afsocket-grammar.y"
                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5462 "modules/afsocket/afsocket-grammar.c"
    break;

  case 29: /* source_afinet: KW_TCP '(' _inner_src_context_push source_afinet_tcp_params _inner_src_context_pop ')'  */
#line 665 "modules/afsocket/afsocket-grammar.y"
                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5468 "modules/afsocket/afsocket-grammar.c"
    break;

  case 30: /* source_afinet: KW_UDP6 '(' _inner_src_context_push source_afinet_udp6_params _inner_src_context_pop ')'  */
#line 666 "modules/afsocket/afsocket-grammar.y"
                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5474 "modules/afsocket/afsocket-grammar.c"
    break;

  case 31: /* source_afinet: KW_TCP6 '(' _inner_src_context_push source_afinet_tcp6_params _inner_src_context_pop ')'  */
#line 667 "modules/afsocket/afsocket-grammar.y"
                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5480 "modules/afsocket/afsocket-grammar.c"
    break;

  case 32: /* $@3: %empty  */
#line 672 "modules/afsocket/afsocket-grammar.y"
          {
            AFInetSourceDriver *d = afinet_sd_new_udp(configuration);

            afinet_grammar_set_source_driver(d);
	  }
#line 5490 "modules/afsocket/afsocket-grammar.c"
    break;

  case 33: /* source_afinet_udp_params: $@3 source_afinet_udp_options  */
#line 677 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; }
#line 5496 "modules/afsocket/afsocket-grammar.c"
    break;

  case 34: /* $@4: %empty  */
#line 682 "modules/afsocket/afsocket-grammar.y"
          {
            AFInetSourceDriver *d = afinet_sd_new_udp6(configuration);

            afinet_grammar_set_source_driver(d);
          }
#line 5506 "modules/afsocket/afsocket-grammar.c"
    break;

  case 35: /* source_afinet_udp6_params: $@4 source_afinet_udp_options  */
#line 687 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; }
#line 5512 "modules/afsocket/afsocket-grammar.c"
    break;

  case 39: /* source_afinet_option: KW_LOCALIP '(' string ')'  */
#line 700 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_sd_set_localip(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5518 "modules/afsocket/afsocket-grammar.c"
    break;

  case 40: /* source_afinet_option: KW_IP '(' string ')'  */
#line 701 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_sd_set_localip(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5524 "modules/afsocket/afsocket-grammar.c"
    break;

  case 41: /* source_afinet_option: KW_LOCALPORT '(' string_or_number ')'  */
#line 702 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_sd_set_localport(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5530 "modules/afsocket/afsocket-grammar.c"
    break;

  case 42: /* source_afinet_option: KW_PORT '(' string_or_number ')'  */
#line 703 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_sd_set_localport(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5536 "modules/afsocket/afsocket-grammar.c"
    break;

  case 46: /* $@5: %empty  */
#line 711 "modules/afsocket/afsocket-grammar.y"
          {
	    AFInetSourceDriver *d = afinet_sd_new_tcp(configuration);

	    afinet_grammar_set_source_driver(d);
	  }
#line 5546 "modules/afsocket/afsocket-grammar.c"
    break;

  case 47: /* source_afinet_tcp_params: $@5 source_afinet_tcp_options  */
#line 716 "modules/afsocket/afsocket-grammar.y"
                                        { (yyval.ptr) = last_driver; }
#line 5552 "modules/afsocket/afsocket-grammar.c"
    break;

  case 48: /* $@6: %empty  */
#line 721 "modules/afsocket/afsocket-grammar.y"
          {
	    AFInetSourceDriver *d = afinet_sd_new_tcp6(configuration);

	    afinet_grammar_set_source_driver(d);
	  }
#line 5562 "modules/afsocket/afsocket-grammar.c"
    break;

  case 49: /* source_afinet_tcp6_params: $@6 source_afinet_tcp_options  */
#line 726 "modules/afsocket/afsocket-grammar.y"
                                        { (yyval.ptr) = last_driver; }
#line 5568 "modules/afsocket/afsocket-grammar.c"
    break;

  case 53: /* $@7: %empty  */
#line 737 "modules/afsocket/afsocket-grammar.y"
          {
            gchar buf[256];

	    last_tls_context = tls_context_new(TM_SERVER, cfg_lexer_format_location(lexer, &(yylsp[0]), buf, sizeof(buf)));
	  }
#line 5578 "modules/afsocket/afsocket-grammar.c"
    break;

  case 54: /* source_afinet_tcp_option: KW_TLS $@7 '(' tls_options ')'  */
#line 743 "modules/afsocket/afsocket-grammar.y"
          {
	    afinet_sd_set_tls_context(last_driver, last_tls_context);
          }
#line 5586 "modules/afsocket/afsocket-grammar.c"
    break;

  case 55: /* source_afinet_tcp_option: source_afsocket_stream_params  */
#line 746 "modules/afsocket/afsocket-grammar.y"
                                                {}
#line 5592 "modules/afsocket/afsocket-grammar.c"
    break;

  case 56: /* source_afsocket_stream_params: KW_KEEP_ALIVE '(' yesno ')'  */
#line 750 "modules/afsocket/afsocket-grammar.y"
                                                { afsocket_sd_set_keep_alive(last_driver, (yyvsp[-1].num)); }
#line 5598 "modules/afsocket/afsocket-grammar.c"
    break;

  case 57: /* source_afsocket_stream_params: KW_MAX_CONNECTIONS '(' positive_integer ')'  */
#line 751 "modules/afsocket/afsocket-grammar.y"
                                                         { afsocket_sd_set_max_connections(last_driver, (yyvsp[-1].num)); }
#line 5604 "modules/afsocket/afsocket-grammar.c"
    break;

  case 58: /* source_afsocket_stream_params: KW_LISTEN_BACKLOG '(' positive_integer ')'  */
#line 752 "modules/afsocket/afsocket-grammar.y"
                                                        { afsocket_sd_set_listen_backlog(last_driver, (yyvsp[-1].num)); }
#line 5610 "modules/afsocket/afsocket-grammar.c"
    break;

  case 59: /* source_afsocket_stream_params: KW_DYNAMIC_WINDOW_SIZE '(' nonnegative_integer ')'  */
#line 753 "modules/afsocket/afsocket-grammar.y"
                                                             { afsocket_sd_set_dynamic_window_size(last_driver, (yyvsp[-1].num)); }
#line 5616 "modules/afsocket/afsocket-grammar.c"
    break;

  case 60: /* source_afsocket_stream_params: KW_DYNAMIC_WINDOW_STATS_FREQ '(' nonnegative_float ')'  */
#line 754 "modules/afsocket/afsocket-grammar.y"
                                                           { afsocket_sd_set_dynamic_window_stats_freq(last_driver, (yyvsp[-1].fnum)); }
#line 5622 "modules/afsocket/afsocket-grammar.c"
    break;

  case 61: /* source_afsocket_stream_params: KW_DYNAMIC_WINDOW_REALLOC_TICKS '(' nonnegative_integer ')'  */
#line 755 "modules/afsocket/afsocket-grammar.y"
                                                                { afsocket_sd_set_dynamic_window_realloc_ticks(last_driver, (yyvsp[-1].num)); }
#line 5628 "modules/afsocket/afsocket-grammar.c"
    break;

  case 62: /* source_afsyslog: KW_SYSLOG '(' _inner_src_context_push source_afsyslog_params _inner_src_context_pop ')'  */
#line 759 "modules/afsocket/afsocket-grammar.y"
                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5634 "modules/afsocket/afsocket-grammar.c"
    break;

  case 63: /* $@8: %empty  */
#line 764 "modules/afsocket/afsocket-grammar.y"
          {
            /* we use transport(tcp) transport by default */
            AFInetSourceDriver *d = afinet_sd_new_syslog(configuration);

            afinet_grammar_set_source_driver(d);
	  }
#line 5645 "modules/afsocket/afsocket-grammar.c"
    break;

  case 64: /* source_afsyslog_params: $@8 source_afsyslog_options  */
#line 770 "modules/afsocket/afsocket-grammar.y"
                                        { (yyval.ptr) = last_driver; }
#line 5651 "modules/afsocket/afsocket-grammar.c"
    break;

  case 69: /* source_afsyslog_option: source_afsocket_stream_params  */
#line 781 "modules/afsocket/afsocket-grammar.y"
                                                {}
#line 5657 "modules/afsocket/afsocket-grammar.c"
    break;

  case 70: /* source_afnetwork: KW_NETWORK '(' _inner_src_context_push source_afnetwork_params _inner_src_context_pop ')'  */
#line 785 "modules/afsocket/afsocket-grammar.y"
                                                                                                       { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5663 "modules/afsocket/afsocket-grammar.c"
    break;

  case 71: /* $@9: %empty  */
#line 790 "modules/afsocket/afsocket-grammar.y"
          {
            /* we use transport(tcp) transport by default */
            AFInetSourceDriver *d = afinet_sd_new_network(configuration);

            afinet_grammar_set_source_driver(d);
	  }
#line 5674 "modules/afsocket/afsocket-grammar.c"
    break;

  case 72: /* source_afnetwork_params: $@9 source_afnetwork_options  */
#line 796 "modules/afsocket/afsocket-grammar.y"
                                        { (yyval.ptr) = last_driver; }
#line 5680 "modules/afsocket/afsocket-grammar.c"
    break;

  case 77: /* source_afnetwork_option: source_afsocket_stream_params  */
#line 807 "modules/afsocket/afsocket-grammar.y"
                                                {}
#line 5686 "modules/afsocket/afsocket-grammar.c"
    break;

  case 79: /* $@10: %empty  */
#line 813 "modules/afsocket/afsocket-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_SERVER_PROTO;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            if (p)
              {
                /* for transports with grammar */
                if (p->parser)
                  {
                    LogProtoServerFactory *sf = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_proto_server_options);
                    ((AFSocketSourceDriver *) last_driver)->proto_factory = sf;
                  }
              }
            transport_mapper_set_transport(last_transport_mapper, (yyvsp[0].cptr));
          }
#line 5707 "modules/afsocket/afsocket-grammar.c"
    break;

  case 80: /* source_afsocket_transport: KW_TRANSPORT '(' string $@10 ')'  */
#line 829 "modules/afsocket/afsocket-grammar.y"
                { free((yyvsp[-2].cptr)); }
#line 5713 "modules/afsocket/afsocket-grammar.c"
    break;

  case 81: /* $@11: %empty  */
#line 831 "modules/afsocket/afsocket-grammar.y"
          {
            gchar buf[256];

	    last_tls_context = tls_context_new(TM_SERVER, cfg_lexer_format_location(lexer, &(yylsp[0]), buf, sizeof(buf)));
	  }
#line 5723 "modules/afsocket/afsocket-grammar.c"
    break;

  case 82: /* source_afsocket_transport: KW_TLS $@11 '(' tls_options ')'  */
#line 837 "modules/afsocket/afsocket-grammar.y"
          {
	    afinet_sd_set_tls_context(last_driver, last_tls_context);
          }
#line 5731 "modules/afsocket/afsocket-grammar.c"
    break;

  case 83: /* source_systemd_syslog: KW_SYSTEMD_SYSLOG '(' _inner_src_context_push source_systemd_syslog_params _inner_src_context_pop ')'  */
#line 843 "modules/afsocket/afsocket-grammar.y"
                                                                                                                 { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5737 "modules/afsocket/afsocket-grammar.c"
    break;

  case 84: /* $@12: %empty  */
#line 847 "modules/afsocket/afsocket-grammar.y"
          {
#if ! SYSLOG_NG_ENABLE_SYSTEMD
            msg_error("systemd-syslog() source cannot be enabled and it is not"
                      " functioning. Please compile your syslog-ng with --enable-systemd"
                      " flag", cfg_lexer_format_location_tag(lexer, &(yylsp[0])));
            YYERROR;
#else
            SystemDSyslogSourceDriver *d = systemd_syslog_sd_new(configuration, FALSE);
            systemd_syslog_grammar_set_source_driver(d);
#endif
          }
#line 5753 "modules/afsocket/afsocket-grammar.c"
    break;

  case 85: /* source_systemd_syslog_params: $@12 source_systemd_syslog_options  */
#line 858 "modules/afsocket/afsocket-grammar.y"
                                        { (yyval.ptr) = last_driver; }
#line 5759 "modules/afsocket/afsocket-grammar.c"
    break;

  case 91: /* dest_afunix: KW_UNIX_DGRAM '(' _inner_dest_context_push dest_afunix_dgram_params _inner_dest_context_pop ')'  */
#line 873 "modules/afsocket/afsocket-grammar.y"
                                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5765 "modules/afsocket/afsocket-grammar.c"
    break;

  case 92: /* dest_afunix: KW_UNIX_STREAM '(' _inner_dest_context_push dest_afunix_stream_params _inner_dest_context_pop ')'  */
#line 874 "modules/afsocket/afsocket-grammar.y"
                                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5771 "modules/afsocket/afsocket-grammar.c"
    break;

  case 93: /* $@13: %empty  */
#line 879 "modules/afsocket/afsocket-grammar.y"
          {
	    AFUnixDestDriver *d = afunix_dd_new_dgram((yyvsp[0].cptr), configuration);

      afunix_grammar_set_dest_driver(d);
	  }
#line 5781 "modules/afsocket/afsocket-grammar.c"
    break;

  case 94: /* dest_afunix_dgram_params: string $@13 dest_afunix_options  */
#line 884 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5787 "modules/afsocket/afsocket-grammar.c"
    break;

  case 95: /* $@14: %empty  */
#line 889 "modules/afsocket/afsocket-grammar.y"
          {
	    AFUnixDestDriver *d = afunix_dd_new_stream((yyvsp[0].cptr), configuration);

      afunix_grammar_set_dest_driver(d);
	  }
#line 5797 "modules/afsocket/afsocket-grammar.c"
    break;

  case 96: /* dest_afunix_stream_params: string $@14 dest_afunix_options  */
#line 894 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5803 "modules/afsocket/afsocket-grammar.c"
    break;

  case 103: /* dest_afinet: KW_UDP '(' _inner_dest_context_push dest_afinet_udp_params _inner_dest_context_pop ')'  */
#line 910 "modules/afsocket/afsocket-grammar.y"
                                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5809 "modules/afsocket/afsocket-grammar.c"
    break;

  case 104: /* dest_afinet: KW_TCP '(' _inner_dest_context_push dest_afinet_tcp_params _inner_dest_context_pop ')'  */
#line 911 "modules/afsocket/afsocket-grammar.y"
                                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5815 "modules/afsocket/afsocket-grammar.c"
    break;

  case 105: /* dest_afinet: KW_UDP6 '(' _inner_dest_context_push dest_afinet_udp6_params _inner_dest_context_pop ')'  */
#line 912 "modules/afsocket/afsocket-grammar.y"
                                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5821 "modules/afsocket/afsocket-grammar.c"
    break;

  case 106: /* dest_afinet: KW_TCP6 '(' _inner_dest_context_push dest_afinet_tcp6_params _inner_dest_context_pop ')'  */
#line 913 "modules/afsocket/afsocket-grammar.y"
                                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 5827 "modules/afsocket/afsocket-grammar.c"
    break;

  case 107: /* $@15: %empty  */
#line 918 "modules/afsocket/afsocket-grammar.y"
          {
	    AFInetDestDriver *d = afinet_dd_new_udp((yyvsp[0].cptr), configuration);

      afinet_grammar_set_dest_driver(d);
	  }
#line 5837 "modules/afsocket/afsocket-grammar.c"
    break;

  case 108: /* dest_afinet_udp_params: string $@15 dest_afinet_udp_options  */
#line 923 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5843 "modules/afsocket/afsocket-grammar.c"
    break;

  case 109: /* $@16: %empty  */
#line 928 "modules/afsocket/afsocket-grammar.y"
          {
	    AFInetDestDriver *d = afinet_dd_new_udp6((yyvsp[0].cptr), configuration);

	    afinet_grammar_set_dest_driver(d);
	  }
#line 5853 "modules/afsocket/afsocket-grammar.c"
    break;

  case 110: /* dest_afinet_udp6_params: string $@16 dest_afinet_udp_options  */
#line 933 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5859 "modules/afsocket/afsocket-grammar.c"
    break;

  case 113: /* dest_afinet_option: KW_LOCALIP '(' string ')'  */
#line 944 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_dd_set_localip(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5865 "modules/afsocket/afsocket-grammar.c"
    break;

  case 114: /* dest_afinet_option: KW_LOCALPORT '(' string_or_number ')'  */
#line 945 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_dd_set_localport(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5871 "modules/afsocket/afsocket-grammar.c"
    break;

  case 115: /* dest_afinet_option: KW_PORT '(' string_or_number ')'  */
#line 946 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_dd_set_destport(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5877 "modules/afsocket/afsocket-grammar.c"
    break;

  case 116: /* dest_afinet_option: KW_DESTPORT '(' string_or_number ')'  */
#line 947 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_dd_set_destport(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5883 "modules/afsocket/afsocket-grammar.c"
    break;

  case 117: /* $@17: %empty  */
#line 948 "modules/afsocket/afsocket-grammar.y"
                              { afinet_dd_enable_failover(last_driver); }
#line 5889 "modules/afsocket/afsocket-grammar.c"
    break;

  case 118: /* dest_afinet_option: KW_FAILOVER_SERVERS $@17 '(' string_list ')'  */
#line 948 "modules/afsocket/afsocket-grammar.y"
                                                                                                { afinet_dd_add_failovers(last_driver, (yyvsp[-1].ptr)); }
#line 5895 "modules/afsocket/afsocket-grammar.c"
    break;

  case 119: /* $@18: %empty  */
#line 949 "modules/afsocket/afsocket-grammar.y"
                      { afinet_dd_enable_failover(last_driver); }
#line 5901 "modules/afsocket/afsocket-grammar.c"
    break;

  case 120: /* dest_afinet_option: KW_FAILOVER $@18 '(' dest_failover_options ')'  */
#line 949 "modules/afsocket/afsocket-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 5907 "modules/afsocket/afsocket-grammar.c"
    break;

  case 125: /* $@19: %empty  */
#line 957 "modules/afsocket/afsocket-grammar.y"
                                         { afinet_dd_add_failovers(last_driver, (yyvsp[-1].ptr)); }
#line 5913 "modules/afsocket/afsocket-grammar.c"
    break;

  case 129: /* $@20: %empty  */
#line 966 "modules/afsocket/afsocket-grammar.y"
                { afinet_dd_enable_failback(last_driver); }
#line 5919 "modules/afsocket/afsocket-grammar.c"
    break;

  case 133: /* dest_failback_probe_option: KW_TCP_PROBE_INTERVAL '(' positive_integer ')'  */
#line 975 "modules/afsocket/afsocket-grammar.y"
                                                         { afinet_dd_set_failback_tcp_probe_interval(last_driver, (yyvsp[-1].num)); }
#line 5925 "modules/afsocket/afsocket-grammar.c"
    break;

  case 134: /* dest_failback_probe_option: KW_SUCCESSFUL_PROBES_REQUIRED '(' positive_integer ')'  */
#line 976 "modules/afsocket/afsocket-grammar.y"
                                                                 { afinet_dd_set_failback_successful_probes_required(last_driver, (yyvsp[-1].num)); }
#line 5931 "modules/afsocket/afsocket-grammar.c"
    break;

  case 135: /* dest_afinet_dgram_option: KW_SPOOF_SOURCE '(' yesno ')'  */
#line 980 "modules/afsocket/afsocket-grammar.y"
                                                { afinet_dd_set_spoof_source(last_driver, (yyvsp[-1].num)); }
#line 5937 "modules/afsocket/afsocket-grammar.c"
    break;

  case 136: /* dest_afinet_dgram_option: KW_SPOOF_SOURCE_MAX_MSGLEN '(' positive_integer ')'  */
#line 981 "modules/afsocket/afsocket-grammar.y"
                                                              { afinet_dd_set_spoof_source_max_msglen(last_driver, (yyvsp[-1].num)); }
#line 5943 "modules/afsocket/afsocket-grammar.c"
    break;

  case 139: /* $@21: %empty  */
#line 991 "modules/afsocket/afsocket-grammar.y"
          {
	    AFInetDestDriver *d = afinet_dd_new_tcp((yyvsp[0].cptr), configuration);

      afinet_grammar_set_dest_driver(d);
	  }
#line 5953 "modules/afsocket/afsocket-grammar.c"
    break;

  case 140: /* dest_afinet_tcp_params: string $@21 dest_afinet_tcp_options  */
#line 996 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5959 "modules/afsocket/afsocket-grammar.c"
    break;

  case 141: /* $@22: %empty  */
#line 1001 "modules/afsocket/afsocket-grammar.y"
          {
	    AFInetDestDriver *d = afinet_dd_new_tcp6((yyvsp[0].cptr), configuration);

	    afinet_grammar_set_dest_driver(d);
	  }
#line 5969 "modules/afsocket/afsocket-grammar.c"
    break;

  case 142: /* dest_afinet_tcp6_params: string $@22 dest_afinet_tcp_options  */
#line 1006 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 5975 "modules/afsocket/afsocket-grammar.c"
    break;

  case 146: /* $@23: %empty  */
#line 1017 "modules/afsocket/afsocket-grammar.y"
          {
            gchar buf[256];
	    last_tls_context = tls_context_new(TM_CLIENT, cfg_lexer_format_location(lexer, &(yylsp[0]), buf, sizeof(buf)));
	  }
#line 5984 "modules/afsocket/afsocket-grammar.c"
    break;

  case 147: /* dest_afinet_tcp_option: KW_TLS $@23 '(' dest_tls_options ')'  */
#line 1022 "modules/afsocket/afsocket-grammar.y"
          {
	    afinet_dd_set_tls_context(last_driver, last_tls_context);
          }
#line 5992 "modules/afsocket/afsocket-grammar.c"
    break;

  case 148: /* dest_afsocket_option: KW_KEEP_ALIVE '(' yesno ')'  */
#line 1028 "modules/afsocket/afsocket-grammar.y"
                                             { afsocket_dd_set_keep_alive(last_driver, (yyvsp[-1].num)); }
#line 5998 "modules/afsocket/afsocket-grammar.c"
    break;

  case 149: /* dest_afsocket_option: KW_CLOSE_ON_INPUT '(' yesno ')'  */
#line 1030 "modules/afsocket/afsocket-grammar.y"
          {
            afsocket_dd_set_close_on_input(last_driver, (yyvsp[-1].num));
            log_proto_client_options_set_drop_input(last_proto_client_options, !(yyvsp[-1].num));
          }
#line 6007 "modules/afsocket/afsocket-grammar.c"
    break;

  case 150: /* dest_afsyslog: KW_SYSLOG '(' _inner_dest_context_push dest_afsyslog_params _inner_dest_context_pop ')'  */
#line 1038 "modules/afsocket/afsocket-grammar.y"
                                                                                                    { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 6013 "modules/afsocket/afsocket-grammar.c"
    break;

  case 151: /* $@24: %empty  */
#line 1042 "modules/afsocket/afsocket-grammar.y"
          {
            AFInetDestDriver *d = afinet_dd_new_syslog((yyvsp[0].cptr), configuration);

            afinet_grammar_set_dest_driver(d);
	  }
#line 6023 "modules/afsocket/afsocket-grammar.c"
    break;

  case 152: /* dest_afsyslog_params: string $@24 dest_afsyslog_options  */
#line 1047 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 6029 "modules/afsocket/afsocket-grammar.c"
    break;

  case 157: /* dest_afnetwork: KW_NETWORK '(' _inner_dest_context_push dest_afnetwork_params _inner_dest_context_pop ')'  */
#line 1062 "modules/afsocket/afsocket-grammar.y"
                                                                                                        { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 6035 "modules/afsocket/afsocket-grammar.c"
    break;

  case 158: /* $@25: %empty  */
#line 1067 "modules/afsocket/afsocket-grammar.y"
          {
            AFInetDestDriver *d = afinet_dd_new_network((yyvsp[0].cptr), configuration);

            afinet_grammar_set_dest_driver(d);
	  }
#line 6045 "modules/afsocket/afsocket-grammar.c"
    break;

  case 159: /* dest_afnetwork_params: string $@25 dest_afnetwork_options  */
#line 1072 "modules/afsocket/afsocket-grammar.y"
                                                        { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 6051 "modules/afsocket/afsocket-grammar.c"
    break;

  case 165: /* $@26: %empty  */
#line 1088 "modules/afsocket/afsocket-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_CLIENT_PROTO;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            if (p)
              {
                /* for transports with grammar */
                if (p->parser)
                  {
                    LogProtoClientFactory *cf = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_proto_client_options);
                    ((AFSocketDestDriver *) last_driver)->proto_factory = cf;
                  }
              }
            transport_mapper_set_transport(last_transport_mapper, (yyvsp[0].cptr));
          }
#line 6072 "modules/afsocket/afsocket-grammar.c"
    break;

  case 166: /* dest_afsocket_transport: KW_TRANSPORT '(' string $@26 ')'  */
#line 1104 "modules/afsocket/afsocket-grammar.y"
                { free((yyvsp[-2].cptr)); }
#line 6078 "modules/afsocket/afsocket-grammar.c"
    break;

  case 168: /* $@27: %empty  */
#line 1107 "modules/afsocket/afsocket-grammar.y"
          {
            gchar buf[256];

            last_tls_context = tls_context_new(TM_CLIENT, cfg_lexer_format_location(lexer, &(yylsp[0]), buf, sizeof(buf)));
          }
#line 6088 "modules/afsocket/afsocket-grammar.c"
    break;

  case 169: /* dest_afsocket_transport: KW_TLS $@27 '(' dest_tls_options ')'  */
#line 1113 "modules/afsocket/afsocket-grammar.y"
          {
            afinet_dd_set_tls_context(last_driver, last_tls_context);
          }
#line 6096 "modules/afsocket/afsocket-grammar.c"
    break;

  case 170: /* afsocket_transport: KW_TRANSPORT '(' KW_TCP ')'  */
#line 1119 "modules/afsocket/afsocket-grammar.y"
                                                         { transport_mapper_set_transport(last_transport_mapper, "tcp"); }
#line 6102 "modules/afsocket/afsocket-grammar.c"
    break;

  case 171: /* afsocket_transport: KW_TRANSPORT '(' KW_UDP ')'  */
#line 1120 "modules/afsocket/afsocket-grammar.y"
                                                         { transport_mapper_set_transport(last_transport_mapper, "udp"); }
#line 6108 "modules/afsocket/afsocket-grammar.c"
    break;

  case 172: /* afsocket_transport: KW_TRANSPORT '(' KW_TLS ')'  */
#line 1121 "modules/afsocket/afsocket-grammar.y"
                                                         { transport_mapper_set_transport(last_transport_mapper, "tls"); }
#line 6114 "modules/afsocket/afsocket-grammar.c"
    break;

  case 173: /* afsocket_transport: KW_IP_PROTOCOL '(' inet_ip_protocol_option ')'  */
#line 1122 "modules/afsocket/afsocket-grammar.y"
                                                         { transport_mapper_set_address_family(last_transport_mapper, (yyvsp[-1].num)); }
#line 6120 "modules/afsocket/afsocket-grammar.c"
    break;

  case 177: /* dest_tls_option: KW_SNI '(' yesno ')'  */
#line 1133 "modules/afsocket/afsocket-grammar.y"
          {
            if ((yyvsp[-1].num))
              tls_context_set_sni(last_tls_context, ((AFInetDestDriver *)last_driver)->primary);
          }
#line 6129 "modules/afsocket/afsocket-grammar.c"
    break;

  case 178: /* dest_tls_option: KW_OCSP_STAPLING_VERIFY '(' yesno ')'  */
#line 1138 "modules/afsocket/afsocket-grammar.y"
          {
            tls_context_set_ocsp_stapling_verify(last_tls_context, (yyvsp[-1].num));
          }
#line 6137 "modules/afsocket/afsocket-grammar.c"
    break;

  case 181: /* tls_option: KW_IFDEF  */
#line 1149 "modules/afsocket/afsocket-grammar.y"
                   {
}
#line 6144 "modules/afsocket/afsocket-grammar.c"
    break;

  case 182: /* tls_option: KW_PEER_VERIFY '(' yesno ')'  */
#line 1153 "modules/afsocket/afsocket-grammar.y"
          {
	    gint verify_mode = (yyvsp[-1].num) ? (TVM_REQUIRED | TVM_TRUSTED) : (TVM_OPTIONAL | TVM_UNTRUSTED);
	    tls_context_set_verify_mode(last_tls_context, verify_mode);
          }
#line 6153 "modules/afsocket/afsocket-grammar.c"
    break;

  case 183: /* tls_option: KW_PEER_VERIFY '(' string ')'  */
#line 1158 "modules/afsocket/afsocket-grammar.y"
          {
	    CHECK_ERROR(tls_context_set_verify_mode_by_name(last_tls_context, (yyvsp[-1].cptr)), (yylsp[-1]),
	                "unknown peer-verify() argument");
            free((yyvsp[-1].cptr));
          }
#line 6163 "modules/afsocket/afsocket-grammar.c"
    break;

  case 184: /* tls_option: KW_KEY_FILE '(' path_secret ')'  */
#line 1164 "modules/afsocket/afsocket-grammar.y"
          {
	    tls_context_set_key_file(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6172 "modules/afsocket/afsocket-grammar.c"
    break;

  case 185: /* tls_option: KW_KEYLOG_FILE '(' string ')'  */
#line 1169 "modules/afsocket/afsocket-grammar.y"
          {
	    GError *error = NULL;
	    CHECK_ERROR_GERROR(tls_context_set_keylog_file(last_tls_context, (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error setting keylog-file()");
	    free((yyvsp[-1].cptr));
	  }
#line 6182 "modules/afsocket/afsocket-grammar.c"
    break;

  case 186: /* tls_option: KW_CERT_FILE '(' path_check ')'  */
#line 1175 "modules/afsocket/afsocket-grammar.y"
          {
	    tls_context_set_cert_file(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6191 "modules/afsocket/afsocket-grammar.c"
    break;

  case 187: /* tls_option: KW_DHPARAM_FILE '(' path_check ')'  */
#line 1180 "modules/afsocket/afsocket-grammar.y"
          {
            tls_context_set_dhparam_file(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6200 "modules/afsocket/afsocket-grammar.c"
    break;

  case 188: /* tls_option: KW_PKCS12_FILE '(' path_check ')'  */
#line 1185 "modules/afsocket/afsocket-grammar.y"
          {
            tls_context_set_pkcs12_file(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6209 "modules/afsocket/afsocket-grammar.c"
    break;

  case 189: /* tls_option: KW_CA_DIR '(' string ')'  */
#line 1190 "modules/afsocket/afsocket-grammar.y"
          {
	    tls_context_set_ca_dir(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6218 "modules/afsocket/afsocket-grammar.c"
    break;

  case 190: /* tls_option: KW_CRL_DIR '(' string ')'  */
#line 1195 "modules/afsocket/afsocket-grammar.y"
          {
	    tls_context_set_crl_dir(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6227 "modules/afsocket/afsocket-grammar.c"
    break;

  case 191: /* tls_option: KW_CA_FILE '(' path_check ')'  */
#line 1200 "modules/afsocket/afsocket-grammar.y"
          {
            tls_context_set_ca_file(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6236 "modules/afsocket/afsocket-grammar.c"
    break;

  case 192: /* tls_option: KW_TRUSTED_KEYS '(' string_list ')'  */
#line 1205 "modules/afsocket/afsocket-grammar.y"
          {
            tls_session_set_trusted_fingerprints(last_tls_context, (yyvsp[-1].ptr));
          }
#line 6244 "modules/afsocket/afsocket-grammar.c"
    break;

  case 193: /* tls_option: KW_TRUSTED_DN '(' string_list ')'  */
#line 1209 "modules/afsocket/afsocket-grammar.y"
          {
            tls_session_set_trusted_dn(last_tls_context, (yyvsp[-1].ptr));
          }
#line 6252 "modules/afsocket/afsocket-grammar.c"
    break;

  case 195: /* tls_option: KW_CIPHER_SUITE '(' string ')'  */
#line 1214 "modules/afsocket/afsocket-grammar.y"
          {
            /* compat for specifying TLS 1.2-or-older ciphers */
            tls_context_set_cipher_suite(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6262 "modules/afsocket/afsocket-grammar.c"
    break;

  case 196: /* tls_option: KW_SIGALGS '(' string ')'  */
#line 1220 "modules/afsocket/afsocket-grammar.y"
          {
            GError *error = NULL;
            CHECK_ERROR_GERROR(tls_context_set_sigalgs(last_tls_context, (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error setting sigalgs()");
            free((yyvsp[-1].cptr));
          }
#line 6272 "modules/afsocket/afsocket-grammar.c"
    break;

  case 197: /* tls_option: KW_CLIENT_SIGALGS '(' string ')'  */
#line 1226 "modules/afsocket/afsocket-grammar.y"
          {
            GError *error = NULL;
            CHECK_ERROR_GERROR(tls_context_set_client_sigalgs(last_tls_context, (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error setting client-sigalgs()");
            free((yyvsp[-1].cptr));
          }
#line 6282 "modules/afsocket/afsocket-grammar.c"
    break;

  case 198: /* tls_option: KW_ECDH_CURVE_LIST '(' string ')'  */
#line 1232 "modules/afsocket/afsocket-grammar.y"
          {
            tls_context_set_ecdh_curve_list(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6291 "modules/afsocket/afsocket-grammar.c"
    break;

  case 199: /* tls_option: KW_SSL_OPTIONS '(' string_list ')'  */
#line 1237 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(tls_context_set_ssl_options_by_name(last_tls_context, (yyvsp[-1].ptr)), (yylsp[-1]),
                        "unknown ssl-options() argument");
	  }
#line 6300 "modules/afsocket/afsocket-grammar.c"
    break;

  case 200: /* tls_option: KW_ALLOW_COMPRESS '(' yesno ')'  */
#line 1242 "modules/afsocket/afsocket-grammar.y"
          {
             transport_mapper_inet_set_allow_compress(last_transport_mapper, (yyvsp[-1].num));
          }
#line 6308 "modules/afsocket/afsocket-grammar.c"
    break;

  case 201: /* tls_option: KW_CONF_CMDS '(' tls_conf_cmds ')'  */
#line 1246 "modules/afsocket/afsocket-grammar.y"
                {
			GError *error = NULL;
			CHECK_ERROR_GERROR(tls_context_set_conf_cmds(last_tls_context, (yyvsp[-1].ptr), &error), (yylsp[-1]), error, "Error setting conf-cmds()");
		}
#line 6317 "modules/afsocket/afsocket-grammar.c"
    break;

  case 202: /* tls_option: KW_ENDIF  */
#line 1250 "modules/afsocket/afsocket-grammar.y"
                   {
}
#line 6324 "modules/afsocket/afsocket-grammar.c"
    break;

  case 203: /* tls_conf_cmds: tls_conf_cmd_list_build  */
#line 1256 "modules/afsocket/afsocket-grammar.y"
                {
			(yyval.ptr) = (yyvsp[0].ptr);
		}
#line 6332 "modules/afsocket/afsocket-grammar.c"
    break;

  case 204: /* tls_conf_cmd_list_build: string LL_ARROW string tls_conf_cmd_list_build  */
#line 1263 "modules/afsocket/afsocket-grammar.y"
                {
			/* Revers order is important here as this is inside of a bison right recursion */
			(yyval.ptr) = g_list_prepend((yyvsp[0].ptr), g_strdup((yyvsp[-1].cptr)));
			(yyval.ptr) = g_list_prepend((yyval.ptr), g_strdup((yyvsp[-3].cptr)));

			free((yyvsp[-3].cptr));
			free((yyvsp[-1].cptr));
		}
#line 6345 "modules/afsocket/afsocket-grammar.c"
    break;

  case 205: /* tls_conf_cmd_list_build: %empty  */
#line 1272 "modules/afsocket/afsocket-grammar.y"
                {
			(yyval.ptr) = NULL;
		}
#line 6353 "modules/afsocket/afsocket-grammar.c"
    break;

  case 208: /* tls_cipher_suite: KW_TLS12_AND_OLDER '(' string ')'  */
#line 1284 "modules/afsocket/afsocket-grammar.y"
          {
            tls_context_set_cipher_suite(last_tls_context, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6362 "modules/afsocket/afsocket-grammar.c"
    break;

  case 209: /* tls_cipher_suite: KW_TLS13 '(' string ')'  */
#line 1289 "modules/afsocket/afsocket-grammar.y"
          {
            GError *error = NULL;
            CHECK_ERROR_GERROR(tls_context_set_tls13_cipher_suite(last_tls_context, (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error setting cipher-suite(tls13())");
            free((yyvsp[-1].cptr));
          }
#line 6372 "modules/afsocket/afsocket-grammar.c"
    break;

  case 210: /* socket_option: KW_SO_SNDBUF '(' nonnegative_integer ')'  */
#line 1298 "modules/afsocket/afsocket-grammar.y"
        {
		CHECK_ERROR((yyvsp[-1].num) <= G_MAXINT, (yylsp[-1]), "Invalid so_sndbuf, it has to be less than %d", G_MAXINT);
		last_sock_options->so_sndbuf = (yyvsp[-1].num);
	}
#line 6381 "modules/afsocket/afsocket-grammar.c"
    break;

  case 211: /* socket_option: KW_SO_RCVBUF '(' nonnegative_integer ')'  */
#line 1303 "modules/afsocket/afsocket-grammar.y"
        {
		CHECK_ERROR((yyvsp[-1].num) <= G_MAXINT, (yylsp[-1]), "Invalid so_rcvbuf, it has to be less than %d", G_MAXINT);
		last_sock_options->so_rcvbuf = (yyvsp[-1].num);
	}
#line 6390 "modules/afsocket/afsocket-grammar.c"
    break;

  case 212: /* socket_option: KW_SO_BROADCAST '(' yesno ')'  */
#line 1307 "modules/afsocket/afsocket-grammar.y"
                                                    { last_sock_options->so_broadcast = (yyvsp[-1].num); }
#line 6396 "modules/afsocket/afsocket-grammar.c"
    break;

  case 213: /* socket_option: KW_SO_KEEPALIVE '(' yesno ')'  */
#line 1308 "modules/afsocket/afsocket-grammar.y"
                                                    { last_sock_options->so_keepalive = (yyvsp[-1].num); }
#line 6402 "modules/afsocket/afsocket-grammar.c"
    break;

  case 214: /* socket_option: KW_SO_REUSEPORT '(' yesno ')'  */
#line 1309 "modules/afsocket/afsocket-grammar.y"
                                                    { last_sock_options->so_reuseport = (yyvsp[-1].num); }
#line 6408 "modules/afsocket/afsocket-grammar.c"
    break;

  case 216: /* unix_socket_option: KW_SO_PASSCRED '(' yesno ')'  */
#line 1314 "modules/afsocket/afsocket-grammar.y"
                                                    { socket_options_unix_set_so_passcred(last_sock_options, (yyvsp[-1].num)); }
#line 6414 "modules/afsocket/afsocket-grammar.c"
    break;

  case 218: /* inet_socket_option: KW_IP_TTL '(' nonnegative_integer ')'  */
#line 1319 "modules/afsocket/afsocket-grammar.y"
                                                              { ((SocketOptionsInet *) last_sock_options)->ip_ttl = (yyvsp[-1].num); }
#line 6420 "modules/afsocket/afsocket-grammar.c"
    break;

  case 219: /* inet_socket_option: KW_IP_TOS '(' nonnegative_integer ')'  */
#line 1320 "modules/afsocket/afsocket-grammar.y"
                                                              { ((SocketOptionsInet *) last_sock_options)->ip_tos = (yyvsp[-1].num); }
#line 6426 "modules/afsocket/afsocket-grammar.c"
    break;

  case 220: /* inet_socket_option: KW_IP_FREEBIND '(' yesno ')'  */
#line 1321 "modules/afsocket/afsocket-grammar.y"
                                                    { ((SocketOptionsInet *) last_sock_options)->ip_freebind = (yyvsp[-1].num); }
#line 6432 "modules/afsocket/afsocket-grammar.c"
    break;

  case 221: /* inet_socket_option: KW_INTERFACE '(' string ')'  */
#line 1322 "modules/afsocket/afsocket-grammar.y"
                                                    { socket_options_inet_set_interface_name((SocketOptionsInet *) last_sock_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6438 "modules/afsocket/afsocket-grammar.c"
    break;

  case 222: /* inet_socket_option: KW_TCP_KEEPALIVE_TIME '(' nonnegative_integer ')'  */
#line 1324 "modules/afsocket/afsocket-grammar.y"
          {
	    CHECK_ERROR(socket_options_inet_set_tcp_keepalive_time((SocketOptionsInet *) last_sock_options, (yyvsp[-1].num)), (yylsp[-3]),
		            "The tcp-keepalive-time() option is not supported on this platform");
	  }
#line 6447 "modules/afsocket/afsocket-grammar.c"
    break;

  case 223: /* inet_socket_option: KW_TCP_KEEPALIVE_INTVL '(' nonnegative_integer ')'  */
#line 1329 "modules/afsocket/afsocket-grammar.y"
          {
	    CHECK_ERROR(socket_options_inet_set_tcp_keepalive_intvl((SocketOptionsInet *) last_sock_options, (yyvsp[-1].num)), (yylsp[-3]),
		            "The tcp-keepalive-intvl() option is not supported on this platform");
	  }
#line 6456 "modules/afsocket/afsocket-grammar.c"
    break;

  case 224: /* inet_socket_option: KW_TCP_KEEPALIVE_PROBES '(' nonnegative_integer ')'  */
#line 1334 "modules/afsocket/afsocket-grammar.y"
          {
	    CHECK_ERROR(socket_options_inet_set_tcp_keepalive_probes((SocketOptionsInet *) last_sock_options, (yyvsp[-1].num)), (yylsp[-3]),
		            "The tcp-keepalive-probes() option is not supported on this platform");
	  }
#line 6465 "modules/afsocket/afsocket-grammar.c"
    break;

  case 225: /* inet_ip_protocol_option: LL_NUMBER  */
#line 1342 "modules/afsocket/afsocket-grammar.y"
        {
          CHECK_ERROR((yyvsp[0].num) == 4 || (yyvsp[0].num) == 6, (yylsp[0]), "ip-protocol option can only be 4 or 6!");
          if ((yyvsp[0].num) == 4)
            {
              (yyval.num) = AF_INET;
            }
          else
            {
              (yyval.num) = AF_INET6;
            }
        }
#line 6481 "modules/afsocket/afsocket-grammar.c"
    break;

  case 228: /* yesno: KW_YES  */
#line 1627 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.num) = 1; }
#line 6487 "modules/afsocket/afsocket-grammar.c"
    break;

  case 229: /* yesno: KW_NO  */
#line 1628 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.num) = 0; }
#line 6493 "modules/afsocket/afsocket-grammar.c"
    break;

  case 230: /* yesno: LL_NUMBER  */
#line 1629 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 6499 "modules/afsocket/afsocket-grammar.c"
    break;

  case 231: /* dnsmode: yesno  */
#line 1633 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 6505 "modules/afsocket/afsocket-grammar.c"
    break;

  case 232: /* dnsmode: KW_PERSIST_ONLY  */
#line 1634 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.num) = 2; }
#line 6511 "modules/afsocket/afsocket-grammar.c"
    break;

  case 233: /* nonnegative_integer64: LL_NUMBER  */
#line 1639 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 6519 "modules/afsocket/afsocket-grammar.c"
    break;

  case 234: /* nonnegative_integer: nonnegative_integer64  */
#line 1646 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 6527 "modules/afsocket/afsocket-grammar.c"
    break;

  case 235: /* positive_integer64: LL_NUMBER  */
#line 1653 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) > 0), (yylsp[0]), "Must be positive");
          }
#line 6535 "modules/afsocket/afsocket-grammar.c"
    break;

  case 236: /* positive_integer: positive_integer64  */
#line 1660 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 6543 "modules/afsocket/afsocket-grammar.c"
    break;

  case 237: /* nonnegative_float: LL_FLOAT  */
#line 1667 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].fnum) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 6551 "modules/afsocket/afsocket-grammar.c"
    break;

  case 238: /* nonnegative_float: nonnegative_integer  */
#line 1671 "modules/afsocket/afsocket-grammar.y"
          {
            (yyval.fnum) = (double) (yyvsp[0].num);
          }
#line 6559 "modules/afsocket/afsocket-grammar.c"
    break;

  case 239: /* string_or_number: string  */
#line 1688 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.cptr) = (yyvsp[0].cptr); }
#line 6565 "modules/afsocket/afsocket-grammar.c"
    break;

  case 240: /* string_or_number: LL_NUMBER  */
#line 1689 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 6571 "modules/afsocket/afsocket-grammar.c"
    break;

  case 241: /* string_or_number: LL_FLOAT  */
#line 1690 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 6577 "modules/afsocket/afsocket-grammar.c"
    break;

  case 242: /* path: string  */
#line 1695 "modules/afsocket/afsocket-grammar.y"
          {
            struct stat buffer;
            int ret = stat((yyvsp[0].cptr), &buffer);
            CHECK_ERROR((ret == 0), (yylsp[0]), "File \"%s\" not found: %s", (yyvsp[0].cptr), strerror(errno));
            (yyval.cptr) = (yyvsp[0].cptr);
	  }
#line 6588 "modules/afsocket/afsocket-grammar.c"
    break;

  case 243: /* path_check: path  */
#line 1704 "modules/afsocket/afsocket-grammar.y"
           { cfg_path_track_file(configuration, (yyvsp[0].cptr), "path_check"); }
#line 6594 "modules/afsocket/afsocket-grammar.c"
    break;

  case 244: /* path_secret: path  */
#line 1708 "modules/afsocket/afsocket-grammar.y"
           { cfg_path_track_file(configuration, (yyvsp[0].cptr), "path_secret"); }
#line 6600 "modules/afsocket/afsocket-grammar.c"
    break;

  case 245: /* normalized_flag: string  */
#line 1716 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.cptr) = normalize_flag((yyvsp[0].cptr)); free((yyvsp[0].cptr)); }
#line 6606 "modules/afsocket/afsocket-grammar.c"
    break;

  case 246: /* string_list: string_list_build  */
#line 1720 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 6612 "modules/afsocket/afsocket-grammar.c"
    break;

  case 247: /* string_list_build: string string_list_build  */
#line 1724 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = g_list_prepend((yyvsp[0].ptr), g_strdup((yyvsp[-1].cptr))); free((yyvsp[-1].cptr)); }
#line 6618 "modules/afsocket/afsocket-grammar.c"
    break;

  case 248: /* string_list_build: %empty  */
#line 1725 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 6624 "modules/afsocket/afsocket-grammar.c"
    break;

  case 249: /* severity_string: string  */
#line 1735 "modules/afsocket/afsocket-grammar.y"
          {
	    /* return the numeric value of the "level" */
	    int n = syslog_name_lookup_severity_by_name((yyvsp[0].cptr));
	    CHECK_ERROR((n != -1), (yylsp[0]), "Unknown priority level\"%s\"", (yyvsp[0].cptr));
	    free((yyvsp[0].cptr));
            (yyval.num) = n;
	  }
#line 6636 "modules/afsocket/afsocket-grammar.c"
    break;

  case 250: /* facility_string: string  */
#line 1746 "modules/afsocket/afsocket-grammar.y"
          {
            /* return the numeric value of facility */
	    int n = syslog_name_lookup_facility_by_name((yyvsp[0].cptr));
	    CHECK_ERROR((n != -1), (yylsp[0]), "Unknown facility \"%s\"", (yyvsp[0].cptr));
	    free((yyvsp[0].cptr));
	    (yyval.num) = n;
	  }
#line 6648 "modules/afsocket/afsocket-grammar.c"
    break;

  case 251: /* facility_string: KW_SYSLOG  */
#line 1753 "modules/afsocket/afsocket-grammar.y"
                                                { (yyval.num) = LOG_SYSLOG; }
#line 6654 "modules/afsocket/afsocket-grammar.c"
    break;

  case 252: /* driver_option: KW_PERSIST_NAME '(' string ')'  */
#line 1769 "modules/afsocket/afsocket-grammar.y"
                                         { log_pipe_set_persist_name(&last_driver->super, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6660 "modules/afsocket/afsocket-grammar.c"
    break;

  case 253: /* inner_source: LL_PLUGIN  */
#line 1774 "modules/afsocket/afsocket-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_INNER_SRC;
            gpointer value;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            value = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_driver);

            free((yyvsp[0].cptr));
            if (!value)
              {
                YYERROR;
              }
            if (!log_driver_add_plugin(last_driver, (LogDriverPlugin *) value))
              {
                log_driver_plugin_free(value);
                CHECK_ERROR(TRUE, (yylsp[0]), "Error while registering the plugin %s in this destination", (yyvsp[0].cptr));
              }
          }
#line 6686 "modules/afsocket/afsocket-grammar.c"
    break;

  case 256: /* inner_dest: LL_PLUGIN  */
#line 1805 "modules/afsocket/afsocket-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_INNER_DEST;
            gpointer value;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            value = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_driver);

            free((yyvsp[0].cptr));
            if (!value)
              {
                YYERROR;
              }
            if (!log_driver_add_plugin(last_driver, (LogDriverPlugin *) value))
              {
                log_driver_plugin_free(value);
                CHECK_ERROR(TRUE, (yylsp[0]), "Error while registering the plugin %s in this destination", (yyvsp[0].cptr));
              }
          }
#line 6712 "modules/afsocket/afsocket-grammar.c"
    break;

  case 257: /* dest_driver_option: KW_LOG_FIFO_SIZE '(' positive_integer ')'  */
#line 1832 "modules/afsocket/afsocket-grammar.y"
                                                        { ((LogDestDriver *) last_driver)->log_fifo_size = (yyvsp[-1].num); }
#line 6718 "modules/afsocket/afsocket-grammar.c"
    break;

  case 258: /* dest_driver_option: KW_THROTTLE '(' nonnegative_integer ')'  */
#line 1833 "modules/afsocket/afsocket-grammar.y"
                                                          { ((LogDestDriver *) last_driver)->throttle = (yyvsp[-1].num); }
#line 6724 "modules/afsocket/afsocket-grammar.c"
    break;

  case 261: /* source_option: KW_LOG_IW_SIZE '(' positive_integer ')'  */
#line 1883 "modules/afsocket/afsocket-grammar.y"
                                                        { last_source_options->init_window_size = (yyvsp[-1].num); }
#line 6730 "modules/afsocket/afsocket-grammar.c"
    break;

  case 262: /* source_option: KW_CHAIN_HOSTNAMES '(' yesno ')'  */
#line 1884 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->chain_hostnames = (yyvsp[-1].num); }
#line 6736 "modules/afsocket/afsocket-grammar.c"
    break;

  case 263: /* source_option: KW_KEEP_HOSTNAME '(' yesno ')'  */
#line 1885 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->keep_hostname = (yyvsp[-1].num); }
#line 6742 "modules/afsocket/afsocket-grammar.c"
    break;

  case 264: /* source_option: KW_PROGRAM_OVERRIDE '(' string ')'  */
#line 1886 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6748 "modules/afsocket/afsocket-grammar.c"
    break;

  case 265: /* source_option: KW_HOST_OVERRIDE '(' string ')'  */
#line 1887 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->host_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6754 "modules/afsocket/afsocket-grammar.c"
    break;

  case 266: /* source_option: KW_LOG_PREFIX '(' string ')'  */
#line 1888 "modules/afsocket/afsocket-grammar.y"
                                                { gchar *p = strrchr((yyvsp[-1].cptr), ':'); if (p) *p = 0; last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6760 "modules/afsocket/afsocket-grammar.c"
    break;

  case 267: /* source_option: KW_KEEP_TIMESTAMP '(' yesno ')'  */
#line 1889 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->keep_timestamp = (yyvsp[-1].num); }
#line 6766 "modules/afsocket/afsocket-grammar.c"
    break;

  case 268: /* source_option: KW_READ_OLD_RECORDS '(' yesno ')'  */
#line 1890 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->read_old_records = (yyvsp[-1].num); }
#line 6772 "modules/afsocket/afsocket-grammar.c"
    break;

  case 269: /* source_option: KW_USE_SYSLOGNG_PID '(' yesno ')'  */
#line 1891 "modules/afsocket/afsocket-grammar.y"
                                                { last_source_options->use_syslogng_pid = (yyvsp[-1].num); }
#line 6778 "modules/afsocket/afsocket-grammar.c"
    break;

  case 270: /* source_option: KW_TAGS '(' string_list ')'  */
#line 1892 "modules/afsocket/afsocket-grammar.y"
                                                { log_source_options_set_tags(last_source_options, (yyvsp[-1].ptr)); }
#line 6784 "modules/afsocket/afsocket-grammar.c"
    break;

  case 271: /* $@32: %empty  */
#line 1893 "modules/afsocket/afsocket-grammar.y"
          { last_host_resolve_options = &last_source_options->host_resolve_options; }
#line 6790 "modules/afsocket/afsocket-grammar.c"
    break;

  case 273: /* source_reader_option: KW_CHECK_HOSTNAME '(' yesno ')'  */
#line 1900 "modules/afsocket/afsocket-grammar.y"
                                                { last_reader_options->check_hostname = (yyvsp[-1].num); }
#line 6796 "modules/afsocket/afsocket-grammar.c"
    break;

  case 275: /* source_reader_option: KW_LOG_FETCH_LIMIT '(' positive_integer ')'  */
#line 1902 "modules/afsocket/afsocket-grammar.y"
                                                        { last_reader_options->fetch_limit = (yyvsp[-1].num); }
#line 6802 "modules/afsocket/afsocket-grammar.c"
    break;

  case 276: /* source_reader_option: KW_FORMAT '(' string ')'  */
#line 1903 "modules/afsocket/afsocket-grammar.y"
                                                { last_reader_options->parse_options.format = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6808 "modules/afsocket/afsocket-grammar.c"
    break;

  case 277: /* $@33: %empty  */
#line 1904 "modules/afsocket/afsocket-grammar.y"
          { last_source_options = &last_reader_options->super; }
#line 6814 "modules/afsocket/afsocket-grammar.c"
    break;

  case 279: /* $@34: %empty  */
#line 1905 "modules/afsocket/afsocket-grammar.y"
          { last_proto_server_options = &last_reader_options->proto_options.super; }
#line 6820 "modules/afsocket/afsocket-grammar.c"
    break;

  case 281: /* $@35: %empty  */
#line 1906 "modules/afsocket/afsocket-grammar.y"
          { last_msg_format_options = &last_reader_options->parse_options; }
#line 6826 "modules/afsocket/afsocket-grammar.c"
    break;

  case 283: /* source_reader_option_flags: string source_reader_option_flags  */
#line 1910 "modules/afsocket/afsocket-grammar.y"
                                                { CHECK_ERROR(log_reader_options_process_flag(last_reader_options, (yyvsp[-1].cptr)), (yylsp[-1]), "Unknown flag \"%s\"", (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6832 "modules/afsocket/afsocket-grammar.c"
    break;

  case 284: /* source_reader_option_flags: KW_CHECK_HOSTNAME source_reader_option_flags  */
#line 1911 "modules/afsocket/afsocket-grammar.y"
                                                           { log_reader_options_process_flag(last_reader_options, "check-hostname"); }
#line 6838 "modules/afsocket/afsocket-grammar.c"
    break;

  case 286: /* source_proto_option: KW_ENCODING '(' string ')'  */
#line 1918 "modules/afsocket/afsocket-grammar.y"
          {
            CHECK_ERROR(log_proto_server_options_set_encoding(last_proto_server_options, (yyvsp[-1].cptr)),
                        (yylsp[-1]),
                        "unknown encoding \"%s\"", (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6849 "modules/afsocket/afsocket-grammar.c"
    break;

  case 287: /* source_proto_option: KW_LOG_MSG_SIZE '(' positive_integer ')'  */
#line 1924 "modules/afsocket/afsocket-grammar.y"
                                                        { last_proto_server_options->max_msg_size = (yyvsp[-1].num); }
#line 6855 "modules/afsocket/afsocket-grammar.c"
    break;

  case 288: /* source_proto_option: KW_TRIM_LARGE_MESSAGES '(' yesno ')'  */
#line 1925 "modules/afsocket/afsocket-grammar.y"
                                                        { last_proto_server_options->trim_large_messages = (yyvsp[-1].num); }
#line 6861 "modules/afsocket/afsocket-grammar.c"
    break;

  case 289: /* host_resolve_option: KW_USE_FQDN '(' yesno ')'  */
#line 1929 "modules/afsocket/afsocket-grammar.y"
                                                { last_host_resolve_options->use_fqdn = (yyvsp[-1].num); }
#line 6867 "modules/afsocket/afsocket-grammar.c"
    break;

  case 290: /* host_resolve_option: KW_USE_DNS '(' dnsmode ')'  */
#line 1930 "modules/afsocket/afsocket-grammar.y"
                                                { last_host_resolve_options->use_dns = (yyvsp[-1].num); }
#line 6873 "modules/afsocket/afsocket-grammar.c"
    break;

  case 291: /* host_resolve_option: KW_DNS_CACHE '(' yesno ')'  */
#line 1931 "modules/afsocket/afsocket-grammar.y"
                                                { last_host_resolve_options->use_dns_cache = (yyvsp[-1].num); }
#line 6879 "modules/afsocket/afsocket-grammar.c"
    break;

  case 292: /* host_resolve_option: KW_NORMALIZE_HOSTNAMES '(' yesno ')'  */
#line 1932 "modules/afsocket/afsocket-grammar.y"
                                                { last_host_resolve_options->normalize_hostnames = (yyvsp[-1].num); }
#line 6885 "modules/afsocket/afsocket-grammar.c"
    break;

  case 293: /* msg_format_option: KW_TIME_ZONE '(' string ')'  */
#line 1936 "modules/afsocket/afsocket-grammar.y"
                                                { last_msg_format_options->recv_time_zone = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 6891 "modules/afsocket/afsocket-grammar.c"
    break;

  case 294: /* msg_format_option: KW_DEFAULT_SEVERITY '(' severity_string ')'  */
#line 1938 "modules/afsocket/afsocket-grammar.y"
          {
	    if (last_msg_format_options->default_pri == 0xFFFF)
	      last_msg_format_options->default_pri = LOG_USER;
	    last_msg_format_options->default_pri = (last_msg_format_options->default_pri & ~LOG_PRIMASK) | (yyvsp[-1].num);
          }
#line 6901 "modules/afsocket/afsocket-grammar.c"
    break;

  case 295: /* msg_format_option: KW_DEFAULT_FACILITY '(' facility_string ')'  */
#line 1944 "modules/afsocket/afsocket-grammar.y"
          {
	    if (last_msg_format_options->default_pri == 0xFFFF)
	      last_msg_format_options->default_pri = LOG_NOTICE;
	    last_msg_format_options->default_pri = (last_msg_format_options->default_pri & LOG_PRIMASK) | (yyvsp[-1].num);
          }
#line 6911 "modules/afsocket/afsocket-grammar.c"
    break;

  case 296: /* dest_writer_option: KW_FLAGS '(' dest_writer_options_flags ')'  */
#line 1959 "modules/afsocket/afsocket-grammar.y"
                                                     { last_writer_options->options = (yyvsp[-1].num); }
#line 6917 "modules/afsocket/afsocket-grammar.c"
    break;

  case 297: /* dest_writer_option: KW_FLUSH_LINES '(' nonnegative_integer ')'  */
#line 1960 "modules/afsocket/afsocket-grammar.y"
                                                                { last_writer_options->flush_lines = (yyvsp[-1].num); }
#line 6923 "modules/afsocket/afsocket-grammar.c"
    break;

  case 298: /* dest_writer_option: KW_FLUSH_TIMEOUT '(' positive_integer ')'  */
#line 1961 "modules/afsocket/afsocket-grammar.y"
                                                        { }
#line 6929 "modules/afsocket/afsocket-grammar.c"
    break;

  case 299: /* dest_writer_option: KW_SUPPRESS '(' nonnegative_integer ')'  */
#line 1962 "modules/afsocket/afsocket-grammar.y"
                                                             { last_writer_options->suppress = (yyvsp[-1].num); }
#line 6935 "modules/afsocket/afsocket-grammar.c"
    break;

  case 300: /* dest_writer_option: KW_TEMPLATE '(' string ')'  */
#line 1963 "modules/afsocket/afsocket-grammar.y"
                                                {
                                                  GError *error = NULL;

                                                  last_writer_options->template = cfg_tree_check_inline_template(&configuration->tree, (yyvsp[-1].cptr), &error);
                                                  CHECK_ERROR_GERROR(last_writer_options->template != NULL, (yylsp[-1]), error, "Error compiling template");
	                                          free((yyvsp[-1].cptr));
	                                        }
#line 6947 "modules/afsocket/afsocket-grammar.c"
    break;

  case 301: /* dest_writer_option: KW_TEMPLATE_ESCAPE '(' yesno ')'  */
#line 1970 "modules/afsocket/afsocket-grammar.y"
                                                { log_writer_options_set_template_escape(last_writer_options, (yyvsp[-1].num)); }
#line 6953 "modules/afsocket/afsocket-grammar.c"
    break;

  case 302: /* dest_writer_option: KW_PAD_SIZE '(' nonnegative_integer ')'  */
#line 1971 "modules/afsocket/afsocket-grammar.y"
                                                          { last_writer_options->padding = (yyvsp[-1].num); }
#line 6959 "modules/afsocket/afsocket-grammar.c"
    break;

  case 303: /* dest_writer_option: KW_TRUNCATE_SIZE '(' nonnegative_integer ')'  */
#line 1972 "modules/afsocket/afsocket-grammar.y"
                                                               { last_writer_options->truncate_size = (yyvsp[-1].num); }
#line 6965 "modules/afsocket/afsocket-grammar.c"
    break;

  case 304: /* dest_writer_option: KW_MARK_FREQ '(' nonnegative_integer ')'  */
#line 1973 "modules/afsocket/afsocket-grammar.y"
                                                          { last_writer_options->mark_freq = (yyvsp[-1].num); }
#line 6971 "modules/afsocket/afsocket-grammar.c"
    break;

  case 305: /* dest_writer_option: KW_MARK_MODE '(' KW_INTERNAL ')'  */
#line 1974 "modules/afsocket/afsocket-grammar.y"
                                                { log_writer_options_set_mark_mode(last_writer_options, "internal"); }
#line 6977 "modules/afsocket/afsocket-grammar.c"
    break;

  case 306: /* dest_writer_option: KW_MARK_MODE '(' string ')'  */
#line 1976 "modules/afsocket/afsocket-grammar.y"
          {
	    CHECK_ERROR(cfg_lookup_mark_mode((yyvsp[-1].cptr)) != -1, (yylsp[-1]), "illegal mark mode \"%s\"", (yyvsp[-1].cptr));
            log_writer_options_set_mark_mode(last_writer_options, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 6987 "modules/afsocket/afsocket-grammar.c"
    break;

  case 307: /* dest_writer_option: KW_TIME_REOPEN '(' positive_integer ')'  */
#line 1981 "modules/afsocket/afsocket-grammar.y"
                                                  { last_writer_options->time_reopen = (yyvsp[-1].num); }
#line 6993 "modules/afsocket/afsocket-grammar.c"
    break;

  case 308: /* $@36: %empty  */
#line 1982 "modules/afsocket/afsocket-grammar.y"
          { last_template_options = &last_writer_options->template_options; }
#line 6999 "modules/afsocket/afsocket-grammar.c"
    break;

  case 310: /* dest_writer_options_flags: normalized_flag dest_writer_options_flags  */
#line 1986 "modules/afsocket/afsocket-grammar.y"
                                                      { (yyval.num) = log_writer_options_lookup_flag((yyvsp[-1].cptr)) | (yyvsp[0].num); free((yyvsp[-1].cptr)); }
#line 7005 "modules/afsocket/afsocket-grammar.c"
    break;

  case 311: /* dest_writer_options_flags: %empty  */
#line 1987 "modules/afsocket/afsocket-grammar.y"
                                                      { (yyval.num) = 0; }
#line 7011 "modules/afsocket/afsocket-grammar.c"
    break;

  case 312: /* file_perm_option: KW_OWNER '(' string_or_number ')'  */
#line 1991 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_set_file_uid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7017 "modules/afsocket/afsocket-grammar.c"
    break;

  case 313: /* file_perm_option: KW_OWNER '(' ')'  */
#line 1992 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_dont_change_file_uid(last_file_perm_options); }
#line 7023 "modules/afsocket/afsocket-grammar.c"
    break;

  case 314: /* file_perm_option: KW_GROUP '(' string_or_number ')'  */
#line 1993 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_set_file_gid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7029 "modules/afsocket/afsocket-grammar.c"
    break;

  case 315: /* file_perm_option: KW_GROUP '(' ')'  */
#line 1994 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_dont_change_file_gid(last_file_perm_options); }
#line 7035 "modules/afsocket/afsocket-grammar.c"
    break;

  case 316: /* file_perm_option: KW_PERM '(' LL_NUMBER ')'  */
#line 1995 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_set_file_perm(last_file_perm_options, (yyvsp[-1].num)); }
#line 7041 "modules/afsocket/afsocket-grammar.c"
    break;

  case 317: /* file_perm_option: KW_PERM '(' ')'  */
#line 1996 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_dont_change_file_perm(last_file_perm_options); }
#line 7047 "modules/afsocket/afsocket-grammar.c"
    break;

  case 318: /* file_perm_option: KW_DIR_OWNER '(' string_or_number ')'  */
#line 1997 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_set_dir_uid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7053 "modules/afsocket/afsocket-grammar.c"
    break;

  case 319: /* file_perm_option: KW_DIR_OWNER '(' ')'  */
#line 1998 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_dont_change_dir_uid(last_file_perm_options); }
#line 7059 "modules/afsocket/afsocket-grammar.c"
    break;

  case 320: /* file_perm_option: KW_DIR_GROUP '(' string_or_number ')'  */
#line 1999 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_set_dir_gid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7065 "modules/afsocket/afsocket-grammar.c"
    break;

  case 321: /* file_perm_option: KW_DIR_GROUP '(' ')'  */
#line 2000 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_dont_change_dir_gid(last_file_perm_options); }
#line 7071 "modules/afsocket/afsocket-grammar.c"
    break;

  case 322: /* file_perm_option: KW_DIR_PERM '(' LL_NUMBER ')'  */
#line 2001 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_set_dir_perm(last_file_perm_options, (yyvsp[-1].num)); }
#line 7077 "modules/afsocket/afsocket-grammar.c"
    break;

  case 323: /* file_perm_option: KW_DIR_PERM '(' ')'  */
#line 2002 "modules/afsocket/afsocket-grammar.y"
                                                { file_perm_options_dont_change_dir_perm(last_file_perm_options); }
#line 7083 "modules/afsocket/afsocket-grammar.c"
    break;

  case 324: /* template_option: KW_TS_FORMAT '(' string ')'  */
#line 2006 "modules/afsocket/afsocket-grammar.y"
                                                { last_template_options->ts_format = cfg_ts_format_value((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7089 "modules/afsocket/afsocket-grammar.c"
    break;

  case 325: /* template_option: KW_FRAC_DIGITS '(' nonnegative_integer ')'  */
#line 2007 "modules/afsocket/afsocket-grammar.y"
                                                        { last_template_options->frac_digits = (yyvsp[-1].num); }
#line 7095 "modules/afsocket/afsocket-grammar.c"
    break;

  case 326: /* template_option: KW_TIME_ZONE '(' string ')'  */
#line 2008 "modules/afsocket/afsocket-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7101 "modules/afsocket/afsocket-grammar.c"
    break;

  case 327: /* template_option: KW_SEND_TIME_ZONE '(' string ')'  */
#line 2009 "modules/afsocket/afsocket-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7107 "modules/afsocket/afsocket-grammar.c"
    break;

  case 328: /* template_option: KW_LOCAL_TIME_ZONE '(' string ')'  */
#line 2010 "modules/afsocket/afsocket-grammar.y"
                                                { last_template_options->time_zone[LTZ_LOCAL] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 7113 "modules/afsocket/afsocket-grammar.c"
    break;

  case 329: /* template_option: KW_ON_ERROR '(' string ')'  */
#line 2012 "modules/afsocket/afsocket-grammar.y"
        {
          gint on_error;

          CHECK_ERROR(log_template_on_error_parse((yyvsp[-1].cptr), &on_error), (yylsp[-1]), "Invalid on-error() setting \"%s\"", (yyvsp[-1].cptr));
          free((yyvsp[-1].cptr));

          log_template_options_set_on_error(last_template_options, on_error);
        }
#line 7126 "modules/afsocket/afsocket-grammar.c"
    break;

  case 330: /* _inner_dest_context_push: %empty  */
#line 2145 "modules/afsocket/afsocket-grammar.y"
                          { cfg_lexer_push_context(lexer, LL_CONTEXT_INNER_DEST, NULL, "within destination"); }
#line 7132 "modules/afsocket/afsocket-grammar.c"
    break;

  case 331: /* _inner_dest_context_pop: %empty  */
#line 2146 "modules/afsocket/afsocket-grammar.y"
                         { cfg_lexer_pop_context(lexer); }
#line 7138 "modules/afsocket/afsocket-grammar.c"
    break;

  case 332: /* _inner_src_context_push: %empty  */
#line 2147 "modules/afsocket/afsocket-grammar.y"
                         { cfg_lexer_push_context(lexer, LL_CONTEXT_INNER_SRC, NULL, "within source"); }
#line 7144 "modules/afsocket/afsocket-grammar.c"
    break;

  case 333: /* _inner_src_context_pop: %empty  */
#line 2148 "modules/afsocket/afsocket-grammar.y"
                        { cfg_lexer_pop_context(lexer); }
#line 7150 "modules/afsocket/afsocket-grammar.c"
    break;


#line 7154 "modules/afsocket/afsocket-grammar.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == AFSOCKET_EMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (&yylloc, lexer, instance, arg, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= AFSOCKET_EOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == AFSOCKET_EOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, lexer, instance, arg);
          yychar = AFSOCKET_EMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, lexer, instance, arg);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, lexer, instance, arg, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != AFSOCKET_EMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, lexer, instance, arg);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, lexer, instance, arg);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 2153 "modules/afsocket/afsocket-grammar.y"

