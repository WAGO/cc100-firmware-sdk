Deprecated platforms
====================

Process of deprecating a platform
---------------------------------

Platform can be deprecated and its source can be kept in repository for a cooling
off period before deleting it or it can be deleted straight away. For later types
Deprecated/Deleted version would be same.

List of deprecated platforms
----------------------------

+----------------+----------------+--------------------+--------------------+
|    Platform    |     Vendor     | Deprecated version |  Deleted version   |
+================+================+====================+====================+
|    sgm775      |      Arm       |        2.5         |       2.7          |
+----------------+----------------+--------------------+--------------------+
