OP-TEE Dispatcher
=================

`OP-TEE OS`_ is a Trusted OS running as Secure EL1.

To build and execute OP-TEE follow the instructions at
`OP-TEE build.git`_

--------------

*Copyright (c) 2014-2018, Arm Limited and Contributors. All rights reserved.*

.. _OP-TEE OS: https://github.com/OP-TEE/build
.. _OP-TEE build.git: https://github.com/OP-TEE/build
