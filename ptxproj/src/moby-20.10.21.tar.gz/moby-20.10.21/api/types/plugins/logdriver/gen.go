//go:generate protoc --gogofast_out=import_path=github.com/docker/docker/api/types/plugins/logdriver:. entry.proto

package logdriver // import "github.com/docker/docker/api/types/plugins/logdriver"
