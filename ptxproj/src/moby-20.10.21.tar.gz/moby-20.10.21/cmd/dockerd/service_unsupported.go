//go:build !windows
// +build !windows

package main

import (
	"github.com/spf13/pflag"
)

func installServiceFlags(flags *pflag.FlagSet) {
}
