char const netsnmp_helpers_dummy_text[] = "dummy symbol to make sure that linking netsnmphelpers does not fail on systems that do not support empty libraries.";
